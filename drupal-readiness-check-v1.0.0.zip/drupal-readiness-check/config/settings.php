<?php

/**
 * @file
 * Configuración del validador. Todas las rutas son relativas.
 *
 * - Rutas que empiezan por "tool:" son relativas al directorio del validador.
 * - El resto son relativas a la raíz del repositorio Git del proyecto.
 */

return [
    // Ramas candidatas para autodetectar la base, en orden de preferencia.
    // Para cada una se prueba primero <remote>/<rama> y luego la rama local.
    'base_candidates' => ['develop', 'main', 'master'],
    'remote' => 'origin',

    // Validaciones que se ejecutan por defecto.
    'default_checks' => ['db-updates', 'code-standards', 'secrets-scan'],

    // Validaciones opcionales: solo con --all-checks o --checks=<id>.
    'optional_checks' => ['config-status', 'composer-audit', 'disallowed-modules'],

    // Extensiones tratadas como PHP (php -l y phpcs).
    'php_extensions' => ['php', 'module', 'inc', 'install', 'theme'],

    // Extensiones tratadas como YAML (symfony/yaml).
    'yaml_extensions' => ['yml', 'yaml'],

    // Estándar de phpcs cuando el proyecto no tiene phpcs.xml(.dist).
    'phpcs_default_standard' => 'Drupal,DrupalPractice',

    // Archivos de configuración de phpcs que se respetan si existen en la raíz.
    'phpcs_project_configs' => ['phpcs.xml', 'phpcs.xml.dist', '.phpcs.xml', '.phpcs.xml.dist'],

    // Lista configurable de módulos prohibidos.
    'disallowed_modules_file' => 'tool:config/disallowed-modules.txt',

    // Rutas que nunca se analizan (además del propio directorio del validador,
    // que se excluye siempre de forma automática).
    'exclude_paths' => [
        '.ddev/commands/web/readiness-check',
    ],

    // Tiempos máximos (segundos) para herramientas externas.
    'timeouts' => [
        'drush' => 300,
        'phpcs' => 600,
        'gitleaks' => 600,
        'composer' => 300,
        'php_lint' => 60,
    ],
];
