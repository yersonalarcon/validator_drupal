#!/usr/bin/env bash
#
# Batería de pruebas automáticas del validador.
#
# Cada escenario crea un repositorio Git temporal (con espacios y tildes en la
# ruta) y una copia del validador dentro de él. Nunca se modifica el proyecto
# Drupal del usuario ni el directorio original del validador.
#
# Uso:
#   bash drupal-readiness-check/tests/scenario-branch.sh
#
# Variables opcionales:
#   PHP_BIN                       Intérprete PHP (por defecto: php).
#   READINESS_TEST_GITLEAKS       Ruta a un Gitleaks real (o se busca en PATH / bin/gitleaks).
#   READINESS_TEST_PHPCS          Ruta a un phpcs real con Drupal Coder.
#   READINESS_TEST_YAML_AUTOLOAD  vendor/autoload.php con symfony/yaml real.
#   KEEP_TMP=1                    Conserva los directorios temporales.
#
# Las pruebas marcadas "[doble]" usan dobles de prueba (tests/fakes) que
# reproducen el formato de salida de Drush, phpcs o Gitleaks: verifican la
# integración del validador (mapeo, clasificación, redacción), no la
# herramienta real. Las marcadas "[real]" requieren la herramienta instalada
# y se reportan como SKIP si no está disponible.

set -uo pipefail

TOOL_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
PHP_BIN="${PHP_BIN:-php}"

if ! command -v "${PHP_BIN}" >/dev/null 2>&1 && [ ! -x "${PHP_BIN}" ]; then
  echo "No se encontró PHP (${PHP_BIN})." >&2
  exit 2
fi
if ! command -v git >/dev/null 2>&1; then
  echo "No se encontró git." >&2
  exit 2
fi

WORK="$(mktemp -d "${TMPDIR:-/tmp}/readiness tests ñ.XXXXXX")"
cleanup() {
  if [ "${KEEP_TMP:-0}" = "1" ]; then
    echo "Directorio temporal conservado: ${WORK}"
  else
    rm -rf "${WORK}"
  fi
}
trap cleanup EXIT

PASSED=0
FAILED=0
SKIPPED=0
FAILED_NAMES=()
N=0

pass() { N=$((N + 1)); PASSED=$((PASSED + 1)); printf '  \033[32mPASS\033[0m %02d %s\n' "$N" "$1"; }
fail() { N=$((N + 1)); FAILED=$((FAILED + 1)); FAILED_NAMES+=("$1"); printf '  \033[31mFAIL\033[0m %02d %s\n' "$N" "$1"; [ -n "${2:-}" ] && printf '       %s\n' "$2"; return 0; }
skip() { N=$((N + 1)); SKIPPED=$((SKIPPED + 1)); printf '  \033[33mSKIP\033[0m %02d %s — %s\n' "$N" "$1" "$2"; }
section() { printf '\n\033[1m%s\033[0m\n' "$1"; }

# ---------------------------------------------------------------------------
# Dobles de prueba envueltos para usar el PHP indicado.
FAKES="${WORK}/fakes"
mkdir -p "${FAKES}"
PHP_ABS="$(command -v "${PHP_BIN}" || echo "${PHP_BIN}")"
for tool in drush gitleaks phpcs; do
  printf '#!/usr/bin/env bash\nexec "%s" "%s" "$@"\n' "${PHP_ABS}" "${TOOL_SRC}/tests/fakes/fake-${tool}.php" > "${FAKES}/${tool}"
  chmod +x "${FAKES}/${tool}"
done
NONE="${WORK}/no-instalado"

# Herramientas reales opcionales.
REAL_GITLEAKS="${READINESS_TEST_GITLEAKS:-}"
if [ -z "${REAL_GITLEAKS}" ]; then
  if [ -x "${TOOL_SRC}/bin/gitleaks" ]; then REAL_GITLEAKS="${TOOL_SRC}/bin/gitleaks";
  else REAL_GITLEAKS="$(command -v gitleaks || true)"; fi
fi
REAL_PHPCS="${READINESS_TEST_PHPCS:-$(command -v phpcs || true)}"
REAL_YAML="${READINESS_TEST_YAML_AUTOLOAD:-}"

# ---------------------------------------------------------------------------
# Utilidades.

# Crea un proyecto: rama develop con contenido base, remoto "origin" y la
# rama feature/<nombre>. Deja la ruta en $P.
new_project() {
  local name="$1" with_remote="${2:-yes}"
  P="${WORK}/Proyecto Drupal ñandú/${name}"
  mkdir -p "${P}"
  git -C "${P}" init -q -b develop
  git -C "${P}" config user.name "Dev Pruebas Ñ"
  git -C "${P}" config user.email "dev@example.com"
  git -C "${P}" config commit.gpgsign false
  mkdir -p "${P}/web/modules/custom/demo" "${P}/web/modules/custom/legacy" "${P}/web/modules/contrib/othermod" "${P}/config/sync"
  printf '/vendor/\n' > "${P}/.gitignore"
  cat > "${P}/web/modules/custom/demo/demo.module" <<'PHP'
<?php

/**
 * @file
 * Módulo de pruebas.
 */

function demo_help() {
  return 'ayuda';
}
PHP
  cat > "${P}/web/modules/custom/demo/demo.install" <<'PHP'
<?php

/**
 * @file
 * Instalación.
 */
PHP
  cat > "${P}/web/modules/custom/demo/demo.info.yml" <<'YML'
name: Demo
type: module
core_version_requirement: ^10 || ^11
dependencies:
  - drupal:node
YML
  cat > "${P}/web/modules/custom/legacy/legacy.inc" <<'PHP'
<?php
// Archivo heredado con un error de sintaxis preexistente.
$valor = ;
$otra = 1;
$mas = 2;
$fin = 3;
PHP
  cat > "${P}/web/modules/contrib/othermod/othermod.install" <<'PHP'
<?php

function othermod_update_9001() {
  return 'contrib';
}
PHP
  cat > "${P}/config/sync/core.extension.yml" <<'YML'
module:
  kint: 0
  node: 0
  system: 0
theme:
  olivero: 0
YML
  printf '{\n  "name": "acme/site",\n  "require": {\n    "drupal/core": "^10"\n  }\n}\n' > "${P}/composer.json"
  git -C "${P}" add -A
  git -C "${P}" commit -q -m "Base del proyecto"
  if [ "${with_remote}" = "yes" ]; then
    git init -q --bare "${P}.remote.git"
    git -C "${P}" remote add origin "${P}.remote.git"
    git -C "${P}" push -q origin develop 2>/dev/null
    git -C "${P}" fetch -q origin
  fi
  git -C "${P}" checkout -q -b "feature/${name}"
  # Copia del validador (sin seguimiento, como en una instalación real sin exclude).
  mkdir -p "${P}/drupal-readiness-check"
  (cd "${TOOL_SRC}" && tar --exclude='./reports/readiness-*' --exclude='./bin/gitleaks' -cf - .) | (cd "${P}/drupal-readiness-check" && tar -xf -)
  # Archivo roto dentro del validador: nunca debe analizarse.
  mkdir -p "${P}/drupal-readiness-check/tests/fixtures"
  printf '<?php\n$roto = ;\n' > "${P}/drupal-readiness-check/tests/fixtures/broken.php"
  : > "${WORK}/fake.log"
}

commit_all() { git -C "${P}" add -A -- . ':!drupal-readiness-check' && git -C "${P}" commit -q -m "$1"; }

# Ejecuta el validador en $P. Deja RC, OUT (stdout+stderr) y JSON (ruta del reporte).
run_check() {
  OUT="$(cd "${P}" && env \
    READINESS_DRUSH="${T_DRUSH:-${NONE}}" \
    READINESS_PHPCS="${T_PHPCS:-${NONE}}" \
    READINESS_GITLEAKS="${T_GITLEAKS:-${NONE}}" \
    READINESS_COMPOSER="${T_COMPOSER:-${NONE}}" \
    ${T_YAML:+READINESS_YAML_AUTOLOAD="${T_YAML}"} \
    FAKE_LOG="${WORK}/fake.log" \
    "${PHP_BIN}" drupal-readiness-check/bin/readiness-check --no-color "$@" 2>&1)"
  RC=$?
  local head
  head="$(git -C "${P}" rev-parse HEAD 2>/dev/null | cut -c1-12)"
  JSON="${P}/drupal-readiness-check/reports/readiness-${head}.json"
}

# Evalúa una expresión PHP sobre el reporte JSON. Variables disponibles:
#   $r (reporte), $c (validaciones por id) y $a (segundo argumento opcional).
q() {
  "${PHP_BIN}" -r '$r = json_decode(file_get_contents($argv[1]), true); if (!is_array($r)) { echo "JSON_INVALIDO"; exit; } $c = []; foreach ($r["checks"] as $x) { $c[$x["id"]] = $x; } $a = $argv[3] ?? null; echo (function ($r, $c, $a) { return eval("return " . $GLOBALS["argv"][2] . ";"); })($r, $c, $a);' "${JSON}" "$1" "${2:-}" 2>/dev/null
}

expect_eq() { # descripción, obtenido, esperado
  if [ "$2" = "$3" ]; then pass "$1"; else fail "$1" "esperado '$3', obtenido '$2'"; fi
}

reset_env() { unset T_DRUSH T_PHPCS T_GITLEAKS T_COMPOSER T_YAML FAKE_DRUSH_UPDB FAKE_DRUSH_CONFIG FAKE_DRUSH_EXIT FAKE_GITLEAKS_MODE FAKE_GITLEAKS_JSON FAKE_PHPCS; }

echo "Validador: ${TOOL_SRC}"
echo "PHP: $("${PHP_BIN}" -r 'echo PHP_VERSION;')"
echo "Temporal: ${WORK}"

# ===========================================================================
section "Opciones y errores de configuración"
reset_env
mkdir -p "${WORK}/sin git ñ"
cp -R "${TOOL_SRC}" "${WORK}/sin git ñ/drupal-readiness-check"
rm -f "${WORK}/sin git ñ/drupal-readiness-check/reports/readiness-"*
OUT="$(cd "${WORK}/sin git ñ" && GIT_CEILING_DIRECTORIES="${WORK}" "${PHP_BIN}" drupal-readiness-check/bin/readiness-check --no-color 2>&1)"; RC=$?
if [ "${RC}" -eq 2 ] && grep -q "no pertenece a un repositorio Git" <<<"${OUT}"; then pass "Proyecto sin Git → código 2 con mensaje claro"; else fail "Proyecto sin Git → código 2" "rc=${RC} ${OUT}"; fi

NOGIT_BIN="${WORK}/bin-sin-git"; mkdir -p "${NOGIT_BIN}"
ln -s "$(command -v bash)" "${NOGIT_BIN}/bash"; ln -s "${PHP_ABS}" "${NOGIT_BIN}/php"
OUT="$(cd "${WORK}/sin git ñ" && env PATH="${NOGIT_BIN}" php drupal-readiness-check/bin/readiness-check --demo --no-color 2>&1)"; RC=$?
DEMO_JSON="${WORK}/sin git ñ/drupal-readiness-check/reports/readiness-demo.json"
if [ "${RC}" -eq 0 ] && [ -f "${DEMO_JSON}" ] && grep -q '"mode": "demo"' "${DEMO_JSON}" && [ -f "${DEMO_JSON%.json}.md" ]; then
  pass "--demo funciona sin Git ni herramientas (PATH sin git) y genera reportes"
else fail "--demo sin Git" "rc=${RC} ${OUT}"; fi

new_project opciones
run_check --opcion-inexistente
expect_eq "Opción desconocida → código 2" "${RC}" "2"
run_check --checks=no-existe
expect_eq "--checks con validación desconocida → código 2" "${RC}" "2"
run_check --base=origin/no-existe
if [ "${RC}" -eq 2 ] && grep -q "no existe" <<<"${OUT}"; then pass "--base inexistente → código 2"; else fail "--base inexistente" "rc=${RC} ${OUT}"; fi

# ===========================================================================
section "Rama limpia, detección de base, reportes y exclusiones"
reset_env
new_project limpia
T_DRUSH="${FAKES}/drush"
printf "<?php\n\n/**\n * @file\n * Módulo de pruebas.\n */\n\nfunction demo_help() {\n  return 'ayuda actualizada';\n}\n" > "${P}/web/modules/custom/demo/demo.module"
commit_all "Cambio válido"
BEFORE_STATUS="$(git -C "${P}" status --porcelain=v1 -uall | grep -v 'drupal-readiness-check/' ; git -C "${P}" rev-parse HEAD; git -C "${P}" stash list)"
run_check
expect_eq "Rama con cambios válidos → código 0" "${RC}" "0"
expect_eq "Base autodetectada prefiriendo la remota (origin/develop)" "$(q '$r["project"]["base"]')" "origin/develop"
if [ -f "${JSON}" ] && [ -f "${JSON%.json}.md" ]; then pass "Reportes reports/readiness-<commit>.md y .json generados"; else fail "Reportes generados" "${JSON}"; fi
expect_eq "JSON incluye commit y rama actual" "$(q '$r["project"]["commit"] === trim(shell_exec("git -C " . escapeshellarg(dirname($GLOBALS["argv"][1], 3)) . " rev-parse HEAD")) && $r["project"]["branch"] === "feature/limpia" ? "ok" : "no"')" "ok"
expect_eq "Archivo modificado en commit listado con origen 'committed'" "$(q 'implode(",", array_column($r["files"], "origins", "path")["web/modules/custom/demo/demo.module"] ?? [])')" "committed"
expect_eq "Archivos del validador excluidos del análisis" "$(q 'count(array_filter(array_column($r["files"], "path"), fn($p) => str_starts_with($p, "drupal-readiness-check/"))) === 0 && in_array("drupal-readiness-check/tests/fixtures/broken.php", $r["excluded_files"]) ? "ok" : "no"')" "ok"
if ! grep -q "config:status" "${WORK}/fake.log" && [ "$(q '$c["config-status"]["status"]')" = "OMITTED" ] && [ "$(q '$c["composer-audit"]["status"]')" = "OMITTED" ]; then
  pass "Validaciones opcionales no se ejecutan por defecto"
else fail "Validaciones opcionales no se ejecutan por defecto"; fi
AFTER_STATUS="$(git -C "${P}" status --porcelain=v1 -uall | grep -v 'drupal-readiness-check/' ; git -C "${P}" rev-parse HEAD; git -C "${P}" stash list)"
expect_eq "El validador no modifica el repositorio (estado, HEAD, stash)" "${AFTER_STATUS}" "${BEFORE_STATUS}"
if grep -q "## Archivos considerados" "${JSON%.json}.md" && grep -q "Rama base" "${JSON%.json}.md"; then pass "Reporte Markdown con contexto y archivos considerados"; else fail "Reporte Markdown"; fi

run_check --base=origin/develop
expect_eq "--base=origin/develop explícito (rama remota) → código 0" "${RC}" "0"
expect_eq "merge-base calculado con la rama remota" "$(q '$r["project"]["merge_base"]')" "$(git -C "${P}" merge-base HEAD origin/develop)"

reset_env
new_project solo-local no
git -C "${P}" branch -q -m develop main 2>/dev/null || true
git -C "${P}" checkout -q main && git -C "${P}" checkout -q -b feature/local
run_check
expect_eq "Sin remoto ni develop: autodetecta la rama local 'main'" "$(q '$r["project"]["base"]')" "main"

reset_env
new_project sin-base no
git -C "${P}" branch -q -m develop trunk
run_check
if [ "${RC}" -eq 2 ] && grep -q "autodetectar" <<<"${OUT}"; then pass "Sin develop/main/master → código 2 pidiendo --base"; else fail "Sin base detectable" "rc=${RC}"; fi

# ===========================================================================
section "Errores nuevos y preexistentes (php -l)"
reset_env
new_project php-nuevo
printf "<?php\n\nfunction demo_help() {\n  return ;;\n  \$x = ;\n}\n" > "${P}/web/modules/custom/demo/demo.module"
commit_all "Error nuevo"
run_check
expect_eq "PHP inválido en .module → code-standards FAIL" "$(q '$c["code-standards"]["status"]')" "FAIL"
expect_eq "PHP inválido → código de salida 1" "${RC}" "1"
expect_eq "Hallazgo con archivo .module y línea exacta" "$(q '$c["code-standards"]["findings"][0]["file"] . ":" . $c["code-standards"]["findings"][0]["line"]')" "web/modules/custom/demo/demo.module:5"

reset_env
new_project php-preexistente
printf '<?php\n// Archivo heredado con un error de sintaxis preexistente.\n$valor = ;\n$otra = 1;\n$mas = 22;\n$fin = 3;\n' > "${P}/web/modules/custom/legacy/legacy.inc"
commit_all "Cambio en otra línea"
run_check
expect_eq "Error preexistente en línea no modificada → no bloquea (código 0)" "${RC}" "0"
expect_eq "Error preexistente listado aparte" "$(q 'count($c["code-standards"]["findings"]) . "/" . count($c["code-standards"]["preexisting"]) . "/" . $c["code-standards"]["preexisting"][0]["line"]')" "0/1/3"

reset_env
new_project php-causado
printf "<?php\n\n/**\n * @file\n * Módulo de pruebas.\n */\n\nfunction demo_help() {\n  return 'ayuda';\n\n" > "${P}/web/modules/custom/demo/demo.module"
commit_all "Borra la llave de cierre"
run_check
expect_eq "Error reportado en línea no modificada pero causado por la rama → FAIL" "$(q '$c["code-standards"]["status"]')" "FAIL"

# ===========================================================================
section "Staged, unstaged, archivos nuevos y nombres especiales"
reset_env
new_project origenes
printf '<?php\n$staged = ;\n' > "${P}/web/modules/custom/demo/staged.php"
git -C "${P}" add web/modules/custom/demo/staged.php
printf "<?php\n\n/**\n * @file\n * Módulo de pruebas.\n */\n\nfunction demo_help() {\n  return 'x' . ;\n}\n" > "${P}/web/modules/custom/demo/demo.module"
printf '<?php\n$nuevo = ;\n' > "${P}/web/modules/custom/demo/nuevo.theme"
printf '<?php\n$esp = ;\n' > "${P}/web/modules/custom/demo/mi archivo con espacios.php"
printf '<?php\n$esp = ;\n' > "${P}/web/modules/custom/demo/ñandú-ácido #1 & (copia).inc"
run_check
origins() { q 'implode(",", array_column($r["files"], "origins", "path")[$a] ?? ["ausente"])' "$1"; }
has_finding() { q 'in_array($a, array_column($c["code-standards"]["findings"], "file"), true) ? "si" : "no"' "$1"; }
expect_eq "Cambio staged detectado (origen staged)" "$(origins web/modules/custom/demo/staged.php)/$(has_finding web/modules/custom/demo/staged.php)" "staged/si"
expect_eq "Cambio unstaged detectado (origen unstaged)" "$(origins web/modules/custom/demo/demo.module)/$(has_finding web/modules/custom/demo/demo.module)" "unstaged/si"
expect_eq "Archivo nuevo sin seguimiento (.theme) detectado" "$(origins web/modules/custom/demo/nuevo.theme)/$(has_finding web/modules/custom/demo/nuevo.theme)" "untracked/si"
expect_eq "Archivo con espacios analizado" "$(has_finding 'web/modules/custom/demo/mi archivo con espacios.php')" "si"
expect_eq "Archivo con tildes, ñ, #, & y paréntesis analizado" "$(has_finding 'web/modules/custom/demo/ñandú-ácido #1 & (copia).inc')" "si"
expect_eq "Errores en staged/unstaged/nuevos → código 1" "${RC}" "1"

reset_env
new_project comillas
printf '<?php\n$q = ;\n' > "${P}/web/modules/custom/demo/comillas\"dobles\\barra.php"
commit_all "Nombre que Git entrecomilla en el diff"
run_check
expect_eq "Ruta entrecomillada por Git (comillas y barra invertida) en commit" "$(has_finding 'web/modules/custom/demo/comillas"dobles\barra.php')" "si"

# ===========================================================================
section "Alcance --scope=all"
reset_env
new_project alcance
printf '<?php\n$ok = 1;\n' > "${P}/web/modules/custom/demo/otro.php"
commit_all "Cambio pequeño"
run_check --scope=all
expect_eq "--scope=all incluye archivos no modificados y su error queda como preexistente" "$(q 'in_array("web/modules/custom/legacy/legacy.inc", array_column($r["files"], "path")) ? count($c["code-standards"]["preexisting"]) : -1')/${RC}" "1/0"

# ===========================================================================
section "db-updates (Drush) [doble]"
reset_env
new_project dbupdates
cat > "${P}/web/modules/custom/demo/demo.install" <<'PHP'
<?php

/**
 * @file
 * Instalación.
 */

/**
 * Crea la tabla de ejemplo.
 */
function demo_update_10001() {
  return 'hecho';
}
PHP
commit_all "Nueva actualización"
printf '{"demo_update_10001":{"module":"demo","update_id":"10001","description":"Crea la tabla de ejemplo.","type":"hook_update_n"},"othermod_update_9001":{"module":"othermod","update_id":"9001","description":"Contrib.","type":"hook_update_n"}}' > "${WORK}/updb.json"
T_DRUSH="${FAKES}/drush"; export FAKE_DRUSH_UPDB="${WORK}/updb.json"
run_check --uri=http://sitio.ddev.site
expect_eq "Actualización introducida por la rama → FAIL con archivo y línea" "$(q '$c["db-updates"]["status"] . " " . $c["db-updates"]["findings"][0]["file"] . ":" . $c["db-updates"]["findings"][0]["line"] . " " . $c["db-updates"]["findings"][0]["function"]')" "FAIL web/modules/custom/demo/demo.install:11 demo_update_10001"
expect_eq "Actualización de otra rama/dependencia → advertencia" "$(q '$c["db-updates"]["findings"][1]["severity"] . " " . $c["db-updates"]["findings"][1]["file"]')" "warning web/modules/contrib/othermod/othermod.install"
if grep -q -- "updatedb:status --format=json --no-interaction --uri=http://sitio.ddev.site" "${WORK}/fake.log"; then pass "--uri se pasa a Drush (multisitio)"; else fail "--uri se pasa a Drush" "$(cat "${WORK}/fake.log")"; fi

printf '{"othermod_update_9001":{"module":"othermod","update_id":"9001","description":"Contrib.","type":"hook_update_n"}}' > "${WORK}/updb.json"
run_check
expect_eq "Solo advertencias → db-updates WARN y código 0" "$(q '$c["db-updates"]["status"]')/${RC}" "WARN/0"
run_check --fail-on=warn
expect_eq "--fail-on=warn con advertencias → código 1" "${RC}" "1"

export FAKE_DRUSH_EXIT=1
run_check
expect_eq "Drush instalado pero falla → OMITTED y código 2" "$(q '$c["db-updates"]["status"]')/${RC}" "OMITTED/2"
unset FAKE_DRUSH_EXIT

: > "${WORK}/fake.log"
run_check --checks=code-standards
if [ "$(q '$c["db-updates"]["status"] . $c["secrets-scan"]["status"]')" = "OMITTEDOMITTED" ] && ! grep -q "updatedb" "${WORK}/fake.log"; then
  pass "--checks=code-standards ejecuta solo esa validación"
else fail "--checks=code-standards"; fi

T_DRUSH="${NONE}"
run_check
expect_eq "Drush no instalado → db-updates OMITTED y continúa (código 0)" "$(q '$c["db-updates"]["status"]')/${RC}" "OMITTED/0"

# ===========================================================================
section "secrets-scan (Gitleaks)"
reset_env
new_project secretos
FAKE_SECRET="AKIAZZFAKESECRETVALUE9"
printf "<?php\n\$settings['api_key'] = '%s';\n" "${FAKE_SECRET}" > "${P}/web/modules/custom/demo/secret.php"
commit_all "Agrega credencial"
SHA="$(git -C "${P}" rev-parse HEAD)"; ADATE="$(git -C "${P}" log -1 --format=%aI)"
cat > "${WORK}/mkgl.php" <<'PHP'
<?php
// Genera el JSON que emitiría Gitleaks SIN --redact (peor caso) para probar
// que el validador enmascara el secreto igualmente.
[, $secret, $sha, $date] = $argv;
echo json_encode([[
    'Description' => 'Detected a Generic API Key', 'StartLine' => 2, 'EndLine' => 2,
    'StartColumn' => 13, 'EndColumn' => 50, 'Match' => "api_key'] = '{$secret}'",
    'Secret' => $secret, 'File' => 'web/modules/custom/demo/secret.php', 'Commit' => $sha,
    'Author' => 'Dev Pruebas Ñ', 'Email' => 'dev@example.com', 'Date' => $date,
    'RuleID' => 'generic-api-key', 'Fingerprint' => 'x',
]]);
PHP
"${PHP_BIN}" "${WORK}/mkgl.php" "${FAKE_SECRET}" "${SHA}" "${ADATE}" > "${WORK}/gl.json"
T_GITLEAKS="${FAKES}/gitleaks"; export FAKE_GITLEAKS_MODE=commits FAKE_GITLEAKS_JSON="${WORK}/gl.json"
run_check
expect_eq "[doble] Secreto en commit → secrets-scan FAIL y código 1" "$(q '$c["secrets-scan"]["status"]')/${RC}" "FAIL/1"
expect_eq "[doble] Hallazgo con archivo, línea, columna, regla, commit, autor y fecha" "$(q 'implode("|", array_map(fn($k) => $c["secrets-scan"]["findings"][0][$k], ["file","line","column","rule","commit","author","date"]))')" "web/modules/custom/demo/secret.php|2|13|generic-api-key|${SHA}|Dev Pruebas Ñ|${ADATE}"
if ! grep -qF "${FAKE_SECRET}" "${JSON}" "${JSON%.json}.md" && ! grep -qF "${FAKE_SECRET}" <<<"${OUT}" && grep -qF '****REDACTED****' "${JSON}"; then
  pass "[doble] El secreto nunca aparece en consola ni reportes (****REDACTED****)"
else fail "Secreto redactado"; fi
if grep -q "gitleaks git --log-opts=" "${WORK}/fake.log" && grep -q -- "--redact" "${WORK}/fake.log" && grep -q -- "--pre-commit --staged" "${WORK}/fake.log"; then
  pass "[doble] Gitleaks se invoca con --redact sobre commits, staged y unstaged"
else fail "Invocación de Gitleaks" "$(cat "${WORK}/fake.log")"; fi

printf "<?php\n\$x = 1;\n" > "${P}/web/modules/custom/demo/nuevo-secreto.php"
"${PHP_BIN}" -r 'echo json_encode([["Description"=>"Generic","StartLine"=>2,"StartColumn"=>1,"Match"=>"token = REDACTED","Secret"=>"REDACTED","File"=>"x","Commit"=>"","Author"=>"","Date"=>"","RuleID"=>"generic-api-key"]]);' > "${WORK}/gl2.json"
export FAKE_GITLEAKS_MODE=untracked FAKE_GITLEAKS_JSON="${WORK}/gl2.json"
run_check
expect_eq "[doble] Secreto en archivo nuevo: ruta real y commit 'sin commit'" "$(q '$c["secrets-scan"]["findings"][0]["file"] . "|" . $c["secrets-scan"]["findings"][0]["commit"] . "|" . $c["secrets-scan"]["findings"][0]["code"]')" "web/modules/custom/demo/nuevo-secreto.php|sin commit (archivo nuevo)|token = ****REDACTED****"

T_GITLEAKS="${NONE}"
run_check
expect_eq "Gitleaks no instalado → secrets-scan OMITTED y continúa" "$(q '$c["secrets-scan"]["status"]')/${RC}" "OMITTED/0"

if [ -n "${REAL_GITLEAKS}" ] && [ -x "${REAL_GITLEAKS}" ]; then
  reset_env
  new_project secretos-real
  # Clave privada ficticia con formato PEM: la regla private-key de Gitleaks la detecta.
  {
    printf -- '-----BEGIN RSA PRIVATE KEY-----\n'
    printf 'MIIEowIBAAKCAQEA7bq9vQ2xYr0dOq9U3hQ0hXk1y6s8Yq2Fv9mJk3pLr4tZw8NcQ\n'
    printf 'dGVzdGtleXRlc3RrZXl0ZXN0a2V5dGVzdGtleXRlc3RrZXl0ZXN0a2V5dGVzdGtl\n'
    printf -- '-----END RSA PRIVATE KEY-----\n'
  } > "${P}/web/modules/custom/demo/clave.pem"
  T_GITLEAKS="${REAL_GITLEAKS}"
  run_check --checks=secrets-scan
  if [ "$(q '$c["secrets-scan"]["status"]')" = "FAIL" ] && ! grep -q "dGVzdGtleXRlc3Rr" "${JSON}"; then
    pass "[real] Gitleaks detecta una clave privada en archivo nuevo y la redacta"
  else fail "[real] Gitleaks detecta secreto" "$(q '$c["secrets-scan"]["summary"]')"; fi
else
  skip "[real] Detección de secretos con Gitleaks real" "Gitleaks no está instalado"
fi

# ===========================================================================
section "phpcs (clasificación por línea) [doble]"
reset_env
new_project phpcs
printf "<?php\n\n/**\n * @file\n * Módulo de pruebas.\n */\n\nfunction demo_help() {\n    return 'mal indentado';\n}\n" > "${P}/web/modules/custom/demo/demo.module"
commit_all "Indentación"
T_PHPCS="${FAKES}/phpcs"; export FAKE_PHPCS="demo.module:9:5:ERROR:Drupal.WhiteSpace.ScopeIndent.IncorrectExact;demo.module:8:1:ERROR:Drupal.Commenting.FunctionComment.Missing"
run_check
expect_eq "[doble] phpcs: error en línea modificada es nuevo y el de línea no modificada es preexistente" "$(q '$c["code-standards"]["status"] . " " . $c["code-standards"]["findings"][0]["line"] . "/" . $c["code-standards"]["findings"][0]["rule"] . " " . $c["code-standards"]["preexisting"][0]["line"]')" "FAIL 9/Drupal.WhiteSpace.ScopeIndent.IncorrectExact 8"
if grep -q -- "--standard=Drupal,DrupalPractice" "${WORK}/fake.log"; then pass "[doble] Sin phpcs.xml.dist se usa Drupal,DrupalPractice"; else fail "Estándar por defecto"; fi
printf '<?xml version="1.0"?>\n<ruleset name="proyecto"><rule ref="Drupal"/></ruleset>\n' > "${P}/phpcs.xml.dist"
: > "${WORK}/fake.log"
run_check
if grep -q "^phpcs --report=json" "${WORK}/fake.log" && ! grep -q -- "--standard=" "${WORK}/fake.log"; then pass "[doble] Con phpcs.xml.dist se respeta la configuración del proyecto"; else fail "phpcs.xml.dist respetado" "$(cat "${WORK}/fake.log")"; fi
T_PHPCS="${NONE}"
run_check
expect_eq "phpcs no instalado → herramienta OMITTED y php -l sigue ejecutándose" "$(q 'implode(",", array_column($c["code-standards"]["tools"], "status", "name"))')" "PASS,PASS,OMITTED"

if [ -n "${REAL_PHPCS}" ] && "${REAL_PHPCS}" -i 2>/dev/null | grep -q Drupal; then
  rm -f "${P}/phpcs.xml.dist"
  T_PHPCS="${REAL_PHPCS}"
  run_check --checks=code-standards
  expect_eq "[real] phpcs + Drupal Coder detecta la indentación incorrecta en la línea modificada" "$(q 'in_array(9, array_column($c["code-standards"]["findings"], "line")) ? "si" : "no"')" "si"
else
  skip "[real] phpcs con Drupal Coder" "phpcs con el estándar Drupal no está instalado"
fi

# ===========================================================================
section "YAML (symfony/yaml)"
reset_env
new_project yaml
printf 'name: Demo\ntype: module\n  mal: [sangria\ncore_version_requirement: ^10\n' > "${P}/web/modules/custom/demo/demo.info.yml"
commit_all "YAML inválido"
run_check
expect_eq "Sin symfony/yaml → herramienta OMITTED y continúa" "$(q 'array_column($c["code-standards"]["tools"], "status", "name")["symfony/yaml"]')/${RC}" "OMITTED/0"

if [ -n "${REAL_YAML}" ] && [ -f "${REAL_YAML}" ]; then
  T_YAML="${REAL_YAML}"
  run_check
  expect_eq "[real] YAML inválido detectado por symfony/yaml → FAIL" "$(q '$c["code-standards"]["status"] . " " . $c["code-standards"]["findings"][0]["file"]')" "FAIL web/modules/custom/demo/demo.info.yml"
else
  skip "[real] YAML inválido con symfony/yaml real" "defina READINESS_TEST_YAML_AUTOLOAD=<proyecto>/vendor/autoload.php"
  # Contrato de la API de symfony/yaml (ParseException::getParsedLine) con un doble mínimo.
  mkdir -p "${P}/vendor/symfony/yaml"
  cat > "${P}/vendor/autoload.php" <<'PHP'
<?php
// Doble de prueba de symfony/yaml: falla en la primera línea con sangría inesperada.
namespace Symfony\Component\Yaml\Exception { class ParseException extends \RuntimeException {
  private int $l; public function __construct(string $m, int $l) { parent::__construct($m); $this->l = $l; }
  public function getParsedLine(): int { return $this->l; } } }
namespace Symfony\Component\Yaml { class Yaml { const PARSE_EXCEPTION_ON_INVALID_TYPE = 2; const PARSE_CUSTOM_TAGS = 512;
  public static function parse(string $s, int $f = 0) { foreach (explode("\n", $s) as $i => $line) {
    if ($i > 0 && preg_match('/^\s+\S/', $line) && !preg_match('/^\s+-|^\s+\w+:/', $line) || preg_match('/\[[^\]]*$/', $line)) {
      throw new Exception\ParseException("Unable to parse at line " . ($i + 1) . ".", $i + 1); } } return []; } } }
PHP
  run_check
  expect_eq "[doble] YAML inválido → FAIL con línea (contrato ParseException)" "$(q '$c["code-standards"]["status"] . " " . $c["code-standards"]["findings"][0]["file"] . ":" . $c["code-standards"]["findings"][0]["line"]')" "FAIL web/modules/custom/demo/demo.info.yml:3"
fi

# ===========================================================================
section "Validaciones opcionales (--all-checks)"
reset_env
new_project opcionales
printf 'module:\n  devel: 0\n  kint: 0\n  node: 0\n  system: 0\ntheme:\n  olivero: 0\n' > "${P}/config/sync/core.extension.yml"
commit_all "Habilita devel"
T_DRUSH="${FAKES}/drush"
printf '[{"name":"system.site","state":"Different"}]' > "${WORK}/cfg.json"; export FAKE_DRUSH_CONFIG="${WORK}/cfg.json"
run_check --all-checks
expect_eq "disallowed-modules: módulo prohibido habilitado por la rama → FAIL" "$(q '$c["disallowed-modules"]["status"] . " " . $c["disallowed-modules"]["findings"][0]["module"] . " " . $c["disallowed-modules"]["findings"][0]["line"]')" "FAIL devel 2"
expect_eq "disallowed-modules: módulo prohibido preexistente no bloquea" "$(q 'count($c["disallowed-modules"]["preexisting"]) . " " . $c["disallowed-modules"]["preexisting"][0]["module"]')" "1 kint"
expect_eq "[doble] config-status ejecutado con --all-checks → WARN por diferencias" "$(q '$c["config-status"]["status"]')" "WARN"
expect_eq "composer-audit sin composer.lock → OMITTED" "$(q '$c["composer-audit"]["status"]')" "OMITTED"

# ===========================================================================
section "Instalador (scripts/install.sh) y comando DDEV"
reset_env
new_project instalador
mkdir -p "${P}/.ddev"; printf 'name: prueba\ntype: drupal10\n' > "${P}/.ddev/config.yaml"
# PATH sin el binario ddev para no reiniciar nada real.
NODDEV_BIN="${WORK}/bin-sin-ddev"; mkdir -p "${NODDEV_BIN}"
for b in bash git sed grep cat mkdir chmod touch tr dirname head env; do
  bin_path="$(type -P "$b" || true)"
  [ -n "${bin_path}" ] && ln -sf "${bin_path}" "${NODDEV_BIN}/$b"
done
ln -sf "${PHP_ABS}" "${NODDEV_BIN}/php"
OUT="$(cd "${P}" && env PATH="${NODDEV_BIN}" bash drupal-readiness-check/scripts/install.sh --no-restart 2>&1)"; RC=$?
CMD="${P}/.ddev/commands/web/readiness-check"
if [ "${RC}" -eq 0 ] && [ -x "${CMD}" ] && grep -q '^TOOL_REL_DIR="drupal-readiness-check"$' "${CMD}"; then pass "install.sh registra el comando DDEV ejecutable con la ruta relativa"; else fail "install.sh registra el comando" "rc=${RC} ${OUT}"; fi
EXCL="${P}/.git/info/exclude"
if grep -qxF '/drupal-readiness-check/' "${EXCL}" && grep -qxF '/.ddev/commands/web/readiness-check' "${EXCL}" \
   && ! git -C "${P}" status --porcelain -uall | grep -qE 'drupal-readiness-check/|\.ddev/commands/'; then
  pass "install.sh excluye el validador y el comando en .git/info/exclude (no se suben)"
else fail "Exclusión en .git/info/exclude" "$(cat "${EXCL}")"; fi
(cd "${P}" && env PATH="${NODDEV_BIN}" bash drupal-readiness-check/scripts/install.sh --no-restart >/dev/null 2>&1)
expect_eq "install.sh es idempotente (sin entradas duplicadas)" "$(grep -cxF '/drupal-readiness-check/' "${EXCL}")" "1"
OUT="$(cd "${P}" && env PATH="${NODDEV_BIN}" bash "${CMD}" --demo --no-color 2>&1)"; RC=$?
if [ "${RC}" -eq 0 ] && grep -q "MODO DEMO" <<<"${OUT}"; then pass "El comando instalado ejecuta el validador (fuera del contenedor usa la raíz Git)"; else fail "Comando instalado" "rc=${RC} ${OUT}"; fi

# Validador ubicado en una ruta con espacios y caracteres especiales.
mkdir -p "${P}/herramientas ñ & co"
mv "${P}/drupal-readiness-check" "${P}/herramientas ñ & co/validador [qa]"
OUT="$(cd "${P}" && env PATH="${NODDEV_BIN}" bash "herramientas ñ & co/validador [qa]/scripts/install.sh" --no-restart 2>&1)"; RC=$?
if [ "${RC}" -eq 0 ] && grep -qF 'TOOL_REL_DIR="herramientas ñ & co/validador [qa]"' "${CMD}" && grep -qxF '/herramientas ñ & co/validador \[qa\]/' "${EXCL}" \
   && ! git -C "${P}" status --porcelain -uall | grep -q 'validador'; then
  pass "install.sh soporta rutas con espacios, tildes, & y corchetes"
else fail "install.sh con ruta especial" "rc=${RC} ${OUT} $(tail -3 "${EXCL}")"; fi
OUT="$(cd "${P}" && env PATH="${NODDEV_BIN}" READINESS_GITLEAKS="${NONE}" READINESS_DRUSH="${NONE}" READINESS_PHPCS="${NONE}" bash "${CMD}" --no-color 2>&1)"; RC=$?
if [ "${RC}" -eq 0 ] && ! grep -q "validador \[qa\]/" <<<"$(cat "${P}/herramientas ñ & co/validador [qa]/reports/"readiness-*.json 2>/dev/null | grep '"path"')"; then
  pass "Validador en ruta especial: se ejecuta y excluye sus propios archivos"
else fail "Ejecución desde ruta especial" "rc=${RC} ${OUT}"; fi

# ===========================================================================
printf '\n\033[1mResumen:\033[0m %d comprobaciones — %d PASS, %d FAIL, %d SKIP\n' "${N}" "${PASSED}" "${FAILED}" "${SKIPPED}"
if [ "${FAILED}" -gt 0 ]; then
  printf 'Fallidas:\n'
  printf '  - %s\n' "${FAILED_NAMES[@]}"
  exit 1
fi
exit 0
