<?php

/**
 * @file
 * Doble de prueba de phpcs (SOLO para tests/scenario-branch.sh).
 *
 * Emite el formato de `phpcs --report=json` con los mensajes definidos en
 * FAKE_PHPCS ("archivo-basename:línea:columna:ERROR|WARNING:Regla;…"), para
 * probar la clasificación por líneas modificadas. Los estándares Drupal reales
 * solo se prueban con phpcs + Drupal Coder instalados.
 */

$args = array_slice($argv, 1);
if ($log = getenv('FAKE_LOG')) {
    file_put_contents($log, 'phpcs ' . implode(' ', $args) . "\n", FILE_APPEND);
}
if (in_array('-i', $args, true)) {
    echo "The installed coding standards are MySource, PEAR, PSR1, PSR2, PSR12, Squiz, Zend, Drupal and DrupalPractice\n";
    exit(0);
}
$specs = [];
foreach (array_filter(explode(';', (string) getenv('FAKE_PHPCS'))) as $spec) {
    [$base, $line, $column, $type, $source] = explode(':', $spec, 5);
    $specs[$base][] = ['line' => (int) $line, 'column' => (int) $column, 'type' => $type, 'source' => $source];
}
$files = [];
$errors = 0;
foreach ($args as $arg) {
    if (str_starts_with($arg, '-')) {
        continue;
    }
    $messages = [];
    foreach ($specs[basename($arg)] ?? [] as $s) {
        $messages[] = [
            'message' => 'Mensaje simulado de ' . $s['source'],
            'source' => $s['source'],
            'severity' => 5,
            'fixable' => false,
            'type' => $s['type'],
            'line' => $s['line'],
            'column' => $s['column'],
        ];
        $errors++;
    }
    $files[$arg] = ['errors' => count($messages), 'warnings' => 0, 'messages' => $messages];
}
echo json_encode(['totals' => ['errors' => $errors, 'warnings' => 0, 'fixable' => 0], 'files' => $files]);
exit($errors > 0 ? 1 : 0);
