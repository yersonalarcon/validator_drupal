<?php

/**
 * @file
 * Doble de prueba de Drush (SOLO para tests/scenario-branch.sh).
 *
 * Reproduce el contrato de salida de `drush updatedb:status --format=json` y
 * `drush config:status --format=json` a partir de archivos preparados por la
 * prueba. Nunca lo usa el validador fuera de las pruebas.
 *
 * Variables: FAKE_LOG, FAKE_DRUSH_UPDB (ruta JSON), FAKE_DRUSH_CONFIG (ruta JSON),
 *            FAKE_DRUSH_EXIT (código de salida forzado).
 */

$args = array_slice($argv, 1);
if ($log = getenv('FAKE_LOG')) {
    file_put_contents($log, 'drush ' . implode(' ', $args) . "\n", FILE_APPEND);
}
$exit = (int) (getenv('FAKE_DRUSH_EXIT') ?: 0);
if ($exit !== 0) {
    fwrite(STDERR, "[error] SQLSTATE[HY000] [2002] Connection refused (simulado)\n");
    exit($exit);
}
$command = $args[0] ?? '';
$source = match ($command) {
    'updatedb:status' => getenv('FAKE_DRUSH_UPDB'),
    'config:status' => getenv('FAKE_DRUSH_CONFIG'),
    default => false,
};
if ($source && is_file($source)) {
    echo file_get_contents($source);
} else {
    fwrite(STDERR, " [success] No database updates required.\n");
}
exit(0);
