<?php

/**
 * @file
 * Doble de prueba de Gitleaks (SOLO para tests/scenario-branch.sh).
 *
 * Escribe en --report-path el JSON preparado por la prueba únicamente para el
 * modo de escaneo indicado en FAKE_GITLEAKS_MODE (commits, staged, unstaged,
 * untracked). Sirve para probar el mapeo de campos y la redacción; la
 * detección real de secretos solo se prueba con Gitleaks instalado.
 *
 * Variables: FAKE_LOG, FAKE_GITLEAKS_MODE, FAKE_GITLEAKS_JSON (ruta).
 */

$args = array_slice($argv, 1);
if ($log = getenv('FAKE_LOG')) {
    file_put_contents($log, 'gitleaks ' . implode(' ', $args) . "\n", FILE_APPEND);
}
if (($args[0] ?? '') === 'version') {
    echo "8.28.0\n";
    exit(0);
}
if (in_array('dir', $args, true)) {
    $mode = 'untracked';
} elseif (in_array('--staged', $args, true)) {
    $mode = 'staged';
} elseif (in_array('--pre-commit', $args, true)) {
    $mode = 'unstaged';
} else {
    $mode = 'commits';
}
$report = null;
foreach ($args as $arg) {
    if (str_starts_with($arg, '--report-path=')) {
        $report = substr($arg, strlen('--report-path='));
    }
}
if ($report === null) {
    fwrite(STDERR, "falta --report-path\n");
    exit(1);
}
$json = '[]';
$source = getenv('FAKE_GITLEAKS_JSON');
if (getenv('FAKE_GITLEAKS_MODE') === $mode && $source && is_file($source)) {
    $json = (string) file_get_contents($source);
}
file_put_contents($report, $json);
exit(0);
