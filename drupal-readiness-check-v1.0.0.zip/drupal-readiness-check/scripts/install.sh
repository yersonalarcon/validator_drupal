#!/usr/bin/env bash
#
# Instala el comando "ddev readiness-check" en el proyecto Drupal que contiene
# este directorio.
#
# Uso (desde el host, en cualquier directorio):
#   bash drupal-readiness-check/scripts/install.sh [--no-restart] [--force]
#
# Qué hace:
#   1. Da permisos de ejecución a los scripts del validador.
#   2. Copia ddev-commands/web/readiness-check a .ddev/commands/web/.
#   3. Añade el validador y el comando a .git/info/exclude (no se suben al repo).
#   4. Reinicia DDEV si el comando es nuevo o cambió y el proyecto está en marcha.
#
# No modifica archivos de Drupal ni archivos versionados del repositorio.

set -euo pipefail

NO_RESTART=0
FORCE=0
for arg in "$@"; do
  case "$arg" in
    --no-restart) NO_RESTART=1 ;;
    --force) FORCE=1 ;;
    -h|--help)
      sed -n '2,16p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *) echo "Opción desconocida: $arg" >&2; exit 2 ;;
  esac
done

info() { printf '  \033[32m✔\033[0m %s\n' "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*" >&2; }
fail() { printf '  \033[31m✘\033[0m %s\n' "$*" >&2; exit 2; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
TOOL_DIR="$(cd "${SCRIPT_DIR}/.." && pwd -P)"

# Raíz del proyecto: la raíz Git que contiene el validador o, si no hay Git,
# el directorio padre del validador.
if PROJECT_ROOT="$(git -C "${TOOL_DIR}" rev-parse --show-toplevel 2>/dev/null)"; then
  PROJECT_ROOT="$(cd "${PROJECT_ROOT}" && pwd -P)"
  HAS_GIT=1
else
  PROJECT_ROOT="$(cd "${TOOL_DIR}/.." && pwd -P)"
  HAS_GIT=0
fi

case "${TOOL_DIR}/" in
  "${PROJECT_ROOT}/"*) ;;
  *) fail "El validador debe estar dentro del proyecto Drupal (${PROJECT_ROOT})." ;;
esac
TOOL_REL="${TOOL_DIR#"${PROJECT_ROOT}/"}"

echo "Instalando drupal-readiness-check"
echo "  Proyecto:   ${PROJECT_ROOT}"
echo "  Validador:  ${TOOL_REL}/"

if [ ! -f "${PROJECT_ROOT}/.ddev/config.yaml" ]; then
  fail "No se encontró .ddev/config.yaml en ${PROJECT_ROOT}. Ejecute 'ddev config' primero."
fi

# 1. Permisos de ejecución.
chmod +x "${TOOL_DIR}/bin/readiness-check" "${TOOL_DIR}/bin/yaml-lint" \
  "${TOOL_DIR}/ddev-commands/web/readiness-check" \
  "${TOOL_DIR}"/scripts/*.sh "${TOOL_DIR}"/tests/*.sh
info "Permisos de ejecución asignados."

# 2. Registro del comando DDEV.
COMMAND_DIR="${PROJECT_ROOT}/.ddev/commands/web"
TARGET="${COMMAND_DIR}/readiness-check"
TEMPLATE="${TOOL_DIR}/ddev-commands/web/readiness-check"
mkdir -p "${COMMAND_DIR}"

if [ -f "${TARGET}" ] && ! grep -q 'drupal-readiness-check' "${TARGET}" && [ "${FORCE}" -ne 1 ]; then
  fail "Ya existe ${TARGET} y no pertenece a este validador. Use --force para reemplazarlo."
fi

# Sustitución literal (sin sed) para soportar espacios, tildes y '&' en la ruta.
# En Bash >= 5.2, '&' en el reemplazo equivale al texto encontrado: se desactiva.
shopt -u patsub_replacement 2>/dev/null || true
TEMPLATE_CONTENT="$(cat "${TEMPLATE}")"
PLACEHOLDER="__READINESS_TOOL_DIR__"
ESCAPED_REL="${TOOL_REL//\\/\\\\}"
ESCAPED_REL="${ESCAPED_REL//\"/\\\"}"
ESCAPED_REL="${ESCAPED_REL//\$/\\\$}"
ESCAPED_REL="${ESCAPED_REL//\`/\\\`}"
RENDERED="${TEMPLATE_CONTENT//${PLACEHOLDER}/${ESCAPED_REL}}"

CHANGED=1
if [ -f "${TARGET}" ] && [ "$(cat "${TARGET}")" = "${RENDERED}" ]; then
  CHANGED=0
fi
if [ "${CHANGED}" -eq 1 ]; then
  printf '%s\n' "${RENDERED}" > "${TARGET}"
  info "Comando registrado en .ddev/commands/web/readiness-check"
else
  info "El comando DDEV ya estaba registrado y actualizado."
fi
chmod +x "${TARGET}"

# 3. Excluir del repositorio (solo afecta a este clon, no se versiona).
escape_pattern() {
  # Escapa los caracteres especiales de los patrones de gitignore.
  printf '%s' "$1" | sed -e 's/[][*?!#\\]/\\&/g'
}
if [ "${HAS_GIT}" -eq 1 ]; then
  EXCLUDE_FILE="$(git -C "${PROJECT_ROOT}" rev-parse --git-path info/exclude)"
  case "${EXCLUDE_FILE}" in
    /*) ;;
    *) EXCLUDE_FILE="${PROJECT_ROOT}/${EXCLUDE_FILE}" ;;
  esac
  mkdir -p "$(dirname "${EXCLUDE_FILE}")"
  touch "${EXCLUDE_FILE}"
  for pattern in "/$(escape_pattern "${TOOL_REL}")/" "/.ddev/commands/web/readiness-check"; do
    if ! grep -qxF -- "${pattern}" "${EXCLUDE_FILE}"; then
      if ! grep -qxF '# drupal-readiness-check (local, no versionar)' "${EXCLUDE_FILE}"; then
        printf '\n# drupal-readiness-check (local, no versionar)\n' >> "${EXCLUDE_FILE}"
      fi
      printf '%s\n' "${pattern}" >> "${EXCLUDE_FILE}"
    fi
  done
  info "Rutas añadidas a .git/info/exclude."

  TRACKED="$(git -C "${PROJECT_ROOT}" ls-files -- "${TOOL_REL}" ".ddev/commands/web/readiness-check" | head -n 5)"
  if [ -n "${TRACKED}" ]; then
    warn "Algunos archivos del validador ya están versionados; .git/info/exclude no los retira:"
    printf '%s\n' "${TRACKED}" | while IFS= read -r tracked; do printf '      %s\n' "${tracked}" >&2; done
    warn "Si no deben subirse, ejecute: git rm -r --cached \"${TOOL_REL}\" .ddev/commands/web/readiness-check"
  fi
else
  warn "El proyecto no es un repositorio Git: no se actualizó .git/info/exclude."
fi

# 4. Reinicio de DDEV si es necesario.
if command -v ddev >/dev/null 2>&1; then
  RUNNING=0
  if (cd "${PROJECT_ROOT}" && ddev describe -j 2>/dev/null | tr -d ' \n' | grep -q '"status":"running"'); then
    RUNNING=1
  fi
  if [ "${CHANGED}" -eq 1 ] && [ "${RUNNING}" -eq 1 ] && [ "${NO_RESTART}" -ne 1 ]; then
    info "Reiniciando DDEV para registrar el comando…"
    (cd "${PROJECT_ROOT}" && ddev restart)
  elif [ "${RUNNING}" -eq 0 ]; then
    info "DDEV no está en marcha; el comando estará disponible tras 'ddev start'."
  fi
else
  warn "No se encontró el binario 'ddev' en este equipo (¿se está ejecutando dentro del contenedor?)."
fi

if [ ! -x "${TOOL_DIR}/bin/gitleaks" ] && ! command -v gitleaks >/dev/null 2>&1; then
  warn "Gitleaks no está instalado. Para habilitar secrets-scan ejecute:"
  warn "  bash \"${TOOL_REL}/scripts/install-gitleaks.sh\""
fi

echo
echo "Listo. Pruebe con:"
echo "  ddev readiness-check --demo"
echo "  ddev readiness-check"
