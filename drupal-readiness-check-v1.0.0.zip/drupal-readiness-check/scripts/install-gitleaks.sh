#!/usr/bin/env bash
#
# Descarga Gitleaks en drupal-readiness-check/bin/gitleaks (ignorado por Git).
#
# Uso:
#   bash drupal-readiness-check/scripts/install-gitleaks.sh [--force] [--host]
#
#   --force  Reinstala aunque ya exista la misma versión.
#   --host   Instala para el sistema actual en vez de para el contenedor DDEV.
#
# Por defecto, si se ejecuta en el host y DDEV está disponible, el script se
# vuelve a lanzar dentro del contenedor web (ddev exec), porque el validador
# se ejecuta allí y el binario debe ser de Linux.
#
# Variables:
#   GITLEAKS_VERSION  Versión a instalar (por defecto 8.28.0).
#
# El archivo descargado se verifica con el checksums.txt publicado en la release.

set -euo pipefail

GITLEAKS_VERSION="${GITLEAKS_VERSION:-8.28.0}"
GITLEAKS_VERSION="${GITLEAKS_VERSION#v}"
FORCE=0
HOST=0
for arg in "$@"; do
  case "$arg" in
    --force) FORCE=1 ;;
    --host) HOST=1 ;;
    -h|--help) sed -n '2,18p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Opción desconocida: $arg" >&2; exit 2 ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
TOOL_DIR="$(cd "${SCRIPT_DIR}/.." && pwd -P)"
TARGET="${TOOL_DIR}/bin/gitleaks"

# Reejecutar dentro del contenedor web de DDEV cuando se lanza desde el host.
if [ "${HOST}" -eq 0 ] && [ "${IS_DDEV_PROJECT:-}" != "true" ] && command -v ddev >/dev/null 2>&1; then
  PROJECT_ROOT="$(git -C "${TOOL_DIR}" rev-parse --show-toplevel 2>/dev/null || (cd "${TOOL_DIR}/.." && pwd -P))"
  PROJECT_ROOT="$(cd "${PROJECT_ROOT}" && pwd -P)"
  TOOL_REL="${TOOL_DIR#"${PROJECT_ROOT}/"}"
  echo "Instalando Gitleaks dentro del contenedor web de DDEV…"
  ARGS=()
  [ "${FORCE}" -eq 1 ] && ARGS+=("--force")
  cd "${PROJECT_ROOT}"
  exec ddev exec env GITLEAKS_VERSION="${GITLEAKS_VERSION}" bash "/var/www/html/${TOOL_REL}/scripts/install-gitleaks.sh" --host ${ARGS[@]+"${ARGS[@]}"}
fi

case "$(uname -s)" in
  Linux) OS="linux" ;;
  Darwin) OS="darwin" ;;
  *) echo "Sistema operativo no soportado: $(uname -s)" >&2; exit 2 ;;
esac
case "$(uname -m)" in
  x86_64|amd64) ARCH="x64" ;;
  aarch64|arm64) ARCH="arm64" ;;
  armv7l) ARCH="armv7" ;;
  *) echo "Arquitectura no soportada: $(uname -m)" >&2; exit 2 ;;
esac

if [ -x "${TARGET}" ] && [ "${FORCE}" -ne 1 ]; then
  CURRENT="$("${TARGET}" version 2>/dev/null || true)"
  if [ "${CURRENT#v}" = "${GITLEAKS_VERSION}" ]; then
    echo "Gitleaks ${GITLEAKS_VERSION} ya está instalado en ${TARGET}."
    exit 0
  fi
fi

ASSET="gitleaks_${GITLEAKS_VERSION}_${OS}_${ARCH}.tar.gz"
CHECKSUMS="gitleaks_${GITLEAKS_VERSION}_checksums.txt"
BASE_URL="https://github.com/gitleaks/gitleaks/releases/download/v${GITLEAKS_VERSION}"

TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/gitleaks-install.XXXXXX")"
trap 'rm -rf "${TMP_DIR}"' EXIT

download() {
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL --retry 2 -o "$2" "$1"
  elif command -v wget >/dev/null 2>&1; then
    wget -q -O "$2" "$1"
  else
    echo "Se necesita curl o wget para descargar Gitleaks." >&2
    exit 2
  fi
}

echo "Descargando ${ASSET}…"
download "${BASE_URL}/${ASSET}" "${TMP_DIR}/${ASSET}"
download "${BASE_URL}/${CHECKSUMS}" "${TMP_DIR}/${CHECKSUMS}"

EXPECTED="$(grep " ${ASSET}\$" "${TMP_DIR}/${CHECKSUMS}" | awk '{print $1}')"
if [ -z "${EXPECTED}" ]; then
  echo "No se encontró el checksum de ${ASSET} en ${CHECKSUMS}." >&2
  exit 2
fi
if command -v sha256sum >/dev/null 2>&1; then
  ACTUAL="$(sha256sum "${TMP_DIR}/${ASSET}" | awk '{print $1}')"
else
  ACTUAL="$(shasum -a 256 "${TMP_DIR}/${ASSET}" | awk '{print $1}')"
fi
if [ "${EXPECTED}" != "${ACTUAL}" ]; then
  echo "El checksum no coincide: esperado ${EXPECTED}, obtenido ${ACTUAL}." >&2
  exit 2
fi

tar -xzf "${TMP_DIR}/${ASSET}" -C "${TMP_DIR}" gitleaks
mkdir -p "$(dirname "${TARGET}")"
mv "${TMP_DIR}/gitleaks" "${TARGET}"
chmod +x "${TARGET}"

echo "Gitleaks instalado: $("${TARGET}" version)"
echo "Ubicación: ${TARGET#"${TOOL_DIR}/"} (ignorado por Git)"
