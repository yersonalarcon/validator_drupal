<?php

declare(strict_types=1);

namespace ReadinessCheck;

use ReadinessCheck\Check\CheckContext;
use ReadinessCheck\Check\CheckInterface;
use ReadinessCheck\Check\CheckResult;
use ReadinessCheck\Check\CodeStandardsCheck;
use ReadinessCheck\Check\ComposerAuditCheck;
use ReadinessCheck\Check\ConfigStatusCheck;
use ReadinessCheck\Check\DbUpdatesCheck;
use ReadinessCheck\Check\DisallowedModulesCheck;
use ReadinessCheck\Check\SecretsScanCheck;
use ReadinessCheck\Check\Status;
use ReadinessCheck\Demo\DemoReport;
use ReadinessCheck\Exception\ConfigurationException;
use ReadinessCheck\Exception\ExecutionException;
use ReadinessCheck\Exception\ToolExecutionException;
use ReadinessCheck\Git\ChangedFile;
use ReadinessCheck\Git\ChangeSet;
use ReadinessCheck\Git\GitRepository;
use ReadinessCheck\Report\ConsoleRenderer;
use ReadinessCheck\Report\ReportWriter;
use ReadinessCheck\Support\Redactor;
use ReadinessCheck\Support\ToolLocator;

/**
 * Orquesta una ejecución completa del validador.
 */
final class Application
{
    public const VERSION = '1.0.0';

    public const EXIT_OK = 0;
    public const EXIT_FAIL = 1;
    public const EXIT_ERROR = 2;

    /** Orden de ejecución: secrets-scan primero para enmascarar sus líneas en el resto. */
    private const EXECUTION_ORDER = ['secrets-scan', 'db-updates', 'code-standards', 'config-status', 'composer-audit', 'disallowed-modules'];

    public function __construct(private string $toolRoot)
    {
    }

    /**
     * @param list<string> $argv
     */
    public function run(array $argv, string $cwd): int
    {
        $stdout = STDOUT;
        $stderr = STDERR;
        try {
            $settings = $this->loadSettings();
            $checks = $this->checks();
            $options = Options::fromArgv($argv, array_keys($checks));
        } catch (ConfigurationException $e) {
            fwrite($stderr, 'Error de configuración: ' . $e->getMessage() . "\n");
            return self::EXIT_ERROR;
        }

        if ($options->help) {
            fwrite($stdout, Options::helpText());
            return self::EXIT_OK;
        }

        $colors = !$options->noColor && getenv('NO_COLOR') === false && function_exists('posix_isatty') && @posix_isatty($stdout);
        $console = new ConsoleRenderer($colors);
        $reportWriter = new ReportWriter($this->toolRoot . '/reports');

        try {
            if ($options->demo) {
                $report = DemoReport::build(self::VERSION);
                $paths = $reportWriter->write($report, 'demo');
                fwrite($stdout, $console->render($report, $paths, $cwd));
                return self::EXIT_OK;
            }

            $git = GitRepository::discover($cwd);
            $excludes = $this->excludePrefixes($git->root(), $settings);
            $changes = ChangeSet::build(
                $git,
                $options->base,
                $settings['base_candidates'],
                (string) $settings['remote'],
                $options->scope,
                $excludes
            );

            $context = new CheckContext(
                $options,
                $changes,
                $settings,
                new ToolLocator($git->root(), $this->toolRoot),
                new Redactor(),
                $this->toolRoot,
                $excludes
            );

            $selected = $this->selectChecks($options, $settings);
            $results = $this->runChecks($checks, $selected, $context);
            $report = $this->buildReport($context, $selected, $results);
            $paths = $reportWriter->write($report, substr($changes->headCommit, 0, 12));
            fwrite($stdout, $console->render($report, $paths, $git->root()));
            return (int) $report['result']['exit_code'];
        } catch (ConfigurationException $e) {
            fwrite($stderr, 'Error de configuración: ' . $e->getMessage() . "\n");
            return self::EXIT_ERROR;
        } catch (ExecutionException $e) {
            fwrite($stderr, 'Error de ejecución: ' . $e->getMessage() . "\n");
            return self::EXIT_ERROR;
        } catch (\Throwable $e) {
            fwrite($stderr, 'Error inesperado: ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ")\n");
            return self::EXIT_ERROR;
        }
    }

    /**
     * @return array<string, CheckInterface>
     */
    private function checks(): array
    {
        $list = [
            new DbUpdatesCheck(),
            new CodeStandardsCheck(),
            new SecretsScanCheck(),
            new ConfigStatusCheck(),
            new ComposerAuditCheck(),
            new DisallowedModulesCheck(),
        ];
        $checks = [];
        foreach ($list as $check) {
            $checks[$check->id()] = $check;
        }
        return $checks;
    }

    /**
     * @return array<string, mixed>
     */
    private function loadSettings(): array
    {
        $file = $this->toolRoot . '/config/settings.php';
        if (!is_file($file)) {
            throw new ConfigurationException('No se encontró config/settings.php del validador.');
        }
        $settings = require $file;
        if (!is_array($settings)) {
            throw new ConfigurationException('config/settings.php debe devolver un array.');
        }
        foreach (['base_candidates', 'default_checks', 'optional_checks', 'php_extensions', 'yaml_extensions', 'phpcs_project_configs'] as $key) {
            if (!isset($settings[$key]) || !is_array($settings[$key])) {
                throw new ConfigurationException("config/settings.php: falta la clave '{$key}' o no es una lista.");
            }
        }
        $settings['remote'] = $settings['remote'] ?? 'origin';
        $settings['exclude_paths'] = $settings['exclude_paths'] ?? [];
        return $settings;
    }

    /**
     * El directorio del validador y el comando DDEV instalado nunca se analizan.
     *
     * @param array<string, mixed> $settings
     * @return list<string>
     */
    private function excludePrefixes(string $repoRoot, array $settings): array
    {
        $prefixes = [];
        $toolReal = realpath($this->toolRoot);
        if ($toolReal !== false && str_starts_with($toolReal . '/', $repoRoot . '/') && $toolReal !== $repoRoot) {
            $prefixes[] = substr($toolReal, strlen($repoRoot) + 1);
        }
        foreach ($settings['exclude_paths'] as $path) {
            $prefixes[] = trim((string) $path, '/');
        }
        return array_values(array_unique(array_filter($prefixes, 'strlen')));
    }

    /**
     * @param array<string, mixed> $settings
     * @return list<string>
     */
    private function selectChecks(Options $options, array $settings): array
    {
        if ($options->checks !== null) {
            return $options->checks;
        }
        if ($options->allChecks) {
            return array_values(array_unique(array_merge($settings['default_checks'], $settings['optional_checks'])));
        }
        return array_values($settings['default_checks']);
    }

    /**
     * @param array<string, CheckInterface> $checks
     * @param list<string> $selected
     * @return array<string, CheckResult>
     */
    private function runChecks(array $checks, array $selected, CheckContext $context): array
    {
        $results = [];
        $order = array_merge(self::EXECUTION_ORDER, array_diff(array_keys($checks), self::EXECUTION_ORDER));
        foreach ($order as $id) {
            if (!isset($checks[$id])) {
                continue;
            }
            $check = $checks[$id];
            if (!in_array($id, $selected, true)) {
                $results[$id] = CheckResult::omitted(
                    $id,
                    $check->title(),
                    in_array($id, $context->settings['optional_checks'], true)
                        ? "Validación opcional no seleccionada (use --all-checks o --checks={$id})."
                        : 'Validación no seleccionada en --checks.'
                );
                continue;
            }
            $start = microtime(true);
            try {
                $result = $check->run($context);
            } catch (ToolExecutionException $e) {
                $result = CheckResult::omitted($id, $check->title(), 'Error de ejecución: ' . Redactor::maskSensitiveAssignments($e->getMessage()));
                $result->notes[] = 'La herramienta está instalada pero no pudo ejecutarse; el resultado de esta validación es desconocido.';
                $result->executionError = true;
            }
            $result->durationMs = (microtime(true) - $start) * 1000;
            $results[$id] = $result;
        }

        // Orden de presentación estable.
        $ordered = [];
        foreach (array_keys($checks) as $id) {
            $ordered[$id] = $results[$id];
        }
        return $ordered;
    }

    /**
     * @param list<string> $selected
     * @param array<string, CheckResult> $results
     * @return array<string, mixed>
     */
    private function buildReport(CheckContext $context, array $selected, array $results): array
    {
        $changes = $context->changes;
        $options = $context->options;

        $statuses = [];
        $executionErrors = 0;
        foreach ($results as $result) {
            $statuses[] = $result->status;
            if ($result->executionError) {
                $executionErrors++;
            }
        }
        $global = Status::worst($statuses);
        if ($global === Status::OMITTED) {
            $global = Status::PASS;
        }

        if ($global === Status::FAIL) {
            $exit = self::EXIT_FAIL;
            $message = 'La rama NO está lista: hay errores que bloquean la creación del Pull Request.';
        } elseif ($executionErrors > 0) {
            $exit = self::EXIT_ERROR;
            $message = 'No se pudo completar la validación: una o más herramientas fallaron al ejecutarse (ver OMITTED).';
        } elseif ($global === Status::WARN && $options->failOn === Options::FAIL_ON_WARN) {
            $exit = self::EXIT_FAIL;
            $message = 'Hay advertencias y se indicó --fail-on=warn.';
        } elseif ($global === Status::WARN) {
            $exit = self::EXIT_OK;
            $message = 'La rama puede continuar, pero revise las advertencias.';
        } else {
            $exit = self::EXIT_OK;
            $message = 'La rama está lista según las validaciones ejecutadas.';
        }
        $omitted = array_keys(array_filter($results, static fn (CheckResult $r): bool => $r->status === Status::OMITTED && in_array($r->id, $selected, true)));
        if ($omitted !== []) {
            $message .= ' Validaciones omitidas: ' . implode(', ', $omitted) . '.';
        }

        $files = array_map(static fn (ChangedFile $f): array => $f->toArray(), array_values($changes->files()));

        return [
            'tool' => ['name' => 'drupal-readiness-check', 'version' => self::VERSION],
            'mode' => 'real',
            'generated_at' => date('c'),
            'project' => [
                'root' => basename($context->projectRoot()),
                'commit' => $changes->headCommit,
                'commit_short' => substr($changes->headCommit, 0, 12),
                'branch' => $changes->branch,
                'base' => $changes->base,
                'base_commit' => $changes->baseCommit,
                'merge_base' => $changes->mergeBase,
                'scope' => $options->scope,
                'uri' => $options->uri,
                'fail_on' => $options->failOn,
                'checks' => $selected,
            ],
            'commits' => $changes->commits,
            'files' => $files,
            'excluded_files' => $changes->excludedPaths(),
            'checks' => array_values(array_map(static fn (CheckResult $r): array => $r->toArray(), $results)),
            'result' => [
                'status' => $global,
                'exit_code' => $exit,
                'message' => $message,
                'execution_errors' => $executionErrors,
            ],
        ];
    }
}
