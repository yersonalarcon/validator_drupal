<?php

declare(strict_types=1);

namespace ReadinessCheck\Git;

/**
 * Archivo considerado por el validador junto con sus líneas modificadas.
 */
final class ChangedFile
{
    public const ORIGIN_COMMITTED = 'committed';
    public const ORIGIN_STAGED = 'staged';
    public const ORIGIN_UNSTAGED = 'unstaged';
    public const ORIGIN_UNTRACKED = 'untracked';
    public const ORIGIN_UNCHANGED = 'unchanged';

    /** @var array<int, true> */
    private array $lines = [];

    /** @var list<string> */
    private array $origins = [];

    /**
     * @param string $path Ruta relativa a la raíz del repositorio.
     * @param bool $newFile El archivo no existía en el merge-base.
     * @param bool $allLinesChanged Todas las líneas se consideran modificadas.
     * @param string|null $basePath Ruta en el merge-base (renombrados).
     */
    public function __construct(
        public string $path,
        public bool $newFile = false,
        public bool $allLinesChanged = false,
        public ?string $basePath = null
    ) {
    }

    public function addLine(int $line): void
    {
        $this->lines[$line] = true;
    }

    public function addOrigin(string $origin): void
    {
        if (!in_array($origin, $this->origins, true)) {
            $this->origins[] = $origin;
        }
    }

    /** @return list<string> */
    public function origins(): array
    {
        return $this->origins === [] ? [self::ORIGIN_UNCHANGED] : $this->origins;
    }

    public function isLineChanged(?int $line): bool
    {
        if ($this->allLinesChanged) {
            return true;
        }
        return $line !== null && isset($this->lines[$line]);
    }

    public function hasChanges(): bool
    {
        return $this->allLinesChanged || $this->lines !== [] || $this->origins !== [];
    }

    public function changedLineCount(): ?int
    {
        return $this->allLinesChanged ? null : count($this->lines);
    }

    /** @return list<int> */
    public function changedLines(): array
    {
        $lines = array_keys($this->lines);
        sort($lines);
        return $lines;
    }

    public function extension(): string
    {
        $base = basename($this->path);
        if (str_ends_with($base, '.post_update.php')) {
            return 'php';
        }
        $pos = strrpos($base, '.');
        return $pos === false ? '' : strtolower(substr($base, $pos + 1));
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'path' => $this->path,
            'origins' => $this->origins(),
            'new_file' => $this->newFile,
            'changed_lines' => $this->allLinesChanged ? 'all' : $this->compactRanges(),
        ];
    }

    /**
     * Representa las líneas como rangos legibles: "3-5,9".
     */
    public function compactRanges(): string
    {
        $lines = $this->changedLines();
        if ($lines === []) {
            return '';
        }
        $ranges = [];
        $start = $prev = $lines[0];
        foreach (array_slice($lines, 1) as $line) {
            if ($line === $prev + 1) {
                $prev = $line;
                continue;
            }
            $ranges[] = $start === $prev ? (string) $start : "{$start}-{$prev}";
            $start = $prev = $line;
        }
        $ranges[] = $start === $prev ? (string) $start : "{$start}-{$prev}";
        return implode(',', $ranges);
    }
}
