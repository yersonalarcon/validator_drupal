<?php

declare(strict_types=1);

namespace ReadinessCheck\Git;

/**
 * Interpreta la salida de `git diff -U0` para obtener las líneas añadidas o
 * modificadas de cada archivo (numeración del archivo resultante).
 */
final class DiffParser
{
    /**
     * @return list<array{path: ?string, oldPath: ?string, new: bool, lines: list<int>}>
     */
    public static function parse(string $diff): array
    {
        $files = [];
        $current = null;

        foreach (preg_split('/\n/', $diff) ?: [] as $line) {
            if (str_starts_with($line, 'diff --git ')) {
                if ($current !== null) {
                    $files[] = $current;
                }
                $current = ['path' => null, 'oldPath' => null, 'new' => false, 'lines' => [], 'headerPath' => null];
                $current['headerPath'] = self::pathFromDiffHeader($line);
                continue;
            }
            if ($current === null) {
                continue;
            }
            if (!empty($current['inHunk'])) {
                // Dentro de un hunk solo interesan las nuevas cabeceras @@.
                if (preg_match('/^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@/', $line, $m)) {
                    self::addRange($current, $m);
                }
                continue;
            }
            if (str_starts_with($line, 'new file mode')) {
                $current['new'] = true;
                continue;
            }
            if (str_starts_with($line, 'rename from ')) {
                $current['oldPath'] = self::unquote(substr($line, 12));
                continue;
            }
            if (str_starts_with($line, 'rename to ')) {
                $current['path'] = self::unquote(substr($line, 10));
                continue;
            }
            if (str_starts_with($line, '--- ')) {
                $old = substr($line, 4);
                if ($old !== '/dev/null' && $current['oldPath'] === null) {
                    $current['oldPath'] = self::stripPrefix(self::unquote($old), 'a/');
                }
                continue;
            }
            if (str_starts_with($line, '+++ ')) {
                $new = substr($line, 4);
                $current['path'] = $new === '/dev/null' ? null : self::stripPrefix(self::unquote($new), 'b/');
                $current['deleted'] = $new === '/dev/null';
                continue;
            }
            if (preg_match('/^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@/', $line, $m)) {
                $current['inHunk'] = true;
                self::addRange($current, $m);
            }
        }
        if ($current !== null) {
            $files[] = $current;
        }

        $result = [];
        foreach ($files as $file) {
            $path = $file['path'];
            // Diffs sin cabeceras ---/+++ (binarios, solo modo o renombrado puro).
            if ($path === null && empty($file['deleted'])) {
                $path = $file['headerPath'];
            }
            $result[] = [
                'path' => $path,
                'oldPath' => $file['oldPath'],
                'new' => $file['new'],
                'lines' => $file['lines'],
            ];
        }
        return $result;
    }

    /**
     * @param array<string, mixed> $current
     * @param array<int, string> $m
     */
    private static function addRange(array &$current, array $m): void
    {
        $start = (int) $m[1];
        $count = isset($m[2]) && $m[2] !== '' ? (int) $m[2] : 1;
        for ($i = 0; $i < $count; $i++) {
            $current['lines'][] = $start + $i;
        }
    }

    private static function stripPrefix(string $path, string $prefix): string
    {
        return str_starts_with($path, $prefix) ? substr($path, strlen($prefix)) : $path;
    }

    /**
     * Obtiene la ruta destino de "diff --git a/x b/x" (solo fiable si ambas coinciden).
     */
    private static function pathFromDiffHeader(string $line): ?string
    {
        $rest = substr($line, strlen('diff --git '));
        if (str_starts_with($rest, '"')) {
            return null;
        }
        // Si la ruta antigua y nueva son iguales: "a/<p> b/<p>".
        $len = strlen($rest);
        if ($len % 2 === 1) {
            $half = intdiv($len - 1, 2);
            $a = substr($rest, 0, $half);
            $b = substr($rest, $half + 1);
            if (str_starts_with($a, 'a/') && str_starts_with($b, 'b/') && substr($a, 2) === substr($b, 2)) {
                return substr($b, 2);
            }
        }
        return null;
    }

    /**
     * Decodifica rutas entrecomilladas al estilo C que Git usa para
     * caracteres de control, comillas o barras invertidas.
     */
    public static function unquote(string $path): string
    {
        $path = rtrim($path, "\t");
        if (!str_starts_with($path, '"') || !str_ends_with($path, '"') || strlen($path) < 2) {
            return $path;
        }
        $inner = substr($path, 1, -1);
        $out = '';
        $len = strlen($inner);
        for ($i = 0; $i < $len; $i++) {
            $c = $inner[$i];
            if ($c !== '\\' || $i + 1 >= $len) {
                $out .= $c;
                continue;
            }
            $n = $inner[++$i];
            switch ($n) {
                case 'n': $out .= "\n"; break;
                case 't': $out .= "\t"; break;
                case 'r': $out .= "\r"; break;
                case 'a': $out .= "\x07"; break;
                case 'b': $out .= "\x08"; break;
                case 'f': $out .= "\x0c"; break;
                case 'v': $out .= "\x0b"; break;
                case '"': $out .= '"'; break;
                case '\\': $out .= '\\'; break;
                default:
                    if (ctype_digit($n) && $i + 2 < $len) {
                        $out .= chr(octdec(substr($inner, $i, 3)));
                        $i += 2;
                    } else {
                        $out .= $n;
                    }
            }
        }
        return $out;
    }
}
