<?php

declare(strict_types=1);

namespace ReadinessCheck\Git;

use ReadinessCheck\Exception\ConfigurationException;
use ReadinessCheck\Exception\ExecutionException;
use ReadinessCheck\Process\Process;
use ReadinessCheck\Process\ProcessResult;

/**
 * Operaciones de solo lectura sobre el repositorio Git del proyecto.
 *
 * Ningún método modifica el repositorio, el índice ni el árbol de trabajo.
 */
final class GitRepository
{
    private function __construct(private string $root)
    {
    }

    /**
     * Localiza el repositorio que contiene el directorio indicado.
     */
    public static function discover(string $directory): self
    {
        if (Process::findExecutable('git') === null) {
            throw new ExecutionException('Git no está instalado o no se encuentra en el PATH.');
        }
        $result = Process::run(['git', 'rev-parse', '--show-toplevel'], $directory);
        if (!$result->isSuccessful()) {
            $detail = $result->errorSummary();
            if (stripos($detail, 'dubious ownership') !== false) {
                throw new ExecutionException(
                    "Git rechaza el repositorio por propietario distinto (safe.directory).\n{$detail}\n"
                    . 'Consulte la sección "Solución de errores comunes" del README.'
                );
            }
            throw new ExecutionException(
                "El directorio '{$directory}' no pertenece a un repositorio Git. "
                . 'El validador necesita Git para identificar los cambios de la rama.'
            );
        }
        $root = trim($result->stdout());
        $real = realpath($root);
        return new self($real !== false ? $real : $root);
    }

    public function root(): string
    {
        return $this->root;
    }

    /**
     * Ejecuta git con salida no traducida y rutas sin escapar.
     *
     * @param list<string> $args
     */
    public function run(array $args): ProcessResult
    {
        $command = array_merge(['git', '-c', 'core.quotePath=false', '-c', 'color.ui=false'], $args);
        return Process::run($command, $this->root, null, 600, ['LC_ALL' => 'C', 'LANG' => 'C', 'GIT_PAGER' => 'cat']);
    }

    /**
     * @param list<string> $args
     */
    public function runOrFail(array $args, string $errorMessage): string
    {
        $result = $this->run($args);
        if (!$result->isSuccessful()) {
            throw new ExecutionException($errorMessage . "\n" . $result->errorSummary());
        }
        return $result->stdout();
    }

    public function headCommit(): string
    {
        $result = $this->run(['rev-parse', '--verify', '--quiet', 'HEAD']);
        if (!$result->isSuccessful()) {
            throw new ExecutionException('El repositorio no tiene commits todavía; no hay nada que comparar.');
        }
        return trim($result->stdout());
    }

    public function currentBranch(): string
    {
        $result = $this->run(['symbolic-ref', '--quiet', '--short', 'HEAD']);
        if ($result->isSuccessful()) {
            return trim($result->stdout());
        }
        return 'HEAD (detached)';
    }

    public function refExists(string $ref): bool
    {
        if ($ref === '' || str_starts_with($ref, '-')) {
            return false;
        }
        return $this->run(['rev-parse', '--verify', '--quiet', $ref . '^{commit}'])->isSuccessful();
    }

    public function resolveCommit(string $ref): string
    {
        return trim($this->runOrFail(['rev-parse', '--verify', $ref . '^{commit}'], "No se pudo resolver '{$ref}'."));
    }

    /**
     * Determina la rama base: la indicada por el usuario o la primera
     * candidata existente (remota primero, luego local).
     *
     * @param list<string> $candidates
     */
    public function resolveBase(?string $requested, array $candidates, string $remote, string $currentBranch): string
    {
        if ($requested !== null) {
            if (!$this->refExists($requested)) {
                $hint = str_contains($requested, '/')
                    ? " Si es una rama remota, ejecute antes 'git fetch'."
                    : '';
                throw new ConfigurationException("La rama base '{$requested}' no existe en el repositorio.{$hint}");
            }
            return $requested;
        }

        foreach ($candidates as $name) {
            $remoteRef = $remote . '/' . $name;
            if ($this->refExists('refs/remotes/' . $remoteRef)) {
                return $remoteRef;
            }
            if ($name !== $currentBranch && $this->refExists('refs/heads/' . $name)) {
                return $name;
            }
        }

        throw new ConfigurationException(
            'No se pudo autodetectar la rama base (se probó: ' . implode(', ', $candidates)
            . '). Indíquela con --base=<rama>, por ejemplo --base=origin/develop.'
        );
    }

    public function mergeBase(string $base): string
    {
        $result = $this->run(['merge-base', 'HEAD', $base]);
        if (!$result->isSuccessful() || trim($result->stdout()) === '') {
            throw new ExecutionException(
                "No existe un ancestro común (merge-base) entre HEAD y '{$base}'. "
                . 'Verifique que la rama base sea correcta.'
            );
        }
        return trim($result->stdout());
    }

    /**
     * Commits de la rama posteriores al merge-base.
     *
     * @return list<array{hash: string, author: string, date: string, subject: string}>
     */
    public function commitsSince(string $mergeBase): array
    {
        $output = $this->runOrFail(
            ['log', '--no-color', '--format=%H%x1f%an%x1f%aI%x1f%s%x1e', $mergeBase . '..HEAD'],
            'No se pudieron listar los commits de la rama.'
        );
        $commits = [];
        foreach (explode("\x1e", $output) as $record) {
            $record = trim($record, "\n");
            if ($record === '') {
                continue;
            }
            $parts = explode("\x1f", $record);
            $commits[] = [
                'hash' => $parts[0] ?? '',
                'author' => $parts[1] ?? '',
                'date' => $parts[2] ?? '',
                'subject' => $parts[3] ?? '',
            ];
        }
        return $commits;
    }

    /**
     * Lista de rutas separadas por NUL.
     *
     * @param list<string> $args
     * @return list<string>
     */
    public function nulList(array $args, string $errorMessage): array
    {
        $output = $this->runOrFail($args, $errorMessage);
        return array_values(array_filter(explode("\0", $output), static fn (string $p): bool => $p !== ''));
    }

    /**
     * Contenido de un archivo en un commit, o null si no existía.
     */
    public function showFile(string $commit, string $path): ?string
    {
        $result = $this->run(['show', $commit . ':' . $path]);
        return $result->isSuccessful() ? $result->stdout() : null;
    }
}
