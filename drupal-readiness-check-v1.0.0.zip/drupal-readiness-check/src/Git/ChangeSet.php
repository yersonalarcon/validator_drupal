<?php

declare(strict_types=1);

namespace ReadinessCheck\Git;

use ReadinessCheck\Options;

/**
 * Conjunto de cambios de la rama actual respecto al merge-base con la rama base.
 *
 * Incluye: commits posteriores al merge-base, cambios en el índice (staged),
 * cambios sin preparar (unstaged) y archivos nuevos sin seguimiento.
 */
final class ChangeSet
{
    /** @var array<string, ChangedFile> */
    private array $files = [];

    /** @var list<string> */
    private array $excludedPaths = [];

    /**
     * @param list<array{hash: string, author: string, date: string, subject: string}> $commits
     */
    private function __construct(
        public GitRepository $git,
        public string $branch,
        public string $base,
        public string $baseCommit,
        public string $mergeBase,
        public string $headCommit,
        public array $commits,
        public string $scope
    ) {
    }

    /**
     * @param list<string> $excludePrefixes Prefijos de ruta (relativos a la raíz) a excluir.
     * @param list<string> $baseCandidates
     */
    public static function build(
        GitRepository $git,
        ?string $requestedBase,
        array $baseCandidates,
        string $remote,
        string $scope,
        array $excludePrefixes
    ): self {
        $head = $git->headCommit();
        $branch = $git->currentBranch();
        $base = $git->resolveBase($requestedBase, $baseCandidates, $remote, $branch);
        $baseCommit = $git->resolveCommit($base);
        $mergeBase = $git->mergeBase($base);
        $commits = $git->commitsSince($mergeBase);

        $set = new self($git, $branch, $base, $baseCommit, $mergeBase, $head, $commits, $scope);
        $set->collect($excludePrefixes);
        return $set;
    }

    /**
     * @param list<string> $excludePrefixes
     */
    private function collect(array $excludePrefixes): void
    {
        $git = $this->git;
        $mb = $this->mergeBase;

        $committed = $git->nulList(['diff', '--name-only', '-z', '--no-renames', $mb, 'HEAD'], 'No se pudieron listar los archivos de los commits.');
        $staged = $git->nulList(['diff', '--cached', '--name-only', '-z', '--no-renames'], 'No se pudieron listar los cambios staged.');
        $unstaged = $git->nulList(['diff', '--name-only', '-z', '--no-renames'], 'No se pudieron listar los cambios unstaged.');
        $untracked = $git->nulList(['ls-files', '--others', '--exclude-standard', '-z'], 'No se pudieron listar los archivos nuevos.');

        // Diferencia completa merge-base -> árbol de trabajo (commits + staged + unstaged).
        $diff = $git->runOrFail(
            ['diff', '-U0', '-M', '--no-color', '--no-ext-diff', '--src-prefix=a/', '--dst-prefix=b/', $mb],
            'No se pudo calcular la diferencia respecto al merge-base.'
        );

        foreach (DiffParser::parse($diff) as $parsed) {
            if ($parsed['path'] === null) {
                continue; // Archivo eliminado.
            }
            $file = $this->fileFor($parsed['path']);
            $file->newFile = $parsed['new'];
            $file->basePath = $parsed['oldPath'];
            foreach ($parsed['lines'] as $line) {
                $file->addLine($line);
            }
        }

        foreach ($committed as $path) {
            $this->markOrigin($path, ChangedFile::ORIGIN_COMMITTED);
        }
        foreach ($staged as $path) {
            $this->markOrigin($path, ChangedFile::ORIGIN_STAGED);
        }
        foreach ($unstaged as $path) {
            $this->markOrigin($path, ChangedFile::ORIGIN_UNSTAGED);
        }
        foreach ($untracked as $path) {
            $file = $this->fileFor($path);
            $file->newFile = true;
            $file->allLinesChanged = true;
            $file->addOrigin(ChangedFile::ORIGIN_UNTRACKED);
        }

        if ($this->scope === Options::SCOPE_ALL) {
            $tracked = $git->nulList(['ls-files', '-z'], 'No se pudieron listar los archivos versionados.');
            foreach ($tracked as $path) {
                $this->fileFor($path);
            }
        }

        // Solo se conservan archivos existentes en el árbol de trabajo y no excluidos.
        foreach (array_keys($this->files) as $path) {
            if ($this->isExcluded($path, $excludePrefixes)) {
                $this->excludedPaths[] = $path;
                unset($this->files[$path]);
                continue;
            }
            $absolute = $this->absolutePath($path);
            if (!is_file($absolute)) {
                unset($this->files[$path]);
                continue;
            }
            if ($this->scope === Options::SCOPE_CHANGED && !$this->files[$path]->hasChanges()) {
                unset($this->files[$path]);
            }
        }
        ksort($this->files, SORT_STRING);
        sort($this->excludedPaths, SORT_STRING);
    }

    private function fileFor(string $path): ChangedFile
    {
        if (!isset($this->files[$path])) {
            $this->files[$path] = new ChangedFile($path);
        }
        return $this->files[$path];
    }

    private function markOrigin(string $path, string $origin): void
    {
        // Los archivos eliminados aparecen en las listas pero no en el diff.
        if (isset($this->files[$path])) {
            $this->files[$path]->addOrigin($origin);
        }
    }

    /**
     * @param list<string> $prefixes
     */
    private function isExcluded(string $path, array $prefixes): bool
    {
        foreach ($prefixes as $prefix) {
            if ($prefix === '') {
                continue;
            }
            if ($path === rtrim($prefix, '/') || str_starts_with($path, rtrim($prefix, '/') . '/')) {
                return true;
            }
        }
        return false;
    }

    /** @return array<string, ChangedFile> */
    public function files(): array
    {
        return $this->files;
    }

    public function file(string $path): ?ChangedFile
    {
        return $this->files[$path] ?? null;
    }

    /** @return list<string> */
    public function excludedPaths(): array
    {
        return $this->excludedPaths;
    }

    /**
     * @param list<string> $extensions
     * @return list<ChangedFile>
     */
    public function filesWithExtensions(array $extensions): array
    {
        return array_values(array_filter(
            $this->files,
            static fn (ChangedFile $f): bool => in_array($f->extension(), $extensions, true)
        ));
    }

    public function absolutePath(string $relative): string
    {
        return $this->git->root() . '/' . $relative;
    }

    /**
     * Convierte una ruta absoluta (o relativa a la raíz) en relativa a la raíz.
     */
    public function relativePath(string $path): string
    {
        $root = $this->git->root() . '/';
        if (str_starts_with($path, $root)) {
            return substr($path, strlen($root));
        }
        $real = realpath($path);
        if ($real !== false && str_starts_with($real, $root)) {
            return substr($real, strlen($root));
        }
        if (str_starts_with($path, './')) {
            return substr($path, 2);
        }
        return $path;
    }

    /**
     * Indica si una línea concreta fue modificada por la rama.
     */
    public function isLineChanged(string $relativePath, ?int $line): bool
    {
        $file = $this->files[$relativePath] ?? null;
        return $file !== null && $file->isLineChanged($line);
    }

    /**
     * Contenido del archivo en el merge-base (null si no existía).
     */
    public function baseContent(ChangedFile $file): ?string
    {
        if ($file->newFile) {
            return null;
        }
        return $this->git->showFile($this->mergeBase, $file->basePath ?? $file->path);
    }
}
