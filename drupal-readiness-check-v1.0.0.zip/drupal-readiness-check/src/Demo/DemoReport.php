<?php

declare(strict_types=1);

namespace ReadinessCheck\Demo;

/**
 * Datos ficticios para --demo.
 *
 * No ejecuta Git, Drush, phpcs, Gitleaks ni Composer y no lee ni modifica el
 * proyecto Drupal. Sirve para conocer el formato de la consola y los reportes.
 */
final class DemoReport
{
    /**
     * @return array<string, mixed>
     */
    public static function build(string $toolVersion): array
    {
        $commit = '0000000000000000000000000000000000000000';
        return [
            'tool' => ['name' => 'drupal-readiness-check', 'version' => $toolVersion],
            'mode' => 'demo',
            'generated_at' => date('c'),
            'project' => [
                'root' => '(demo)',
                'commit' => $commit,
                'commit_short' => 'demo',
                'branch' => 'feature/DEMO-123-ejemplo',
                'base' => 'origin/develop',
                'base_commit' => '1111111111111111111111111111111111111111',
                'merge_base' => '2222222222222222222222222222222222222222',
                'scope' => 'changed',
                'uri' => null,
                'fail_on' => 'fail',
                'checks' => ['db-updates', 'code-standards', 'secrets-scan'],
            ],
            'commits' => [
                ['hash' => '3333333333333333333333333333333333333333', 'author' => 'Desarrollador Demo', 'date' => '2026-01-15T10:00:00-05:00', 'subject' => 'DEMO-123: Agrega módulo de ejemplo'],
            ],
            'files' => [
                ['path' => 'web/modules/custom/demo_example/demo_example.module', 'origins' => ['committed'], 'new_file' => true, 'changed_lines' => 'all'],
                ['path' => 'web/modules/custom/demo_example/demo_example.install', 'origins' => ['committed', 'unstaged'], 'new_file' => false, 'changed_lines' => '12-20'],
                ['path' => 'web/modules/custom/demo_example/demo_example.services.yml', 'origins' => ['staged'], 'new_file' => false, 'changed_lines' => '3'],
                ['path' => 'web/sites/default/settings.local.php', 'origins' => ['untracked'], 'new_file' => true, 'changed_lines' => 'all'],
            ],
            'excluded_files' => [],
            'checks' => [
                [
                    'id' => 'db-updates', 'title' => 'Actualizaciones de base de datos pendientes', 'status' => 'FAIL',
                    'summary' => '2 actualización(es) pendiente(s); 1 introducida(s) por la rama actual.', 'duration_ms' => 0,
                    'tools' => [['name' => 'drush', 'status' => 'PASS', 'detail' => 'DEMO (no ejecutado)']], 'notes' => [],
                    'findings' => [
                        ['file' => 'web/modules/custom/demo_example/demo_example.install', 'line' => 14, 'column' => 1, 'rule' => 'hook_update_N', 'message' => "La rama introduce la actualización demo_example_update_10001() y está pendiente de ejecutar. Ejecute 'ddev drush updatedb' y verifique el resultado. Descripción: Crea la tabla de ejemplo.", 'severity' => 'error', 'code' => 'function demo_example_update_10001() {', 'module' => 'demo_example', 'function' => 'demo_example_update_10001', 'origin' => 'rama actual'],
                        ['file' => 'web/modules/contrib/demo_contrib/demo_contrib.install', 'line' => 40, 'column' => 1, 'rule' => 'hook_update_N', 'message' => 'Actualización pendiente demo_contrib_update_9001() que no fue introducida por la rama actual (proviene de otra rama o dependencia).', 'severity' => 'warning', 'code' => 'function demo_contrib_update_9001() {', 'module' => 'demo_contrib', 'function' => 'demo_contrib_update_9001', 'origin' => 'otra rama o dependencia'],
                    ],
                    'preexisting' => [],
                ],
                [
                    'id' => 'code-standards', 'title' => 'Sintaxis PHP/YAML y estándares Drupal', 'status' => 'FAIL',
                    'summary' => '2 archivo(s) PHP y 1 YAML analizados: 2 hallazgo(s) nuevo(s), 1 preexistente(s).', 'duration_ms' => 0,
                    'tools' => [
                        ['name' => 'php -l', 'status' => 'PASS', 'detail' => 'DEMO (no ejecutado)'],
                        ['name' => 'symfony/yaml', 'status' => 'PASS', 'detail' => 'DEMO (no ejecutado)'],
                        ['name' => 'phpcs', 'status' => 'PASS', 'detail' => 'DEMO (no ejecutado)'],
                    ],
                    'notes' => [],
                    'findings' => [
                        ['file' => 'web/modules/custom/demo_example/demo_example.module', 'line' => 8, 'column' => 3, 'rule' => 'Drupal.WhiteSpace.ScopeIndent.IncorrectExact', 'message' => 'Line indented incorrectly; expected 2 spaces, found 4', 'severity' => 'error', 'code' => '    return $build;', 'fixable' => true],
                        ['file' => 'web/modules/custom/demo_example/demo_example.services.yml', 'line' => 3, 'column' => null, 'rule' => 'yaml.syntax', 'message' => 'Indentation problem at line 3 (near "class: ...").', 'severity' => 'error', 'code' => '   class: Drupal\\demo_example\\DemoService'],
                    ],
                    'preexisting' => [
                        ['file' => 'web/modules/custom/demo_example/demo_example.install', 'line' => 3, 'column' => 1, 'rule' => 'Drupal.Commenting.FileComment.Missing', 'message' => 'Missing file doc comment', 'severity' => 'error', 'code' => '<?php'],
                    ],
                ],
                [
                    'id' => 'secrets-scan', 'title' => 'Detección de secretos (Gitleaks)', 'status' => 'FAIL',
                    'summary' => '1 posible(s) secreto(s) detectado(s). Los valores se muestran redactados.', 'duration_ms' => 0,
                    'tools' => [['name' => 'gitleaks', 'status' => 'PASS', 'detail' => 'DEMO (no ejecutado)']], 'notes' => [],
                    'findings' => [
                        ['file' => 'web/sites/default/settings.local.php', 'line' => 5, 'column' => 20, 'rule' => 'generic-api-key', 'message' => 'Detected a Generic API Key, potentially exposing access to various services and sensitive operations.', 'severity' => 'error', 'code' => "\$config['demo.settings']['api_key'] = '****REDACTED****';", 'commit' => 'sin commit (archivo nuevo)', 'author' => 'Desarrollador Demo (usuario Git local)', 'date' => '2026-01-15T10:05:00-05:00 (modificación del archivo)', 'source' => 'untracked'],
                    ],
                    'preexisting' => [],
                ],
                ['id' => 'config-status', 'title' => 'Estado de la configuración (drush config:status)', 'status' => 'OMITTED', 'summary' => 'Validación opcional no seleccionada (use --all-checks o --checks=config-status).', 'duration_ms' => 0, 'tools' => [], 'notes' => [], 'findings' => [], 'preexisting' => []],
                ['id' => 'composer-audit', 'title' => 'Auditoría de dependencias (composer audit)', 'status' => 'OMITTED', 'summary' => 'Validación opcional no seleccionada (use --all-checks o --checks=composer-audit).', 'duration_ms' => 0, 'tools' => [], 'notes' => [], 'findings' => [], 'preexisting' => []],
                ['id' => 'disallowed-modules', 'title' => 'Módulos prohibidos', 'status' => 'OMITTED', 'summary' => 'Validación opcional no seleccionada (use --all-checks o --checks=disallowed-modules).', 'duration_ms' => 0, 'tools' => [], 'notes' => [], 'findings' => [], 'preexisting' => []],
            ],
            'result' => [
                'status' => 'FAIL',
                'exit_code' => 0,
                'message' => 'MODO DEMO: el resultado es ilustrativo. En modo demo el código de salida es siempre 0.',
                'execution_errors' => 0,
            ],
        ];
    }
}
