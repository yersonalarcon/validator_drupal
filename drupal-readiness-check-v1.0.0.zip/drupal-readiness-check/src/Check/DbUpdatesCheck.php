<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

use ReadinessCheck\Exception\ToolExecutionException;
use ReadinessCheck\Process\Process;
use ReadinessCheck\Support\Json;

/**
 * db-updates: detecta actualizaciones de base de datos pendientes.
 *
 * Usa `drush updatedb:status`. Para cada actualización localiza la función
 * que la define (hook_update_N o hook_post_update_NAME) y su archivo/línea:
 *  - FAIL si la definición fue introducida por la rama actual.
 *  - WARN si proviene de otra rama o de una dependencia.
 */
final class DbUpdatesCheck implements CheckInterface
{
    private const SKIP_DIRS = ['.git', 'vendor', 'node_modules', '.ddev', 'files', 'private', 'simpletest'];

    /** @var array<string, list<string>>|null Índice nombre-de-archivo => rutas. */
    private ?array $fileIndex = null;

    public function id(): string
    {
        return 'db-updates';
    }

    public function title(): string
    {
        return 'Actualizaciones de base de datos pendientes';
    }

    public function run(CheckContext $context): CheckResult
    {
        $result = new CheckResult($this->id(), $this->title());
        $drush = $context->tools->drush();
        if ($drush === null) {
            $result->addTool('drush', Status::OMITTED, 'Drush no está instalado (vendor/bin/drush ni PATH).');
            $result->status = Status::OMITTED;
            $result->summary = 'Drush no está disponible; no se pudieron consultar las actualizaciones pendientes.';
            return $result;
        }

        $command = [$drush, 'updatedb:status', '--format=json', '--no-interaction'];
        if ($context->options->uri !== null) {
            $command[] = '--uri=' . $context->options->uri;
        }
        $process = Process::run($command, $context->projectRoot(), null, $context->timeout('drush'));
        if (!$process->isSuccessful()) {
            throw new ToolExecutionException(
                'drush updatedb:status falló (código ' . $process->exitCode() . '): ' . $process->errorSummary()
            );
        }

        $updates = $this->parseUpdates($process->stdout());
        $result->addTool('drush', Status::PASS, 'drush updatedb:status' . ($context->options->uri ? ' --uri=' . $context->options->uri : ''));

        foreach ($updates as $update) {
            $result->findings[] = $this->classify($context, $update);
        }

        $result->status = Status::worst(array_merge(
            [Status::PASS],
            array_map(static fn (Finding $f): string => $f->severity === Finding::SEVERITY_ERROR ? Status::FAIL : Status::WARN, $result->findings)
        ));
        $new = count(array_filter($result->findings, static fn (Finding $f): bool => $f->severity === Finding::SEVERITY_ERROR));
        $result->summary = $updates === []
            ? 'No hay actualizaciones de base de datos pendientes.'
            : sprintf('%d actualización(es) pendiente(s); %d introducida(s) por la rama actual.', count($updates), $new);

        return $result;
    }

    /**
     * @return list<array{module: string, update_id: string, description: string, type: string}>
     */
    private function parseUpdates(string $stdout): array
    {
        if (trim($stdout) === '') {
            return []; // Drush no imprime nada en stdout cuando no hay pendientes.
        }
        $data = Json::decodeLenient($stdout);
        if ($data === null) {
            throw new ToolExecutionException('La salida de drush updatedb:status no es JSON válido: ' . mb_substr(trim($stdout), 0, 300));
        }
        $updates = [];
        foreach ($data as $item) {
            if (!is_array($item) || !isset($item['module'])) {
                continue;
            }
            $updates[] = [
                'module' => (string) $item['module'],
                'update_id' => (string) ($item['update_id'] ?? ''),
                'description' => trim((string) ($item['description'] ?? '')),
                'type' => (string) ($item['type'] ?? 'hook_update_n'),
            ];
        }
        return $updates;
    }

    /**
     * @param array{module: string, update_id: string, description: string, type: string} $update
     */
    private function classify(CheckContext $context, array $update): Finding
    {
        $module = $update['module'];
        $id = $update['update_id'];
        $isPost = str_contains(strtolower($update['type']), 'post');

        if ($isPost) {
            $function = str_starts_with($id, $module . '_post_update_') ? $id : $module . '_post_update_' . $id;
            $fileName = $module . '.post_update.php';
            $rule = 'hook_post_update_NAME';
        } else {
            $function = str_starts_with($id, $module . '_update_') ? $id : $module . '_update_' . $id;
            $fileName = $module . '.install';
            $rule = 'hook_update_N';
        }

        $location = $this->locateFunction($context, $function, $fileName);
        $extra = [
            'module' => $module,
            'update_id' => $id,
            'function' => $function,
            'type' => $update['type'],
        ];
        $description = $update['description'] !== '' ? ' Descripción: ' . $update['description'] : '';

        if ($location === null) {
            $extra['origin'] = 'desconocido';
            return new Finding(
                $fileName,
                null,
                null,
                $rule,
                "Actualización pendiente {$function}(). No se encontró su definición en el proyecto.{$description}",
                Finding::SEVERITY_WARNING,
                null,
                $extra
            );
        }

        [$path, $line, $column] = $location;
        $introducedByBranch = $context->changes->isLineChanged($path, $line);
        $extra['origin'] = $introducedByBranch ? 'rama actual' : 'otra rama o dependencia';

        $message = $introducedByBranch
            ? "La rama introduce la actualización {$function}() y está pendiente de ejecutar. Ejecute 'ddev drush updatedb' y verifique el resultado.{$description}"
            : "Actualización pendiente {$function}() que no fue introducida por la rama actual (proviene de otra rama o dependencia).{$description}";

        return new Finding(
            $path,
            $line,
            $column,
            $rule,
            $message,
            $introducedByBranch ? Finding::SEVERITY_ERROR : Finding::SEVERITY_WARNING,
            $context->codeAt($path, $line),
            $extra
        );
    }

    /**
     * Busca "function <nombre>(" en los archivos con el nombre esperado.
     *
     * @return array{0: string, 1: int, 2: int}|null [ruta relativa, línea, columna]
     */
    private function locateFunction(CheckContext $context, string $function, string $fileName): ?array
    {
        $root = $context->projectRoot();
        $candidates = [];
        // Primero los archivos de la rama (rápido y prioritario).
        foreach ($context->changes->files() as $path => $file) {
            if (basename($path) === $fileName) {
                $candidates[] = $path;
            }
        }
        foreach ($this->filesNamed($root, $fileName) as $path) {
            if (!in_array($path, $candidates, true) && !$context->isExcluded($path)) {
                $candidates[] = $path;
            }
        }

        $pattern = '/^([ \t]*)function[ \t]+' . preg_quote($function, '/') . '[ \t]*\(/m';
        foreach ($candidates as $path) {
            $content = @file_get_contents($root . '/' . $path);
            if ($content === false) {
                continue;
            }
            if (preg_match($pattern, $content, $m, PREG_OFFSET_CAPTURE)) {
                $offset = $m[0][1];
                $line = substr_count($content, "\n", 0, $offset) + 1;
                $column = strlen($m[1][0]) + 1;
                return [$path, $line, $column];
            }
        }
        return null;
    }

    /**
     * @return list<string> Rutas relativas a la raíz.
     */
    private function filesNamed(string $root, string $fileName): array
    {
        if ($this->fileIndex === null) {
            $this->fileIndex = [];
            $this->indexDirectory($root, '', 0);
        }
        return $this->fileIndex[$fileName] ?? [];
    }

    private function indexDirectory(string $root, string $relative, int $depth): void
    {
        if ($depth > 12) {
            return;
        }
        $dir = $relative === '' ? $root : $root . '/' . $relative;
        $entries = @scandir($dir);
        if ($entries === false) {
            return;
        }
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $path = $relative === '' ? $entry : $relative . '/' . $entry;
            $absolute = $root . '/' . $path;
            if (is_dir($absolute)) {
                if (in_array($entry, self::SKIP_DIRS, true) || is_link($absolute)) {
                    continue;
                }
                $this->indexDirectory($root, $path, $depth + 1);
                continue;
            }
            if (str_ends_with($entry, '.install') || str_ends_with($entry, '.post_update.php')) {
                $this->fileIndex[$entry][] = $path;
            }
        }
    }
}
