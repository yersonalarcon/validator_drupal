<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

/**
 * Resultado de una validación.
 *
 * - $findings: hallazgos nuevos (introducidos por la rama), determinan el estado.
 * - $preexisting: hallazgos que ya existían en líneas no modificadas. Se
 *   informan por separado y nunca hacen fallar la validación.
 * - $tools: estado de cada herramienta usada (útil cuando una falta).
 */
final class CheckResult
{
    /** @var list<Finding> */
    public array $findings = [];

    /** @var list<Finding> */
    public array $preexisting = [];

    /** @var list<array{name: string, status: string, detail: string}> */
    public array $tools = [];

    /** @var list<string> */
    public array $notes = [];

    public float $durationMs = 0.0;

    /** La herramienta existe pero falló: el resultado es desconocido. */
    public bool $executionError = false;

    public function __construct(
        public string $id,
        public string $title,
        public string $status = Status::PASS,
        public string $summary = ''
    ) {
    }

    public static function omitted(string $id, string $title, string $reason): self
    {
        return new self($id, $title, Status::OMITTED, $reason);
    }

    public function addTool(string $name, string $status, string $detail): void
    {
        $this->tools[] = ['name' => $name, 'status' => $status, 'detail' => $detail];
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'status' => $this->status,
            'summary' => $this->summary,
            'duration_ms' => (int) round($this->durationMs),
            'execution_error' => $this->executionError,
            'tools' => $this->tools,
            'notes' => $this->notes,
            'findings' => array_map(static fn (Finding $f): array => $f->toArray(), $this->findings),
            'preexisting' => array_map(static fn (Finding $f): array => $f->toArray(), $this->preexisting),
        ];
    }
}
