<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

use ReadinessCheck\Exception\ToolExecutionException;
use ReadinessCheck\Process\Process;
use ReadinessCheck\Support\Json;

/**
 * composer-audit (opcional): vulnerabilidades conocidas en las dependencias
 * de composer.lock mediante `composer audit`.
 *
 * - Avisos de seguridad: FAIL.
 * - Paquetes abandonados: WARN.
 */
final class ComposerAuditCheck implements CheckInterface
{
    public function id(): string
    {
        return 'composer-audit';
    }

    public function title(): string
    {
        return 'Auditoría de dependencias (composer audit)';
    }

    public function run(CheckContext $context): CheckResult
    {
        $result = new CheckResult($this->id(), $this->title());
        $root = $context->projectRoot();

        if (!is_file($root . '/composer.lock')) {
            $result->addTool('composer', Status::OMITTED, 'No existe composer.lock en la raíz del proyecto.');
            $result->status = Status::OMITTED;
            $result->summary = 'No hay composer.lock que auditar.';
            return $result;
        }
        $composer = $context->tools->composer();
        if ($composer === null) {
            $result->addTool('composer', Status::OMITTED, 'Composer no está instalado.');
            $result->status = Status::OMITTED;
            $result->summary = 'Composer no está disponible.';
            return $result;
        }

        $process = Process::run(
            [$composer, 'audit', '--format=json', '--locked', '--no-interaction', '--no-ansi'],
            $root,
            null,
            $context->timeout('composer')
        );
        $data = Json::decodeLenient($process->stdout());
        if ($data === null || (!isset($data['advisories']) && !isset($data['abandoned']))) {
            throw new ToolExecutionException('composer audit falló (código ' . $process->exitCode() . '): ' . $process->errorSummary());
        }
        $result->addTool('composer', Status::PASS, 'composer audit --locked');

        $lockLines = $this->lockLineIndex($root . '/composer.lock');

        foreach ($data['advisories'] ?? [] as $package => $advisories) {
            foreach ((array) $advisories as $advisory) {
                if (!is_array($advisory)) {
                    continue;
                }
                $id = (string) ($advisory['cve'] ?? '') ?: (string) ($advisory['advisoryId'] ?? 'advisory');
                $title = (string) ($advisory['title'] ?? 'Aviso de seguridad');
                $affected = (string) ($advisory['affectedVersions'] ?? '');
                $severity = (string) ($advisory['severity'] ?? '');
                $link = (string) ($advisory['link'] ?? '');
                $line = $lockLines[(string) $package] ?? null;
                $result->findings[] = new Finding(
                    'composer.lock',
                    $line,
                    null,
                    $id,
                    trim("{$package}: {$title}" . ($affected !== '' ? " (versiones afectadas: {$affected})" : '')
                        . ($severity !== '' ? " [severidad: {$severity}]" : '') . ($link !== '' ? " {$link}" : '')),
                    Finding::SEVERITY_ERROR,
                    $line !== null ? $context->codeAt('composer.lock', $line) : null,
                    ['package' => (string) $package]
                );
            }
        }

        foreach ($data['abandoned'] ?? [] as $package => $replacement) {
            $line = $lockLines[(string) $package] ?? null;
            $result->findings[] = new Finding(
                'composer.lock',
                $line,
                null,
                'abandoned-package',
                "{$package} está abandonado" . (is_string($replacement) && $replacement !== '' ? "; se recomienda {$replacement}." : '.'),
                Finding::SEVERITY_WARNING,
                $line !== null ? $context->codeAt('composer.lock', $line) : null,
                ['package' => (string) $package]
            );
        }

        $statuses = [Status::PASS];
        foreach ($result->findings as $finding) {
            $statuses[] = $finding->severity === Finding::SEVERITY_ERROR ? Status::FAIL : Status::WARN;
        }
        $result->status = Status::worst($statuses);
        $result->summary = $result->findings === []
            ? 'No se encontraron vulnerabilidades conocidas ni paquetes abandonados.'
            : count($result->findings) . ' hallazgo(s) en las dependencias.';
        return $result;
    }

    /**
     * @return array<string, int> paquete => línea de "name" en composer.lock
     */
    private function lockLineIndex(string $lockFile): array
    {
        $index = [];
        $handle = @fopen($lockFile, 'rb');
        if ($handle === false) {
            return $index;
        }
        $lineNumber = 0;
        while (($line = fgets($handle)) !== false) {
            $lineNumber++;
            if (preg_match('/^\s*"name":\s*"([^"]+)"/', $line, $m) && !isset($index[$m[1]])) {
                $index[$m[1]] = $lineNumber;
            }
        }
        fclose($handle);
        return $index;
    }
}
