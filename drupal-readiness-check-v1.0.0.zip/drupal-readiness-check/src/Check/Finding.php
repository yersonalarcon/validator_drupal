<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

/**
 * Hallazgo individual de una validación.
 */
final class Finding
{
    public const SEVERITY_ERROR = 'error';
    public const SEVERITY_WARNING = 'warning';

    /**
     * @param array<string, string|int|null> $extra Datos adicionales (commit, autor, fecha…).
     */
    public function __construct(
        public string $file,
        public ?int $line,
        public ?int $column,
        public string $rule,
        public string $message,
        public string $severity = self::SEVERITY_ERROR,
        public ?string $code = null,
        public array $extra = []
    ) {
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'file' => $this->file,
            'line' => $this->line,
            'column' => $this->column,
            'rule' => $this->rule,
            'message' => $this->message,
            'severity' => $this->severity,
            'code' => $this->code,
        ] + $this->extra;
    }
}
