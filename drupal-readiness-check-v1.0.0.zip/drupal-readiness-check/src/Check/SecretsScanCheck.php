<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

use ReadinessCheck\Exception\ToolExecutionException;
use ReadinessCheck\Git\ChangedFile;
use ReadinessCheck\Process\Process;
use ReadinessCheck\Support\Redactor;

/**
 * secrets-scan: busca secretos con Gitleaks en
 *  - los commits de la rama (merge-base..HEAD),
 *  - los cambios staged,
 *  - los cambios unstaged,
 *  - los archivos nuevos sin seguimiento.
 *
 * Gitleaks se ejecuta siempre con --redact y el campo "Secret" nunca se
 * copia a la consola ni a los reportes.
 */
final class SecretsScanCheck implements CheckInterface
{
    public function id(): string
    {
        return 'secrets-scan';
    }

    public function title(): string
    {
        return 'Detección de secretos (Gitleaks)';
    }

    public function run(CheckContext $context): CheckResult
    {
        $result = new CheckResult($this->id(), $this->title());
        $gitleaks = $context->tools->gitleaks();
        if ($gitleaks === null) {
            $result->addTool('gitleaks', Status::OMITTED, 'Gitleaks no está instalado. Ejecute: ddev exec bash <validador>/scripts/install-gitleaks.sh');
            $result->status = Status::OMITTED;
            $result->summary = 'Gitleaks no está disponible; no se buscaron secretos.';
            return $result;
        }

        $version = $this->version($gitleaks, $context);
        $modern = version_compare($version, '8.19.0', '>=');
        $root = $context->projectRoot();
        $changes = $context->changes;
        $tmp = $context->tempDir();

        $common = ['--report-format=json', '--redact', '--no-banner', '--exit-code=0', '--log-level=error'];
        if (is_file($root . '/.gitleaks.toml')) {
            $common[] = '--config=' . $root . '/.gitleaks.toml';
        }
        if ($modern && is_file($root . '/.gitleaksignore')) {
            $common[] = '--gitleaks-ignore-path=' . $root . '/.gitleaksignore';
        }

        $scans = [];
        if ($changes->commits !== []) {
            $logOpts = '--log-opts=' . $changes->mergeBase . '..HEAD';
            $scans[] = ['label' => 'commits', 'origin' => ChangedFile::ORIGIN_COMMITTED, 'cmd' => $modern
                ? array_merge([$gitleaks, 'git', $logOpts], $common, [$root])
                : array_merge([$gitleaks, 'detect', '--source=' . $root, $logOpts], $common)];
        }
        $scans[] = ['label' => 'staged', 'origin' => ChangedFile::ORIGIN_STAGED, 'cmd' => $modern
            ? array_merge([$gitleaks, 'git', '--pre-commit', '--staged'], $common, [$root])
            : array_merge([$gitleaks, 'protect', '--staged', '--source=' . $root], $common)];
        $scans[] = ['label' => 'unstaged', 'origin' => ChangedFile::ORIGIN_UNSTAGED, 'cmd' => $modern
            ? array_merge([$gitleaks, 'git', '--pre-commit'], $common, [$root])
            : array_merge([$gitleaks, 'protect', '--source=' . $root], $common)];

        foreach ($changes->files() as $file) {
            if (in_array(ChangedFile::ORIGIN_UNTRACKED, $file->origins(), true)) {
                $absolute = $changes->absolutePath($file->path);
                $scans[] = ['label' => 'untracked', 'origin' => ChangedFile::ORIGIN_UNTRACKED, 'file' => $file->path, 'cmd' => $modern
                    ? array_merge([$gitleaks, 'dir'], $common, [$absolute])
                    : array_merge([$gitleaks, 'detect', '--no-git', '--source=' . $absolute], $common)];
            }
        }

        $seen = [];
        $counts = ['commits' => 0, 'staged' => 0, 'unstaged' => 0, 'untracked' => 0];
        try {
            foreach ($scans as $index => $scan) {
                $reportPath = $tmp . '/gitleaks-' . $index . '.json';
                $command = array_merge($scan['cmd'], ['--report-path=' . $reportPath]);
                $process = Process::run($command, $root, null, $context->timeout('gitleaks'));
                if ($process->exitCode() !== 0) {
                    throw new ToolExecutionException(
                        "Gitleaks falló al analizar {$scan['label']} (código {$process->exitCode()}): " . $process->errorSummary()
                    );
                }
                $raw = is_file($reportPath) ? (string) file_get_contents($reportPath) : '[]';
                @unlink($reportPath);
                $items = json_decode(trim($raw) === '' ? '[]' : $raw, true);
                if (!is_array($items)) {
                    throw new ToolExecutionException("El reporte de Gitleaks ({$scan['label']}) no es JSON válido.");
                }
                foreach ($items as $item) {
                    if (!is_array($item)) {
                        continue;
                    }
                    $finding = $this->toFinding($context, $item, $scan);
                    if ($finding === null) {
                        continue;
                    }
                    $key = implode('|', [$finding->file, $finding->line, $finding->rule, $finding->extra['commit'] ?? '']);
                    if (isset($seen[$key])) {
                        continue;
                    }
                    $seen[$key] = true;
                    $counts[$scan['label']]++;
                    $context->redactor->markSecretLine($finding->file, $finding->line);
                    $result->findings[] = $finding;
                }
            }
        } finally {
            CheckContext::removeDir($tmp);
        }

        $result->addTool('gitleaks', Status::PASS, sprintf(
            'Gitleaks %s (%s). Commits analizados: %d. Hallazgos: commits %d, staged %d, unstaged %d, nuevos %d.',
            $version,
            $modern ? 'git/dir' : 'detect/protect',
            count($changes->commits),
            $counts['commits'],
            $counts['staged'],
            $counts['unstaged'],
            $counts['untracked']
        ));
        $result->status = $result->findings === [] ? Status::PASS : Status::FAIL;
        $result->summary = $result->findings === []
            ? 'No se detectaron secretos en los cambios de la rama.'
            : count($result->findings) . ' posible(s) secreto(s) detectado(s). Los valores se muestran redactados.';
        return $result;
    }

    private function version(string $gitleaks, CheckContext $context): string
    {
        $process = Process::run([$gitleaks, 'version'], $context->projectRoot(), null, 30);
        if (!$process->started()) {
            throw new ToolExecutionException('No se pudo ejecutar Gitleaks.');
        }
        if (preg_match('/(\d+)\.(\d+)\.(\d+)/', $process->stdout() . ' ' . $process->stderr(), $m)) {
            return "{$m[1]}.{$m[2]}.{$m[3]}";
        }
        // Compilaciones sin versión ("dev"): se asume una versión moderna.
        return '8.19.0';
    }

    /**
     * @param array<string, mixed> $item
     * @param array<string, mixed> $scan
     */
    private function toFinding(CheckContext $context, array $item, array $scan): ?Finding
    {
        $file = (string) ($item['File'] ?? '');
        if (isset($scan['file'])) {
            $file = $scan['file'];
        } else {
            $file = $context->changes->relativePath($file);
        }
        if ($file === '' || $context->isExcluded($file)) {
            return null;
        }

        $line = isset($item['StartLine']) ? (int) $item['StartLine'] : null;
        $column = isset($item['StartColumn']) ? (int) $item['StartColumn'] : null;
        // El secreto solo se usa para enmascararlo; nunca se almacena.
        $code = Redactor::maskGitleaksMatch((string) ($item['Match'] ?? ''), (string) ($item['Secret'] ?? ''));

        $commit = trim((string) ($item['Commit'] ?? ''));
        $author = trim((string) ($item['Author'] ?? ''));
        $date = trim((string) ($item['Date'] ?? ''));
        if ($commit === '') {
            $commit = match ($scan['origin']) {
                ChangedFile::ORIGIN_STAGED => 'sin commit (staged)',
                ChangedFile::ORIGIN_UNSTAGED => 'sin commit (unstaged)',
                default => 'sin commit (archivo nuevo)',
            };
            $author = $author !== '' ? $author : $this->localAuthor($context);
            $mtime = @filemtime($context->changes->absolutePath($file));
            $date = $date !== '' ? $date : ($mtime ? date('c', $mtime) . ' (modificación del archivo)' : '');
        }

        $description = trim((string) ($item['Description'] ?? ''));
        $rule = (string) ($item['RuleID'] ?? 'gitleaks');

        return new Finding(
            $file,
            $line,
            $column,
            $rule,
            $description !== '' ? $description : 'Posible secreto detectado por Gitleaks.',
            Finding::SEVERITY_ERROR,
            $code,
            [
                'commit' => $commit,
                'author' => $author,
                'date' => $date,
                'source' => $scan['origin'],
            ]
        );
    }

    private ?string $localAuthor = null;

    private function localAuthor(CheckContext $context): string
    {
        if ($this->localAuthor === null) {
            $name = trim($context->changes->git->run(['config', 'user.name'])->stdout());
            $this->localAuthor = $name !== '' ? $name . ' (usuario Git local)' : 'desconocido';
        }
        return $this->localAuthor;
    }
}
