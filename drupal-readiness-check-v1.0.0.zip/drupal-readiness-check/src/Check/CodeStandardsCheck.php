<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

use ReadinessCheck\Exception\ToolExecutionException;
use ReadinessCheck\Git\ChangedFile;
use ReadinessCheck\Process\Process;
use ReadinessCheck\Support\Json;
use ReadinessCheck\Support\Redactor;

/**
 * code-standards: sintaxis PHP (php -l), sintaxis YAML (symfony/yaml) y
 * estándares Drupal (phpcs + Drupal Coder).
 *
 * Solo los hallazgos en líneas modificadas por la rama se consideran nuevos.
 * Los errores de sintaxis en líneas no modificadas se comparan con la versión
 * del merge-base: si allí el archivo era válido, el error lo causó la rama.
 */
final class CodeStandardsCheck implements CheckInterface
{
    private const PHPCS_CHUNK = 150;

    public function id(): string
    {
        return 'code-standards';
    }

    public function title(): string
    {
        return 'Sintaxis PHP/YAML y estándares Drupal';
    }

    public function run(CheckContext $context): CheckResult
    {
        $result = new CheckResult($this->id(), $this->title());
        $phpFiles = $context->changes->filesWithExtensions($context->settings['php_extensions']);
        $yamlFiles = $context->changes->filesWithExtensions($context->settings['yaml_extensions']);

        if ($phpFiles === [] && $yamlFiles === []) {
            $result->summary = 'No hay archivos PHP ni YAML entre los archivos considerados.';
            $result->addTool('php -l', Status::PASS, 'Sin archivos PHP.');
            $result->addTool('symfony/yaml', Status::PASS, 'Sin archivos YAML.');
            $result->addTool('phpcs', Status::PASS, 'Sin archivos PHP.');
            return $result;
        }

        $executed = 0;
        $executed += $this->phpLint($context, $result, $phpFiles);
        $executed += $this->yamlLint($context, $result, $yamlFiles);
        $executed += $this->phpcs($context, $result, $phpFiles);

        if ($executed === 0) {
            $result->status = Status::OMITTED;
            $result->summary = 'Ninguna herramienta de esta validación está disponible.';
            return $result;
        }

        $statuses = [Status::PASS];
        foreach ($result->findings as $finding) {
            $statuses[] = $finding->severity === Finding::SEVERITY_ERROR ? Status::FAIL : Status::WARN;
        }
        $result->status = Status::worst($statuses);
        $result->summary = sprintf(
            '%d archivo(s) PHP y %d YAML analizados: %d hallazgo(s) nuevo(s), %d preexistente(s).',
            count($phpFiles),
            count($yamlFiles),
            count($result->findings),
            count($result->preexisting)
        );
        return $result;
    }

    /**
     * @param list<ChangedFile> $files
     * @return int 1 si la herramienta se ejecutó.
     */
    private function phpLint(CheckContext $context, CheckResult $result, array $files): int
    {
        if ($files === []) {
            $result->addTool('php -l', Status::PASS, 'Sin archivos PHP.');
            return 1;
        }
        $php = $context->tools->php();
        $tmp = null;
        $errors = 0;
        try {
            foreach ($files as $file) {
                $absolute = $context->changes->absolutePath($file->path);
                $error = $this->lintPhpFile($php, $absolute, $context);
                if ($error === null) {
                    continue;
                }
                $errors++;
                $line = $error['line'];
                $isNew = $file->isLineChanged($line);
                $note = null;
                if (!$isNew) {
                    // El error está en una línea no modificada: ¿ya existía en la base?
                    $base = $context->changes->baseContent($file);
                    if ($base === null) {
                        $isNew = true;
                    } else {
                        $tmp ??= $context->tempDir();
                        $baseFile = $tmp . '/base-' . md5($file->path) . '.' . ($file->extension() ?: 'php');
                        file_put_contents($baseFile, $base);
                        $baseError = $this->lintPhpFile($php, $baseFile, $context);
                        $isNew = $baseError === null;
                        if ($isNew) {
                            $note = 'El error se reporta en una línea no modificada, pero el archivo era válido en la rama base: lo causan los cambios de la rama.';
                        }
                    }
                }
                $finding = new Finding(
                    $file->path,
                    $line,
                    null,
                    'php-lint.' . $error['type'],
                    Redactor::maskSensitiveAssignments($error['message']) . ($note ? ' ' . $note : ''),
                    Finding::SEVERITY_ERROR,
                    $context->codeAt($file->path, $line)
                );
                if ($isNew) {
                    $result->findings[] = $finding;
                } else {
                    $result->preexisting[] = $finding;
                }
            }
        } finally {
            if ($tmp !== null) {
                CheckContext::removeDir($tmp);
            }
        }
        $result->addTool('php -l', Status::PASS, sprintf('%d archivo(s) revisados, %d con errores de sintaxis.', count($files), $errors));
        return 1;
    }

    /**
     * @return array{line: ?int, message: string, type: string}|null
     */
    private function lintPhpFile(string $php, string $path, CheckContext $context): ?array
    {
        $process = Process::run(
            [$php, '-d', 'display_errors=1', '-d', 'error_reporting=-1', '-d', 'log_errors=0', '-l', $path],
            $context->projectRoot(),
            null,
            $context->timeout('php_lint')
        );
        if (!$process->started()) {
            throw new ToolExecutionException('No se pudo ejecutar php -l.');
        }
        if ($process->exitCode() === 0) {
            return null;
        }
        $output = $process->stdout() . "\n" . $process->stderr();
        $pathPattern = preg_quote($path, '/');
        if (preg_match('/(?:PHP\s+)?(Parse error|Fatal error):\s*(.+) in ' . $pathPattern . ' on line (\d+)/', $output, $m)
            || preg_match('/(?:PHP\s+)?(Parse error|Fatal error):\s*(.+?) in .+? on line (\d+)/', $output, $m)) {
            $type = strtolower(str_replace(' ', '-', $m[1]));
            return ['line' => (int) $m[3], 'message' => trim($m[2]), 'type' => $type];
        }
        if (stripos($output, 'Could not open input file') !== false) {
            throw new ToolExecutionException('php -l no pudo abrir el archivo ' . basename($path));
        }
        return ['line' => null, 'message' => trim(preg_replace('/\s+/', ' ', $output) ?? $output), 'type' => 'error'];
    }

    /**
     * @param list<ChangedFile> $files
     */
    private function yamlLint(CheckContext $context, CheckResult $result, array $files): int
    {
        if ($files === []) {
            $result->addTool('symfony/yaml', Status::PASS, 'Sin archivos YAML.');
            return 1;
        }
        $autoload = $context->tools->yamlAutoload();
        if ($autoload === null) {
            $result->addTool('symfony/yaml', Status::OMITTED, 'symfony/yaml no está disponible (no se encontró vendor/symfony/yaml en el proyecto).');
            return 0;
        }

        $items = [];
        foreach ($files as $index => $file) {
            $items[] = ['id' => 'w' . $index, 'path' => $context->changes->absolutePath($file->path)];
        }
        $current = $this->runYamlHelper($context, $autoload, $items);
        if ($current === null) {
            $result->addTool('symfony/yaml', Status::OMITTED, 'symfony/yaml no pudo cargarse desde el autoload del proyecto.');
            return 0;
        }

        $tmp = null;
        $errors = 0;
        try {
            foreach ($files as $index => $file) {
                $res = $current['w' . $index] ?? null;
                if ($res === null || $res['ok']) {
                    continue;
                }
                $errors++;
                $line = $res['line'];
                $isNew = $file->isLineChanged($line);
                $note = null;
                if (!$isNew) {
                    $base = $context->changes->baseContent($file);
                    if ($base === null) {
                        $isNew = true;
                    } else {
                        $tmp ??= $context->tempDir();
                        $baseFile = $tmp . '/base-' . $index . '.yml';
                        file_put_contents($baseFile, $base);
                        $baseRes = $this->runYamlHelper($context, $autoload, [['id' => 'b', 'path' => $baseFile]]);
                        $isNew = ($baseRes['b']['ok'] ?? false) === true;
                        if ($isNew) {
                            $note = 'El archivo era válido en la rama base: el error lo causan los cambios de la rama.';
                        }
                    }
                }
                $finding = new Finding(
                    $file->path,
                    $line,
                    null,
                    'yaml.syntax',
                    Redactor::maskSensitiveAssignments((string) $res['message']) . ($note ? ' ' . $note : ''),
                    Finding::SEVERITY_ERROR,
                    $context->codeAt($file->path, $line)
                );
                if ($isNew) {
                    $result->findings[] = $finding;
                } else {
                    $result->preexisting[] = $finding;
                }
            }
        } finally {
            if ($tmp !== null) {
                CheckContext::removeDir($tmp);
            }
        }
        $result->addTool('symfony/yaml', Status::PASS, sprintf('%d archivo(s) YAML revisados, %d con errores.', count($files), $errors));
        return 1;
    }

    /**
     * @param list<array{id: string, path: string}> $items
     * @return array<string, array{ok: bool, line: ?int, message: string}>|null
     */
    private function runYamlHelper(CheckContext $context, string $autoload, array $items): ?array
    {
        $process = Process::run(
            [$context->tools->php(), $context->toolRoot . '/bin/yaml-lint', $autoload],
            $context->projectRoot(),
            (string) json_encode($items, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            $context->timeout('php_lint')
        );
        $data = Json::decodeLenient($process->stdout());
        if ($data === null) {
            throw new ToolExecutionException('La validación YAML falló: ' . $process->errorSummary());
        }
        if (isset($data['error'])) {
            return null;
        }
        $map = [];
        foreach ($data['results'] ?? [] as $row) {
            $map[(string) $row['id']] = [
                'ok' => (bool) $row['ok'],
                'line' => isset($row['line']) ? (int) $row['line'] : null,
                'message' => (string) ($row['message'] ?? ''),
            ];
        }
        return $map;
    }

    /**
     * @param list<ChangedFile> $files
     */
    private function phpcs(CheckContext $context, CheckResult $result, array $files): int
    {
        if ($files === []) {
            $result->addTool('phpcs', Status::PASS, 'Sin archivos PHP.');
            return 1;
        }
        $phpcs = $context->tools->phpcs();
        if ($phpcs === null) {
            $result->addTool('phpcs', Status::OMITTED, 'phpcs no está instalado. Instale drupal/coder como dependencia de desarrollo.');
            return 0;
        }

        $root = $context->projectRoot();
        $standardArgs = [];
        $projectConfig = null;
        foreach ($context->settings['phpcs_project_configs'] as $config) {
            if (is_file($root . '/' . $config)) {
                $projectConfig = $config;
                break;
            }
        }
        if ($projectConfig !== null) {
            // phpcs detecta el archivo automáticamente al ejecutarse desde la raíz.
            $standardLabel = $projectConfig . ' del proyecto';
        } else {
            $installed = Process::run([$phpcs, '-i'], $root, null, 60);
            if (!$installed->isSuccessful()) {
                throw new ToolExecutionException('phpcs -i falló: ' . $installed->errorSummary());
            }
            if (!preg_match('/\bDrupal\b/', $installed->stdout())) {
                $result->addTool('phpcs', Status::OMITTED, 'El estándar Drupal (Drupal Coder) no está instalado en phpcs.');
                return 0;
            }
            $standard = (string) $context->settings['phpcs_default_standard'];
            if (!preg_match('/\bDrupalPractice\b/', $installed->stdout())) {
                $standard = 'Drupal';
            }
            $standardArgs[] = '--standard=' . $standard;
            $standardLabel = $standard;
        }

        $extensions = implode(',', $context->settings['php_extensions']);
        $totalMessages = 0;
        foreach (array_chunk($files, self::PHPCS_CHUNK) as $chunk) {
            $command = array_merge(
                [$phpcs, '--report=json', '-q', '--no-colors', '--encoding=utf-8', '--extensions=' . $extensions],
                $standardArgs
            );
            foreach ($chunk as $file) {
                $command[] = $context->changes->absolutePath($file->path);
            }
            $process = Process::run($command, $root, null, $context->timeout('phpcs'));
            $data = Json::decodeLenient($process->stdout());
            if ($data === null || !isset($data['files'])) {
                throw new ToolExecutionException('phpcs no devolvió un reporte JSON válido (código ' . $process->exitCode() . '): ' . $process->errorSummary());
            }
            foreach ($data['files'] as $path => $info) {
                $relative = $context->changes->relativePath((string) $path);
                foreach ($info['messages'] ?? [] as $message) {
                    $totalMessages++;
                    $line = isset($message['line']) ? (int) $message['line'] : null;
                    $isError = strtoupper((string) ($message['type'] ?? 'ERROR')) === 'ERROR';
                    $finding = new Finding(
                        $relative,
                        $line,
                        isset($message['column']) ? (int) $message['column'] : null,
                        (string) ($message['source'] ?? 'phpcs'),
                        Redactor::maskSensitiveAssignments((string) ($message['message'] ?? '')),
                        $isError ? Finding::SEVERITY_ERROR : Finding::SEVERITY_WARNING,
                        $context->codeAt($relative, $line),
                        ['fixable' => !empty($message['fixable'])]
                    );
                    if ($context->changes->isLineChanged($relative, $line)) {
                        $result->findings[] = $finding;
                    } else {
                        $result->preexisting[] = $finding;
                    }
                }
            }
        }

        $result->addTool('phpcs', Status::PASS, sprintf('Estándar: %s. %d archivo(s), %d mensaje(s).', $standardLabel, count($files), $totalMessages));
        return 1;
    }
}
