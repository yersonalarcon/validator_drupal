<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

use ReadinessCheck\Exception\ToolExecutionException;
use ReadinessCheck\Process\Process;
use ReadinessCheck\Support\Json;

/**
 * config-status (opcional): diferencias entre la configuración activa y la
 * del directorio de sincronización, mediante `drush config:status`.
 *
 * Las diferencias se informan como WARN: pueden ser legítimas (configuración
 * pendiente de importar o de exportar) y requieren revisión humana.
 */
final class ConfigStatusCheck implements CheckInterface
{
    public function id(): string
    {
        return 'config-status';
    }

    public function title(): string
    {
        return 'Estado de la configuración (drush config:status)';
    }

    public function run(CheckContext $context): CheckResult
    {
        $result = new CheckResult($this->id(), $this->title());
        $drush = $context->tools->drush();
        if ($drush === null) {
            $result->addTool('drush', Status::OMITTED, 'Drush no está instalado.');
            $result->status = Status::OMITTED;
            $result->summary = 'Drush no está disponible.';
            return $result;
        }

        $command = [$drush, 'config:status', '--format=json', '--no-interaction'];
        if ($context->options->uri !== null) {
            $command[] = '--uri=' . $context->options->uri;
        }
        $process = Process::run($command, $context->projectRoot(), null, $context->timeout('drush'));
        if (!$process->isSuccessful()) {
            throw new ToolExecutionException('drush config:status falló (código ' . $process->exitCode() . '): ' . $process->errorSummary());
        }
        $result->addTool('drush', Status::PASS, 'drush config:status');

        $data = [];
        if (trim($process->stdout()) !== '') {
            $data = Json::decodeLenient($process->stdout());
            if ($data === null) {
                throw new ToolExecutionException('La salida de drush config:status no es JSON válido.');
            }
        }

        foreach ($data as $key => $row) {
            if (!is_array($row)) {
                continue;
            }
            $name = (string) ($row['name'] ?? $key);
            $state = (string) ($row['state'] ?? 'Diferente');
            $result->findings[] = new Finding(
                $name . '.yml',
                null,
                null,
                'config-status',
                "Configuración '{$name}': {$state}.",
                Finding::SEVERITY_WARNING,
                null,
                ['config' => $name, 'state' => $state]
            );
        }

        $result->status = $result->findings === [] ? Status::PASS : Status::WARN;
        $result->summary = $result->findings === []
            ? 'La configuración activa coincide con el directorio de sincronización.'
            : count($result->findings) . ' diferencia(s) entre la base de datos y el directorio de sincronización.';
        return $result;
    }
}
