<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

use ReadinessCheck\Git\ChangeSet;
use ReadinessCheck\Options;
use ReadinessCheck\Support\Redactor;
use ReadinessCheck\Support\ToolLocator;

/**
 * Información compartida por todas las validaciones de una ejecución.
 */
final class CheckContext
{
    /**
     * @param array<string, mixed> $settings
     * @param list<string> $excludePrefixes
     */
    public function __construct(
        public Options $options,
        public ChangeSet $changes,
        public array $settings,
        public ToolLocator $tools,
        public Redactor $redactor,
        public string $toolRoot,
        public array $excludePrefixes = []
    ) {
    }

    /**
     * Indica si una ruta relativa pertenece a los archivos excluidos
     * (el propio validador, el comando DDEV instalado…).
     */
    public function isExcluded(string $relativePath): bool
    {
        foreach ($this->excludePrefixes as $prefix) {
            $prefix = rtrim($prefix, '/');
            if ($prefix !== '' && ($relativePath === $prefix || str_starts_with($relativePath, $prefix . '/'))) {
                return true;
            }
        }
        return false;
    }

    public function projectRoot(): string
    {
        return $this->changes->git->root();
    }

    public function timeout(string $tool): int
    {
        return (int) ($this->settings['timeouts'][$tool] ?? 600);
    }

    /**
     * Lee una línea del archivo del árbol de trabajo, con secretos enmascarados.
     */
    public function codeAt(string $relativePath, ?int $line): ?string
    {
        if ($line === null || $line < 1) {
            return null;
        }
        $absolute = $this->changes->absolutePath($relativePath);
        if (!is_file($absolute) || !is_readable($absolute)) {
            return null;
        }
        $handle = fopen($absolute, 'rb');
        if ($handle === false) {
            return null;
        }
        $current = 0;
        $text = null;
        while (($row = fgets($handle)) !== false) {
            if (++$current === $line) {
                $text = rtrim($row, "\r\n");
                break;
            }
        }
        fclose($handle);
        if ($text === null) {
            return null;
        }
        return $this->redactor->maskCode($relativePath, $line, $text);
    }

    /**
     * Crea un directorio temporal privado para la ejecución.
     */
    public function tempDir(): string
    {
        $dir = sys_get_temp_dir() . '/readiness-check-' . bin2hex(random_bytes(6));
        if (!mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new \RuntimeException('No se pudo crear un directorio temporal.');
        }
        return $dir;
    }

    public static function removeDir(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($items as $item) {
            $item->isDir() && !$item->isLink() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
        }
        @rmdir($dir);
    }
}
