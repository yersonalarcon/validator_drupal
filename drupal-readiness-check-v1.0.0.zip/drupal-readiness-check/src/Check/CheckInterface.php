<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

/**
 * Contrato de una validación.
 *
 * Una validación nunca modifica archivos del proyecto ni corrige errores.
 * Si una herramienta necesaria no está instalada debe devolver OMITTED.
 * Si la herramienta existe pero falla, debe lanzar ToolExecutionException.
 */
interface CheckInterface
{
    public function id(): string;

    public function title(): string;

    public function run(CheckContext $context): CheckResult;
}
