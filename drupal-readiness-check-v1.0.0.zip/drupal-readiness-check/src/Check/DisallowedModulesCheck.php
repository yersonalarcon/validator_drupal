<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

use ReadinessCheck\Git\ChangedFile;

/**
 * disallowed-modules (opcional): detecta módulos prohibidos (lista
 * configurable en config/disallowed-modules.txt) en los archivos considerados:
 *
 *  - core.extension.yml: módulos habilitados en la configuración.
 *  - composer.json: paquetes drupal/<módulo>.
 *  - *.info.yml: dependencias declaradas.
 *  - <módulo>.info.yml: el propio módulo añadido al código.
 *
 * Solo las apariciones en líneas modificadas por la rama producen FAIL.
 */
final class DisallowedModulesCheck implements CheckInterface
{
    public function id(): string
    {
        return 'disallowed-modules';
    }

    public function title(): string
    {
        return 'Módulos prohibidos';
    }

    public function run(CheckContext $context): CheckResult
    {
        $result = new CheckResult($this->id(), $this->title());
        $listFile = $this->resolvePath($context, (string) $context->settings['disallowed_modules_file']);
        if (!is_file($listFile)) {
            $result->addTool('lista', Status::OMITTED, 'No existe la lista de módulos prohibidos: ' . basename($listFile));
            $result->status = Status::OMITTED;
            $result->summary = 'No hay lista de módulos prohibidos configurada.';
            return $result;
        }
        $disallowed = $this->readList($listFile);
        $result->addTool('lista', Status::PASS, count($disallowed) . ' módulo(s) prohibido(s) configurado(s).');
        if ($disallowed === []) {
            $result->summary = 'La lista de módulos prohibidos está vacía.';
            return $result;
        }

        $examined = 0;
        foreach ($context->changes->files() as $path => $file) {
            $base = basename($path);
            if ($base === 'core.extension.yml') {
                $examined++;
                $this->scan($context, $result, $file, $disallowed, '/^\s{2}([a-z][a-z0-9_]*)\s*:\s*-?\d+\s*$/', 'enabled-in-config', 'habilitado en core.extension.yml');
            } elseif ($base === 'composer.json') {
                $examined++;
                $this->scan($context, $result, $file, $disallowed, '/"drupal\/([a-z][a-z0-9_]*)"\s*:/', 'composer-require', 'requerido en composer.json');
            } elseif (str_ends_with($base, '.info.yml')) {
                $examined++;
                $this->scan($context, $result, $file, $disallowed, '/^\s*-\s*["\']?(?:[a-z][a-z0-9_]*:)?([a-z][a-z0-9_]*)\b/', 'info-dependency', 'declarado como dependencia');
                $module = substr($base, 0, -strlen('.info.yml'));
                if (in_array($module, $disallowed, true)) {
                    $finding = new Finding($path, 1, 1, 'module-code', "El módulo prohibido '{$module}' está incluido en el código.", Finding::SEVERITY_ERROR, $context->codeAt($path, 1), ['module' => $module]);
                    if ($file->newFile) {
                        $result->findings[] = $finding;
                    } else {
                        $result->preexisting[] = $finding;
                    }
                }
            }
        }

        $result->status = $result->findings === [] ? Status::PASS : Status::FAIL;
        $result->summary = sprintf(
            '%d archivo(s) relevantes revisados: %d aparición(es) nueva(s), %d preexistente(s).',
            $examined,
            count($result->findings),
            count($result->preexisting)
        );
        return $result;
    }

    /**
     * @param list<string> $disallowed
     */
    private function scan(CheckContext $context, CheckResult $result, ChangedFile $file, array $disallowed, string $pattern, string $rule, string $label): void
    {
        $absolute = $context->changes->absolutePath($file->path);
        $lines = @file($absolute, FILE_IGNORE_NEW_LINES);
        if ($lines === false) {
            return;
        }
        $inModuleSection = !str_ends_with($file->path, 'core.extension.yml');
        $inDependencies = !str_ends_with($file->path, '.info.yml');
        foreach ($lines as $index => $text) {
            $lineNumber = $index + 1;
            if (str_ends_with($file->path, 'core.extension.yml') && preg_match('/^(\S[^:]*):/', $text, $section)) {
                $inModuleSection = trim($section[1]) === 'module';
                continue;
            }
            if (str_ends_with($file->path, '.info.yml') && preg_match('/^(\S[^:]*):/', $text, $section)) {
                $inDependencies = in_array(trim($section[1]), ['dependencies', 'test_dependencies'], true);
                continue;
            }
            if (!$inModuleSection || !$inDependencies) {
                continue;
            }
            if (!preg_match($pattern, $text, $m) || !in_array($m[1], $disallowed, true)) {
                continue;
            }
            $column = strpos($text, $m[1]);
            $finding = new Finding(
                $file->path,
                $lineNumber,
                $column === false ? null : $column + 1,
                $rule,
                "Módulo prohibido '{$m[1]}' {$label}.",
                Finding::SEVERITY_ERROR,
                $context->codeAt($file->path, $lineNumber),
                ['module' => $m[1]]
            );
            if ($file->isLineChanged($lineNumber)) {
                $result->findings[] = $finding;
            } else {
                $result->preexisting[] = $finding;
            }
        }
    }

    /**
     * @return list<string>
     */
    private function readList(string $file): array
    {
        $modules = [];
        foreach (file($file, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
            $line = trim(preg_replace('/#.*$/', '', $line) ?? '');
            if ($line !== '' && preg_match('/^[a-z][a-z0-9_]*$/', $line)) {
                $modules[] = $line;
            }
        }
        return array_values(array_unique($modules));
    }

    private function resolvePath(CheckContext $context, string $path): string
    {
        if (str_starts_with($path, 'tool:')) {
            return $context->toolRoot . '/' . ltrim(substr($path, 5), '/');
        }
        return $context->projectRoot() . '/' . ltrim($path, '/');
    }
}
