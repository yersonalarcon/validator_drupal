<?php

declare(strict_types=1);

namespace ReadinessCheck\Check;

/**
 * Estados posibles de una validación.
 */
final class Status
{
    public const PASS = 'PASS';
    public const WARN = 'WARN';
    public const FAIL = 'FAIL';
    public const OMITTED = 'OMITTED';

    private const WEIGHT = [
        self::OMITTED => 0,
        self::PASS => 1,
        self::WARN => 2,
        self::FAIL => 3,
    ];

    /**
     * Devuelve el estado más grave de la lista (OMITTED si no hay ninguno).
     *
     * @param list<string> $statuses
     */
    public static function worst(array $statuses): string
    {
        $worst = self::OMITTED;
        foreach ($statuses as $status) {
            if (self::WEIGHT[$status] > self::WEIGHT[$worst]) {
                $worst = $status;
            }
        }
        return $worst;
    }

    public static function describe(string $status): string
    {
        return match ($status) {
            self::PASS => 'aprobado',
            self::WARN => 'advertencia',
            self::FAIL => 'error que bloquea',
            self::OMITTED => 'validación omitida',
            default => $status,
        };
    }
}
