<?php

declare(strict_types=1);

namespace ReadinessCheck\Support;

/**
 * Utilidades para interpretar JSON emitido por herramientas externas, que a
 * veces viene precedido de avisos o mensajes de progreso.
 */
final class Json
{
    /**
     * Decodifica JSON tolerando texto antes del primer '{' o '['.
     *
     * @return array<mixed>|null null si no hay JSON válido.
     */
    public static function decodeLenient(string $output): ?array
    {
        $output = trim($output);
        if ($output === '') {
            return null;
        }
        $data = json_decode($output, true);
        if (is_array($data)) {
            return $data;
        }
        foreach (['{', '['] as $opening) {
            $pos = strpos($output, $opening);
            while ($pos !== false) {
                $data = json_decode(substr($output, $pos), true);
                if (is_array($data)) {
                    return $data;
                }
                $pos = strpos($output, $opening, $pos + 1);
            }
        }
        return null;
    }
}
