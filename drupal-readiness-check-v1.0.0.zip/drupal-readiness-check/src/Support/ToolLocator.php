<?php

declare(strict_types=1);

namespace ReadinessCheck\Support;

use ReadinessCheck\Process\Process;

/**
 * Localiza las herramientas externas sin rutas absolutas fijas.
 *
 * Orden de búsqueda:
 *  1. Variable de entorno READINESS_<HERRAMIENTA> (instalaciones personalizadas).
 *  2. Binario del proyecto (vendor/bin) o del validador (bin/gitleaks).
 *  3. PATH del sistema.
 */
final class ToolLocator
{
    /** @var array<string, string|null> */
    private array $cache = [];

    public function __construct(private string $projectRoot, private string $toolRoot)
    {
    }

    public function php(): string
    {
        return PHP_BINARY !== '' ? PHP_BINARY : 'php';
    }

    public function drush(): ?string
    {
        return $this->find('drush', [$this->vendorBin() . '/drush']);
    }

    public function phpcs(): ?string
    {
        return $this->find('phpcs', [$this->vendorBin() . '/phpcs']);
    }

    public function gitleaks(): ?string
    {
        return $this->find('gitleaks', [$this->toolRoot . '/bin/gitleaks']);
    }

    public function composer(): ?string
    {
        return $this->find('composer', []);
    }

    /**
     * Ruta del autoload de Composer que provee symfony/yaml.
     */
    public function yamlAutoload(): ?string
    {
        $override = getenv('READINESS_YAML_AUTOLOAD');
        if (is_string($override) && $override !== '') {
            return is_file($override) ? $override : null;
        }
        $autoload = $this->vendorDir() . '/autoload.php';
        if (!is_file($autoload)) {
            return null;
        }
        // Comprobación rápida sin cargar el autoload en este proceso.
        if (!is_dir($this->vendorDir() . '/symfony/yaml')) {
            return null;
        }
        return $autoload;
    }

    public function vendorDir(): string
    {
        $vendor = 'vendor';
        $composerJson = $this->projectRoot . '/composer.json';
        if (is_file($composerJson)) {
            $data = json_decode((string) file_get_contents($composerJson), true);
            if (is_array($data) && isset($data['config']['vendor-dir']) && is_string($data['config']['vendor-dir'])) {
                $vendor = trim($data['config']['vendor-dir'], '/');
            }
        }
        return $this->projectRoot . '/' . $vendor;
    }

    private function vendorBin(): string
    {
        return $this->vendorDir() . '/bin';
    }

    /**
     * @param list<string> $candidates
     */
    private function find(string $name, array $candidates): ?string
    {
        if (array_key_exists($name, $this->cache)) {
            return $this->cache[$name];
        }
        $env = getenv('READINESS_' . strtoupper($name));
        if (is_string($env) && $env !== '') {
            // Un valor explícito que no existe se trata como "no instalado".
            return $this->cache[$name] = (is_file($env) && is_executable($env)) ? $env : null;
        }
        foreach ($candidates as $candidate) {
            if (is_file($candidate) && is_executable($candidate)) {
                return $this->cache[$name] = $candidate;
            }
        }
        return $this->cache[$name] = Process::findExecutable($name);
    }
}
