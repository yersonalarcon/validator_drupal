<?php

declare(strict_types=1);

namespace ReadinessCheck\Support;

/**
 * Evita que los reportes y la consola muestren secretos.
 *
 * - Las líneas donde Gitleaks detectó un secreto se reemplazan por completo
 *   en cualquier validación.
 * - Como defensa adicional, los valores asignados a claves con nombres
 *   sensibles (password, token, api_key…) se enmascaran en todo fragmento
 *   de código mostrado.
 */
final class Redactor
{
    public const MASK = '****REDACTED****';

    /** @var array<string, array<int, true>> */
    private array $secretLines = [];

    public function markSecretLine(string $file, ?int $line): void
    {
        if ($line !== null) {
            $this->secretLines[$file][$line] = true;
        }
    }

    public function isSecretLine(string $file, ?int $line): bool
    {
        return $line !== null && isset($this->secretLines[$file][$line]);
    }

    public function maskCode(string $file, ?int $line, string $code): string
    {
        if ($this->isSecretLine($file, $line)) {
            return self::MASK . ' (línea con secreto detectado)';
        }
        return self::maskSensitiveAssignments(self::truncate($code));
    }

    /**
     * Enmascara la salida "Match" de Gitleaks (ya redactada con --redact).
     */
    public static function maskGitleaksMatch(string $match, string $secret): string
    {
        $text = $match;
        if ($secret !== '' && $secret !== 'REDACTED' && strlen($secret) >= 4) {
            $text = str_replace($secret, self::MASK, $text);
        }
        // Gitleaks reemplaza el secreto por "REDACTED"; se normaliza a la máscara.
        $text = preg_replace('/(?<!\*)REDACTED(?!\*)/', self::MASK, $text) ?? $text;
        return self::truncate($text);
    }

    public static function maskSensitiveAssignments(string $code): string
    {
        $pattern = '/((?:pass(?:word|wd)?|secret|token|api[_-]?key|private[_-]?key|client[_-]?secret|auth|salt)[A-Za-z0-9_\-]*(?:["\']\]?)?\s*(?:=>|=|:)\s*)(["\']?)((?!\$)[^"\'\s,;)]+)(\2)/i';
        return preg_replace_callback(
            $pattern,
            static fn (array $m): string => $m[1] . $m[2] . self::MASK . $m[4],
            $code
        ) ?? $code;
    }

    public static function truncate(string $code, int $max = 240): string
    {
        $code = trim($code);
        if (mb_strlen($code) > $max) {
            return mb_substr($code, 0, $max) . '…';
        }
        return $code;
    }
}
