<?php

declare(strict_types=1);

namespace ReadinessCheck\Process;

use ReadinessCheck\Exception\ExecutionException;

/**
 * Ejecuta comandos externos sin pasar por una shell.
 *
 * Los argumentos se entregan como array a proc_open(), por lo que las rutas
 * con espacios, tildes o caracteres especiales no necesitan escaparse y no
 * existe riesgo de inyección de comandos.
 */
final class Process
{
    /**
     * @param list<string> $command
     * @param array<string, string>|null $env Variables adicionales.
     */
    public static function run(
        array $command,
        ?string $cwd = null,
        ?string $stdin = null,
        int $timeoutSeconds = 600,
        ?array $env = null
    ): ProcessResult {
        if ($command === []) {
            throw new ExecutionException('No se indicó ningún comando para ejecutar.');
        }

        $descriptors = [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];

        $fullEnv = null;
        if ($env !== null) {
            $fullEnv = getenv();
            foreach ($env as $key => $value) {
                $fullEnv[$key] = $value;
            }
        }

        $pipes = [];
        $process = @proc_open($command, $descriptors, $pipes, $cwd, $fullEnv);
        if (!is_resource($process)) {
            return new ProcessResult($command, 127, '', 'No fue posible iniciar el proceso: ' . $command[0], false);
        }

        if ($stdin !== null && $stdin !== '') {
            fwrite($pipes[0], $stdin);
        }
        fclose($pipes[0]);

        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);

        $stdout = '';
        $stderr = '';
        $start = microtime(true);
        $timedOut = false;
        $open = [1 => $pipes[1], 2 => $pipes[2]];

        while ($open !== []) {
            $read = array_values($open);
            $write = null;
            $except = null;
            $changed = @stream_select($read, $write, $except, 1, 0);
            if ($changed === false) {
                break;
            }
            foreach ($open as $index => $pipe) {
                $chunk = fread($pipe, 65536);
                if ($chunk !== false && $chunk !== '') {
                    if ($index === 1) {
                        $stdout .= $chunk;
                    } else {
                        $stderr .= $chunk;
                    }
                }
                if (feof($pipe)) {
                    fclose($pipe);
                    unset($open[$index]);
                }
            }
            if ((microtime(true) - $start) > $timeoutSeconds) {
                $timedOut = true;
                foreach ($open as $pipe) {
                    fclose($pipe);
                }
                $open = [];
                proc_terminate($process, 9);
            }
        }

        $exitCode = proc_close($process);
        if ($timedOut) {
            $exitCode = 124;
            $stderr .= "\nTiempo de ejecución agotado ({$timeoutSeconds}s).";
        }

        return new ProcessResult($command, $exitCode, $stdout, $stderr, true);
    }

    /**
     * Busca un ejecutable en el PATH.
     */
    public static function findExecutable(string $name): ?string
    {
        if (str_contains($name, '/')) {
            return is_file($name) && is_executable($name) ? $name : null;
        }
        $path = getenv('PATH') ?: '';
        foreach (explode(PATH_SEPARATOR, $path) as $dir) {
            if ($dir === '') {
                continue;
            }
            $candidate = rtrim($dir, '/') . '/' . $name;
            if (is_file($candidate) && is_executable($candidate)) {
                return $candidate;
            }
        }
        return null;
    }
}
