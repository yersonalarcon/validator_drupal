<?php

declare(strict_types=1);

namespace ReadinessCheck\Process;

/**
 * Resultado inmutable de la ejecución de un proceso externo.
 */
final class ProcessResult
{
    /**
     * @param list<string> $command
     */
    public function __construct(
        private array $command,
        private int $exitCode,
        private string $stdout,
        private string $stderr,
        private bool $started
    ) {
    }

    /** @return list<string> */
    public function command(): array
    {
        return $this->command;
    }

    public function exitCode(): int
    {
        return $this->exitCode;
    }

    public function stdout(): string
    {
        return $this->stdout;
    }

    public function stderr(): string
    {
        return $this->stderr;
    }

    public function started(): bool
    {
        return $this->started;
    }

    public function isSuccessful(): bool
    {
        return $this->started && $this->exitCode === 0;
    }

    /**
     * Devuelve un resumen corto del error para mensajes al usuario.
     */
    public function errorSummary(int $maxLength = 400): string
    {
        $text = trim($this->stderr) !== '' ? trim($this->stderr) : trim($this->stdout);
        if (mb_strlen($text) > $maxLength) {
            $text = mb_substr($text, 0, $maxLength) . '…';
        }
        return $text;
    }
}
