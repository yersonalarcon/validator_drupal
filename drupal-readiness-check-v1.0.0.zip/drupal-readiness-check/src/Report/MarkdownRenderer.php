<?php

declare(strict_types=1);

namespace ReadinessCheck\Report;

/**
 * Genera el reporte Markdown a partir de la estructura del reporte.
 */
final class MarkdownRenderer
{
    private const ICON = [
        'PASS' => '✅',
        'WARN' => '⚠️',
        'FAIL' => '❌',
        'OMITTED' => '⏭️',
    ];

    /**
     * @param array<string, mixed> $report
     */
    public function render(array $report): string
    {
        $p = $report['project'];
        $out = [];
        $out[] = '# Reporte de alistamiento técnico';
        $out[] = '';
        if ($report['mode'] === 'demo') {
            $out[] = '> **MODO DEMO:** este reporte contiene datos ficticios de ejemplo. No se ejecutó Git, Drush ni ninguna otra herramienta.';
            $out[] = '';
        }
        $status = $report['result']['status'];
        $out[] = sprintf('**Resultado global:** %s %s (código de salida %d)', self::ICON[$status] ?? '', $status, $report['result']['exit_code']);
        $out[] = '';
        $out[] = $report['result']['message'];
        $out[] = '';
        $out[] = '## Contexto';
        $out[] = '';
        $out[] = '| Dato | Valor |';
        $out[] = '|---|---|';
        $out[] = '| Commit del proyecto | `' . $p['commit'] . '` |';
        $out[] = '| Rama actual | `' . $this->cell($p['branch']) . '` |';
        $out[] = '| Rama base | `' . $this->cell($p['base']) . '` (`' . substr((string) $p['base_commit'], 0, 12) . '`) |';
        $out[] = '| Merge-base | `' . $p['merge_base'] . '` |';
        $out[] = '| Alcance | ' . $p['scope'] . ' |';
        $out[] = '| URI Drush | ' . ($p['uri'] !== null ? '`' . $this->cell($p['uri']) . '`' : '(por defecto)') . ' |';
        $out[] = '| Falla con | ' . $p['fail_on'] . ' |';
        $out[] = '| Generado | ' . $report['generated_at'] . ' |';
        $out[] = '| Herramienta | ' . $report['tool']['name'] . ' ' . $report['tool']['version'] . ' |';
        $out[] = '';

        $out[] = '## Commits de la rama (' . count($report['commits']) . ')';
        $out[] = '';
        if ($report['commits'] === []) {
            $out[] = '_No hay commits posteriores al merge-base._';
        } else {
            $out[] = '| Commit | Autor | Fecha | Asunto |';
            $out[] = '|---|---|---|---|';
            foreach ($report['commits'] as $c) {
                $out[] = sprintf('| `%s` | %s | %s | %s |', substr($c['hash'], 0, 12), $this->cell($c['author']), $c['date'], $this->cell($c['subject']));
            }
        }
        $out[] = '';

        $out[] = '## Archivos considerados (' . count($report['files']) . ')';
        $out[] = '';
        if ($report['files'] === []) {
            $out[] = '_No hay archivos modificados._';
        } else {
            $out[] = '| Archivo | Origen | Líneas modificadas |';
            $out[] = '|---|---|---|';
            foreach ($report['files'] as $f) {
                $out[] = sprintf('| `%s` | %s | %s |', $this->cell($f['path']), implode(', ', $f['origins']), $f['changed_lines'] === '' ? '—' : $this->cell((string) $f['changed_lines']));
            }
        }
        if (!empty($report['excluded_files'])) {
            $out[] = '';
            $out[] = 'Archivos excluidos (propios del validador): ' . count($report['excluded_files']) . '.';
        }
        $out[] = '';

        $out[] = '## Resumen de validaciones';
        $out[] = '';
        $out[] = '| Validación | Estado | Nuevos | Preexistentes | Resumen |';
        $out[] = '|---|---|---|---|---|';
        foreach ($report['checks'] as $check) {
            $out[] = sprintf(
                '| %s | %s %s | %d | %d | %s |',
                $check['id'],
                self::ICON[$check['status']] ?? '',
                $check['status'],
                count($check['findings']),
                count($check['preexisting']),
                $this->cell($check['summary'])
            );
        }
        $out[] = '';

        foreach ($report['checks'] as $check) {
            $out[] = '## ' . $check['id'] . ' — ' . $check['title'];
            $out[] = '';
            $out[] = '**Estado:** ' . (self::ICON[$check['status']] ?? '') . ' ' . $check['status'] . ' — ' . $check['summary'];
            $out[] = '';
            if ($check['tools'] !== []) {
                $out[] = '**Herramientas:**';
                $out[] = '';
                foreach ($check['tools'] as $tool) {
                    $out[] = sprintf('- `%s`: %s — %s', $tool['name'], $tool['status'], $tool['detail']);
                }
                $out[] = '';
            }
            foreach ($check['notes'] as $note) {
                $out[] = '> ' . $note;
                $out[] = '';
            }
            if ($check['findings'] !== []) {
                $out[] = '### Hallazgos nuevos (introducidos por la rama)';
                $out[] = '';
                $out = array_merge($out, $this->findings($check['findings']));
            }
            if ($check['preexisting'] !== []) {
                $out[] = '### Errores preexistentes (líneas no modificadas; no bloquean)';
                $out[] = '';
                $out = array_merge($out, $this->findings($check['preexisting']));
            }
        }

        return implode("\n", $out) . "\n";
    }

    /**
     * @param list<array<string, mixed>> $findings
     * @return list<string>
     */
    private function findings(array $findings): array
    {
        $out = [];
        foreach ($findings as $i => $f) {
            $location = $f['file'] . ($f['line'] !== null ? ':' . $f['line'] : '') . ($f['column'] !== null ? ':' . $f['column'] : '');
            $out[] = sprintf('%d. **`%s`** — %s', $i + 1, $this->inline($location), $f['severity'] === 'error' ? 'error' : 'advertencia');
            $out[] = '   - Archivo: `' . $this->inline($f['file']) . '`';
            $out[] = '   - Línea: ' . ($f['line'] ?? '—') . ' · Columna: ' . ($f['column'] ?? '—');
            $out[] = '   - Regla: `' . $this->inline((string) $f['rule']) . '`';
            $out[] = '   - Mensaje: ' . $this->text((string) $f['message']);
            foreach (['commit' => 'Commit', 'author' => 'Autor', 'date' => 'Fecha', 'function' => 'Función', 'origin' => 'Origen', 'module' => 'Módulo'] as $key => $label) {
                if (isset($f[$key]) && $f[$key] !== '') {
                    $out[] = '   - ' . $label . ': ' . $this->text((string) $f[$key]);
                }
            }
            if (isset($f['code']) && $f['code'] !== null && $f['code'] !== '') {
                $out[] = '   - Código:';
                $out[] = '';
                $out[] = '     ```';
                $out[] = '     ' . str_replace('```', "'''", (string) $f['code']);
                $out[] = '     ```';
            }
            $out[] = '';
        }
        return $out;
    }

    private function cell(string $text): string
    {
        return str_replace(['|', "\n", "\r"], ['\\|', ' ', ' '], $text);
    }

    private function inline(string $text): string
    {
        return str_replace(['`', "\n"], ["'", ' '], $text);
    }

    private function text(string $text): string
    {
        return str_replace(["\n", "\r"], ' ', $text);
    }
}
