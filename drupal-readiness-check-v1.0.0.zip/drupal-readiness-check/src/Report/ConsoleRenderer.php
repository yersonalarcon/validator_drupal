<?php

declare(strict_types=1);

namespace ReadinessCheck\Report;

/**
 * Salida resumida para la terminal.
 */
final class ConsoleRenderer
{
    private const COLORS = [
        'PASS' => "\033[32m",
        'WARN' => "\033[33m",
        'FAIL' => "\033[31m",
        'OMITTED' => "\033[90m",
    ];
    private const RESET = "\033[0m";
    private const MAX_FINDINGS_PER_CHECK = 25;

    public function __construct(private bool $colors)
    {
    }

    /**
     * @param array<string, mixed> $report
     * @param array{markdown: string, json: string}|null $paths
     */
    public function render(array $report, ?array $paths, string $displayBase): string
    {
        $p = $report['project'];
        $lines = [];
        $lines[] = '';
        $lines[] = $this->bold('Validador de Alistamiento Técnico para Proyectos Drupal');
        if ($report['mode'] === 'demo') {
            $lines[] = $this->paint('WARN', 'MODO DEMO: datos ficticios; no se ejecutaron herramientas externas.');
        }
        $lines[] = sprintf('Rama: %s   Base: %s   Commit: %s', $p['branch'], $p['base'], $p['commit_short']);
        $lines[] = sprintf('Merge-base: %s   Commits: %d   Archivos considerados: %d   Alcance: %s',
            substr((string) $p['merge_base'], 0, 12), count($report['commits']), count($report['files']), $p['scope']);
        $lines[] = '';

        foreach ($report['checks'] as $check) {
            $lines[] = sprintf('%s %s — %s', $this->badge($check['status']), $this->bold($check['id']), $check['summary']);
            foreach ($check['tools'] as $tool) {
                if ($tool['status'] === 'OMITTED') {
                    $lines[] = '    ' . $this->paint('OMITTED', "· {$tool['name']}: OMITTED — {$tool['detail']}");
                }
            }
            $shown = 0;
            foreach ($check['findings'] as $f) {
                if ($shown++ >= self::MAX_FINDINGS_PER_CHECK) {
                    $lines[] = '    … (ver reporte completo)';
                    break;
                }
                $lines[] = '    ' . $this->paint($f['severity'] === 'error' ? 'FAIL' : 'WARN', $this->location($f)) . ' [' . $f['rule'] . '] ' . $f['message'];
                if (isset($f['commit'])) {
                    $lines[] = sprintf('        commit: %s · autor: %s · fecha: %s', $f['commit'], $f['author'] ?? '', $f['date'] ?? '');
                }
                if (!empty($f['code'])) {
                    $lines[] = '        > ' . $f['code'];
                }
            }
            if ($check['preexisting'] !== []) {
                $lines[] = '    ' . $this->paint('OMITTED', sprintf('Preexistentes (no bloquean): %d', count($check['preexisting'])));
                foreach (array_slice($check['preexisting'], 0, 5) as $f) {
                    $lines[] = '      ' . $this->paint('OMITTED', $this->location($f) . ' [' . $f['rule'] . '] ' . $f['message']);
                }
                if (count($check['preexisting']) > 5) {
                    $lines[] = '      … (ver reporte completo)';
                }
            }
        }

        $lines[] = '';
        $status = $report['result']['status'];
        $lines[] = sprintf('Resultado: %s  (código de salida %d)', $this->badge($status), $report['result']['exit_code']);
        $lines[] = $report['result']['message'];
        if ($paths !== null) {
            $lines[] = 'Reportes:';
            $lines[] = '  ' . $this->relative($paths['markdown'], $displayBase);
            $lines[] = '  ' . $this->relative($paths['json'], $displayBase);
        }
        $lines[] = '';
        return implode("\n", $lines) . "\n";
    }

    /**
     * @param array<string, mixed> $f
     */
    private function location(array $f): string
    {
        return $f['file'] . ($f['line'] !== null ? ':' . $f['line'] : '') . ($f['column'] !== null ? ':' . $f['column'] : '');
    }

    private function relative(string $path, string $base): string
    {
        $base = rtrim($base, '/') . '/';
        return str_starts_with($path, $base) ? substr($path, strlen($base)) : $path;
    }

    private function badge(string $status): string
    {
        return $this->paint($status, '[' . str_pad($status, 7, ' ', STR_PAD_BOTH) . ']');
    }

    private function paint(string $status, string $text): string
    {
        if (!$this->colors) {
            return $text;
        }
        return (self::COLORS[$status] ?? '') . $text . self::RESET;
    }

    private function bold(string $text): string
    {
        return $this->colors ? "\033[1m{$text}" . self::RESET : $text;
    }
}
