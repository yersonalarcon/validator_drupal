<?php

declare(strict_types=1);

namespace ReadinessCheck\Report;

use ReadinessCheck\Exception\ExecutionException;

/**
 * Escribe reports/readiness-<commit>.md y reports/readiness-<commit>.json.
 */
final class ReportWriter
{
    public function __construct(private string $reportDir)
    {
    }

    /**
     * @param array<string, mixed> $report
     * @return array{markdown: string, json: string}
     */
    public function write(array $report, string $name): array
    {
        if (!is_dir($this->reportDir) && !@mkdir($this->reportDir, 0775, true) && !is_dir($this->reportDir)) {
            throw new ExecutionException('No se pudo crear el directorio de reportes: ' . $this->reportDir);
        }
        $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', $name) ?? 'report';
        $markdownPath = $this->reportDir . '/readiness-' . $safeName . '.md';
        $jsonPath = $this->reportDir . '/readiness-' . $safeName . '.json';

        $json = json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        if ($json === false) {
            throw new ExecutionException('No se pudo serializar el reporte JSON: ' . json_last_error_msg());
        }
        $markdown = (new MarkdownRenderer())->render($report);

        if (@file_put_contents($markdownPath, $markdown) === false || @file_put_contents($jsonPath, $json . "\n") === false) {
            throw new ExecutionException('No se pudieron escribir los reportes en ' . $this->reportDir);
        }
        return ['markdown' => $markdownPath, 'json' => $jsonPath];
    }
}
