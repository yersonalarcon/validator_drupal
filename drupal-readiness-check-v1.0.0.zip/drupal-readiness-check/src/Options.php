<?php

declare(strict_types=1);

namespace ReadinessCheck;

use ReadinessCheck\Exception\ConfigurationException;

/**
 * Opciones de línea de comandos ya validadas.
 */
final class Options
{
    public const SCOPE_CHANGED = 'changed';
    public const SCOPE_ALL = 'all';

    public const FAIL_ON_FAIL = 'fail';
    public const FAIL_ON_WARN = 'warn';

    /**
     * @param list<string>|null $checks Checks pedidos explícitamente con --checks.
     */
    public function __construct(
        public ?string $base = null,
        public ?array $checks = null,
        public bool $allChecks = false,
        public string $scope = self::SCOPE_CHANGED,
        public ?string $uri = null,
        public string $failOn = self::FAIL_ON_FAIL,
        public bool $demo = false,
        public bool $help = false,
        public bool $noColor = false
    ) {
    }

    /**
     * Interpreta los argumentos del comando.
     *
     * @param list<string> $argv
     * @param list<string> $knownChecks
     */
    public static function fromArgv(array $argv, array $knownChecks): self
    {
        $options = new self();
        $count = count($argv);

        for ($i = 0; $i < $count; $i++) {
            $arg = $argv[$i];

            if ($arg === '--help' || $arg === '-h') {
                $options->help = true;
                continue;
            }
            if ($arg === '--all-checks') {
                $options->allChecks = true;
                continue;
            }
            if ($arg === '--demo') {
                $options->demo = true;
                continue;
            }
            if ($arg === '--no-color') {
                $options->noColor = true;
                continue;
            }

            if (!str_starts_with($arg, '--')) {
                throw new ConfigurationException("Argumento no reconocido: '{$arg}'. Use --help para ver las opciones.");
            }

            $name = substr($arg, 2);
            $value = null;
            if (str_contains($name, '=')) {
                [$name, $value] = explode('=', $name, 2);
            } elseif (in_array($name, ['base', 'checks', 'scope', 'uri', 'fail-on'], true)) {
                if ($i + 1 >= $count || str_starts_with($argv[$i + 1], '--')) {
                    throw new ConfigurationException("La opción --{$name} requiere un valor (p. ej. --{$name}=valor).");
                }
                $value = $argv[++$i];
            }

            switch ($name) {
                case 'base':
                    $options->base = self::requireValue($name, $value);
                    break;

                case 'checks':
                    $list = array_values(array_filter(array_map('trim', explode(',', self::requireValue($name, $value))), 'strlen'));
                    $unknown = array_diff($list, $knownChecks);
                    if ($unknown !== []) {
                        throw new ConfigurationException(
                            'Validación desconocida: ' . implode(', ', $unknown)
                            . '. Disponibles: ' . implode(', ', $knownChecks) . '.'
                        );
                    }
                    if ($list === []) {
                        throw new ConfigurationException('--checks no puede estar vacío.');
                    }
                    $options->checks = array_values(array_unique($list));
                    break;

                case 'scope':
                    $scope = self::requireValue($name, $value);
                    if (!in_array($scope, [self::SCOPE_CHANGED, self::SCOPE_ALL], true)) {
                        throw new ConfigurationException("Valor inválido para --scope: '{$scope}'. Use 'changed' o 'all'.");
                    }
                    $options->scope = $scope;
                    break;

                case 'uri':
                    $options->uri = self::requireValue($name, $value);
                    break;

                case 'fail-on':
                    $failOn = self::requireValue($name, $value);
                    if (!in_array($failOn, [self::FAIL_ON_FAIL, self::FAIL_ON_WARN], true)) {
                        throw new ConfigurationException("Valor inválido para --fail-on: '{$failOn}'. Use 'fail' o 'warn'.");
                    }
                    $options->failOn = $failOn;
                    break;

                default:
                    throw new ConfigurationException("Opción desconocida: '--{$name}'. Use --help para ver las opciones.");
            }
        }

        return $options;
    }

    private static function requireValue(string $name, ?string $value): string
    {
        if ($value === null || trim($value) === '') {
            throw new ConfigurationException("La opción --{$name} requiere un valor.");
        }
        return trim($value);
    }

    public static function helpText(): string
    {
        return <<<TXT
Validador de Alistamiento Técnico para Proyectos Drupal

Uso:
  ddev readiness-check [opciones]

Opciones:
  --base=<ref>         Rama base de comparación (p. ej. origin/develop).
                       Por defecto se autodetecta: develop, main, master.
  --checks=<lista>     Validaciones separadas por comas. Disponibles:
                       db-updates, code-standards, secrets-scan,
                       config-status, composer-audit, disallowed-modules.
  --all-checks         Ejecuta también las validaciones opcionales.
  --scope=<alcance>    changed (por defecto): archivos modificados en la rama.
                       all: todos los archivos versionados y nuevos del proyecto.
  --uri=<url>          URI del sitio para Drush (proyectos multisitio).
  --fail-on=<estado>   fail (por defecto) o warn: con warn, las advertencias
                       también devuelven código de salida 1.
  --demo               Genera un reporte de demostración con datos ficticios,
                       sin ejecutar Git, Drush ni otras herramientas.
  --no-color           Desactiva los colores en la consola.
  --help, -h           Muestra esta ayuda.

Códigos de salida:
  0  Aprobado o solo advertencias.
  1  Fallo (o advertencias con --fail-on=warn).
  2  Error de ejecución o de configuración.

TXT;
    }
}
