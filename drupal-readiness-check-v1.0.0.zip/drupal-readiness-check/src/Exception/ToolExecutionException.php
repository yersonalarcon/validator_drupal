<?php

declare(strict_types=1);

namespace ReadinessCheck\Exception;

/**
 * Una herramienta externa está instalada pero no pudo ejecutarse
 * correctamente (p. ej. Drush sin conexión a la base de datos).
 *
 * La validación afectada queda OMITTED con el motivo y la ejecución global
 * termina con código 2 si no hay ningún FAIL.
 */
class ToolExecutionException extends \RuntimeException
{
}
