<?php

declare(strict_types=1);

namespace ReadinessCheck\Exception;

/**
 * Error de ejecución que impide completar la validación (p. ej. Git falla).
 *
 * Provoca el código de salida 2.
 */
class ExecutionException extends \RuntimeException
{
}
