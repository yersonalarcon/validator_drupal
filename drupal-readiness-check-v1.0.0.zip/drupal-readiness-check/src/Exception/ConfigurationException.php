<?php

declare(strict_types=1);

namespace ReadinessCheck\Exception;

/**
 * Error de configuración o de uso (opciones inválidas, rama base inexistente…).
 *
 * Provoca el código de salida 2.
 */
class ConfigurationException extends \RuntimeException
{
}
