# Validador de Alistamiento Técnico para Proyectos Drupal

`drupal-readiness-check` valida técnicamente los cambios de la rama Git actual **antes de crear un Pull Request**. Compara la rama con su rama base (`develop`, `main` o `master`), identifica exactamente qué archivos y líneas cambiaron y ejecuta sobre ellos validaciones de base de datos, sintaxis, estándares Drupal y secretos.

```bash
ddev readiness-check
```

La herramienta solo lee: no modifica archivos de Drupal, no corrige errores, no hace commits ni toca el índice de Git. Lo único que escribe son los reportes en `drupal-readiness-check/reports/`.

---

## Contenido

1. [Requisitos](#requisitos)
2. [Estructura del proyecto](#estructura-del-proyecto)
3. [Instalación](#instalación)
4. [Dependencias por validación](#dependencias-por-validación)
5. [Comandos](#comandos)
6. [Cómo se determinan los cambios](#cómo-se-determinan-los-cambios)
7. [Validaciones](#validaciones)
8. [Estados y códigos de salida](#estados-y-códigos-de-salida)
9. [Reportes](#reportes)
10. [Configuración](#configuración)
11. [Pruebas automáticas](#pruebas-automáticas)
12. [Decisiones técnicas](#decisiones-técnicas)
13. [Solución de errores comunes](#solución-de-errores-comunes)

---

## Requisitos

| Requisito | Detalle |
|---|---|
| DDEV | Proyecto Drupal configurado con DDEV (`.ddev/config.yaml`). |
| PHP | 8.0 o superior dentro del contenedor web (el de DDEV para Drupal 10/11 ya cumple). Probado con 8.2 y 8.4; con 8.0 y 8.1 no se ha probado. |
| Git | Disponible en el contenedor web de DDEV (incluido en la imagen oficial). |
| Bash | Para los scripts de instalación y las pruebas. |
| curl o wget | Solo para descargar Gitleaks con `scripts/install-gitleaks.sh`. |

El validador no tiene dependencias de Composer propias. Usa las herramientas que el proyecto Drupal ya trae (`vendor/bin/drush`, `vendor/bin/phpcs`, `vendor/symfony/yaml`) y Gitleaks como binario independiente.

## Estructura del proyecto

```
drupal-readiness-check/
├── bin/
│   ├── readiness-check          # Punto de entrada (PHP CLI)
│   └── yaml-lint                # Auxiliar interno: valida YAML con symfony/yaml en un proceso aparte
├── src/
│   ├── Application.php          # Orquestación, selección de validaciones, código de salida
│   ├── Options.php              # Interpretación de opciones de línea de comandos
│   ├── Check/                   # Validaciones y modelo de resultados
│   │   ├── DbUpdatesCheck.php
│   │   ├── CodeStandardsCheck.php
│   │   ├── SecretsScanCheck.php
│   │   ├── ConfigStatusCheck.php        (opcional)
│   │   ├── ComposerAuditCheck.php       (opcional)
│   │   ├── DisallowedModulesCheck.php   (opcional)
│   │   └── CheckContext / CheckResult / Finding / Status / CheckInterface
│   ├── Git/                     # merge-base, commits, staged, unstaged, archivos nuevos, líneas modificadas
│   ├── Process/                 # Ejecución de procesos sin shell (rutas con espacios y tildes)
│   ├── Report/                  # Consola, Markdown y JSON
│   ├── Support/                 # Localización de herramientas, redacción de secretos, JSON
│   ├── Demo/                    # Datos ficticios de --demo
│   └── Exception/
├── config/
│   ├── settings.php             # Ramas candidatas, validaciones por defecto, extensiones, tiempos
│   └── disallowed-modules.txt   # Lista configurable de módulos prohibidos
├── scripts/
│   ├── install.sh               # Registra "ddev readiness-check"
│   └── install-gitleaks.sh      # Descarga y verifica Gitleaks
├── tests/
│   ├── scenario-branch.sh       # Batería de pruebas automáticas
│   └── fakes/                   # Dobles de prueba de Drush, phpcs y Gitleaks (solo pruebas)
├── reports/                     # Reportes generados (ignorados por Git)
├── ddev-commands/
│   └── web/readiness-check      # Plantilla del comando DDEV (se ejecuta en el contenedor web)
├── .gitignore
└── README.md
```

## Instalación

1. Copie el directorio `drupal-readiness-check/` a la **raíz** del proyecto Drupal (donde está `.ddev/`).

2. Ejecute el instalador desde el host:

   ```bash
   bash drupal-readiness-check/scripts/install.sh
   ```

   El instalador:
   - da permisos de ejecución a los scripts del validador;
   - copia `ddev-commands/web/readiness-check` a `.ddev/commands/web/readiness-check`, con la ruta relativa del validador;
   - añade `/drupal-readiness-check/` y `/.ddev/commands/web/readiness-check` a `.git/info/exclude`, de modo que la herramienta no aparezca en `git status` ni se suba por accidente. Este archivo es local a su clon y no se versiona;
   - si DDEV está en marcha y el comando es nuevo o cambió, ejecuta `ddev restart`. Use `--no-restart` para evitarlo;
   - avisa si algún archivo del validador ya estaba versionado. `.git/info/exclude` no retira archivos ya versionados; en ese caso el instalador sugiere `git rm -r --cached`, pero no lo ejecuta.

   Opciones: `--no-restart` y `--force` (reemplaza un `.ddev/commands/web/readiness-check` existente que no pertenezca al validador).

3. (Recomendado) Instale Gitleaks para habilitar `secrets-scan`:

   ```bash
   bash drupal-readiness-check/scripts/install-gitleaks.sh
   ```

   Desde el host, el script se vuelve a lanzar dentro del contenedor con `ddev exec`, porque el validador se ejecuta allí y necesita un binario de Linux. Descarga la release oficial de GitHub, **verifica el SHA-256** con el `checksums.txt` publicado y deja el binario en `drupal-readiness-check/bin/gitleaks` (ignorado por Git).
   - Versión por defecto: `8.28.0`. Para otra versión: `GITLEAKS_VERSION=8.x.y bash .../install-gitleaks.sh --force`.
   - `--host` instala para el sistema actual en lugar del contenedor.

4. Compruebe la instalación:

   ```bash
   ddev readiness-check --demo
   ddev readiness-check
   ```

## Dependencias por validación

Si falta una herramienta, la validación (o la parte afectada) aparece como **OMITTED** con el motivo y el resto continúa.

| Validación | Herramienta | Dónde la busca | Cómo instalarla |
|---|---|---|---|
| db-updates | Drush | `vendor/bin/drush`, luego `PATH` | `ddev composer require drush/drush` |
| code-standards (sintaxis PHP) | `php -l` | El mismo PHP que ejecuta el validador | Incluido |
| code-standards (YAML) | symfony/yaml | `vendor/symfony/yaml` del proyecto | Incluido en Drupal core |
| code-standards (estándares) | phpcs + Drupal Coder | `vendor/bin/phpcs`, luego `PATH` | `ddev composer require --dev drupal/coder` |
| secrets-scan | Gitleaks | `drupal-readiness-check/bin/gitleaks`, luego `PATH` | `scripts/install-gitleaks.sh` |
| config-status (opcional) | Drush | igual que db-updates | — |
| composer-audit (opcional) | Composer ≥ 2.4 | `PATH` (DDEV lo incluye) | — |
| disallowed-modules (opcional) | — | Solo lectura de archivos | — |

Para instalaciones no estándar se puede indicar la ruta con las variables `READINESS_DRUSH`, `READINESS_PHPCS`, `READINESS_GITLEAKS`, `READINESS_COMPOSER` y `READINESS_YAML_AUTOLOAD`. Si la ruta indicada no existe, la herramienta se trata como no instalada.

## Comandos

| Comando | Descripción |
|---|---|
| `ddev readiness-check` | Validaciones por defecto (`db-updates`, `code-standards`, `secrets-scan`) contra la base autodetectada. |
| `ddev readiness-check --base=origin/develop` | Usa una rama base concreta (local o remota). |
| `ddev readiness-check --checks=code-standards` | Ejecuta solo las validaciones indicadas, separadas por comas. |
| `ddev readiness-check --all-checks` | Añade las opcionales: `config-status`, `composer-audit` y `disallowed-modules`. |
| `ddev readiness-check --scope=all` | Analiza todos los archivos versionados y nuevos, no solo los cambiados (ver [alcance](#alcance---scope)). |
| `ddev readiness-check --uri=http://sitio.ddev.site` | Pasa `--uri` a Drush (multisitio). |
| `ddev readiness-check --fail-on=warn` | Las advertencias también devuelven código 1. |
| `ddev readiness-check --demo` | Reporte de ejemplo con datos ficticios, sin ejecutar Git ni ninguna herramienta. |
| `ddev readiness-check --help` | Ayuda. |
| `--no-color` | Desactiva colores (también se respeta `NO_COLOR`). |

Las opciones aceptan `--opcion=valor` y `--opcion valor`, y se pueden combinar:

```bash
ddev readiness-check --base=origin/main --all-checks --uri=http://es.sitio.ddev.site --fail-on=warn
ddev readiness-check --checks=secrets-scan,code-standards
```

Sin DDEV, el validador se ejecuta igual desde la raíz del repositorio:

```bash
php drupal-readiness-check/bin/readiness-check [opciones]
```

## Cómo se determinan los cambios

1. **Rama actual:** `git symbolic-ref --short HEAD`. Con HEAD separado se muestra `HEAD (detached)`.
2. **Rama base:** el valor de `--base` o, si no se indica, la primera que exista de esta lista: `origin/develop`, `develop`, `origin/main`, `main`, `origin/master`, `master`. Se prefiere la remota porque suele estar más actualizada. Una rama local con el mismo nombre que la rama actual se omite. Si no se encuentra ninguna, el resultado es el código 2 y se pide `--base`.
3. **Merge-base:** `git merge-base HEAD <base>`.
4. **Commits:** `git log <merge-base>..HEAD`; se incluyen en el reporte.
5. **Archivos y líneas:**
   - `git diff -U0 -M <merge-base>` compara el merge-base con el **árbol de trabajo**, así que abarca a la vez commits, cambios staged y cambios unstaged. Las líneas añadidas o modificadas se toman de las cabeceras `@@`.
   - `git ls-files --others --exclude-standard` lista los archivos nuevos sin seguimiento (respetando `.gitignore`). Todas sus líneas cuentan como nuevas.
   - Cada archivo indica su origen: `committed`, `staged`, `unstaged` y/o `untracked`.
   - Los archivos eliminados no se analizan. Los renombrados se comparan con su ruta anterior.
6. **Exclusiones:** el directorio del validador (calculado en tiempo de ejecución, sin rutas absolutas) y `.ddev/commands/web/readiness-check` nunca se analizan. El reporte indica cuántos archivos se excluyeron.

Los nombres de archivo con espacios, tildes, `ñ`, `#`, `&`, paréntesis, comillas o barras invertidas están cubiertos por las pruebas. Los procesos externos se lanzan sin shell (`proc_open` con array de argumentos), por lo que no hay que escapar nada y no hay riesgo de inyección.

### Errores nuevos y preexistentes

- Un hallazgo en una **línea modificada** por la rama es **nuevo** y determina el estado.
- Un hallazgo en una **línea no modificada** es **preexistente**: se lista aparte en consola y reportes y **nunca** hace fallar la validación.
- Caso especial, errores de sintaxis (PHP y YAML): el parser puede señalar una línea distinta de la que causó el error (por ejemplo, al borrar una llave de cierre el error aparece al final del archivo). Si el error cae en una línea no modificada, el validador comprueba la versión del archivo en el merge-base:
  - si allí también fallaba, el error es preexistente;
  - si allí era válido, el error lo causó la rama y se considera nuevo, con una nota explicativa.

### Alcance (`--scope`)

- `changed` (por defecto): solo archivos modificados, staged, unstaged o nuevos.
- `all`: además, todos los archivos versionados (`git ls-files`). Sirve como auditoría completa del código del repositorio. La clasificación nuevo/preexistente se mantiene: los errores en líneas que la rama no tocó siguen sin bloquear. No afecta a `secrets-scan`, que siempre revisa commits, staged, unstaged y archivos nuevos de la rama.

## Validaciones

### db-updates

1. Ejecuta `drush updatedb:status --format=json` (con `--uri` si se indicó).
2. Para cada actualización pendiente obtiene la función que la define:
   - `hook_update_N` → `<módulo>_update_<N>()` en `<módulo>.install`;
   - `hook_post_update_NAME` → `<módulo>_post_update_<NAME>()` en `<módulo>.post_update.php`.
3. Localiza el archivo y la línea de `function <nombre>(`. Busca primero en los archivos de la rama y luego en el resto del proyecto (sin `vendor/`, `node_modules/`, `.git/` ni directorios `files/`).
4. Clasificación:
   - **FAIL**: la línea de definición fue introducida por la rama actual. La rama trae una actualización que no se ha ejecutado localmente (`ddev drush updatedb`).
   - **WARN**: la actualización viene de otra rama, de un módulo contrib o de core.
   - **WARN**: no se encontró la definición (se indica en el mensaje).

### code-standards

Analiza archivos `.php`, `.module`, `.inc`, `.install` y `.theme` (configurable), además de `.yml` y `.yaml`.

| Parte | Herramienta | Detalle |
|---|---|---|
| Sintaxis PHP | `php -l` | Un proceso por archivo, con el PHP del contenedor. |
| Sintaxis YAML | `symfony/yaml` del proyecto | Mismas banderas que Drupal (`PARSE_EXCEPTION_ON_INVALID_TYPE`, `PARSE_CUSTOM_TAGS`). Se ejecuta en un proceso aparte para no mezclar autoloads. |
| Estándares | `phpcs` + Drupal Coder | Si existe `phpcs.xml`, `phpcs.xml.dist`, `.phpcs.xml` o `.phpcs.xml.dist` en la raíz, phpcs se ejecuta desde la raíz sin `--standard`, así respeta el ruleset del proyecto (incluidos sus `exclude-pattern`). Si no existe, usa `--standard=Drupal,DrupalPractice` cuando `phpcs -i` muestra esos estándares. |

Los errores de phpcs (`ERROR`) en líneas modificadas producen FAIL; las advertencias (`WARNING`) producen WARN.

### secrets-scan

Ejecuta Gitleaks con `--redact` sobre:

| Origen | Gitleaks ≥ 8.19 | Gitleaks < 8.19 |
|---|---|---|
| Commits de la rama | `gitleaks git --log-opts=<merge-base>..HEAD` | `gitleaks detect --log-opts=…` |
| Cambios staged | `gitleaks git --pre-commit --staged` | `gitleaks protect --staged` |
| Cambios unstaged | `gitleaks git --pre-commit` | `gitleaks protect` |
| Archivos nuevos | `gitleaks dir <archivo>` | `gitleaks detect --no-git --source=<archivo>` |

Si existen, se usan `.gitleaks.toml` y `.gitleaksignore` de la raíz del proyecto.

Cada hallazgo muestra archivo, línea, columna, regla, mensaje, commit, autor y fecha. Para cambios sin commit, el commit figura como `sin commit (staged)`, `sin commit (unstaged)` o `sin commit (archivo nuevo)`, el autor es el `user.name` local y la fecha es la de modificación del archivo.

**El secreto nunca se muestra**:
- Gitleaks se ejecuta siempre con `--redact` y el campo `Secret` no se copia a ningún reporte.
- El fragmento de código mostrado es el `Match` de Gitleaks con el valor sustituido por `****REDACTED****`. Si por algún motivo el `Match` trajera el valor real, también se reemplaza.
- Las líneas con secretos se enmascaran por completo en las demás validaciones. Esta validación se ejecuta primero precisamente por eso.
- Como defensa adicional, en todos los fragmentos de código se enmascaran los valores asignados a claves como `password`, `secret`, `token`, `api_key`, `salt` o `auth`.
- Los informes JSON temporales de Gitleaks se escriben en un directorio privado (`0700`) y se borran al terminar.

Cualquier secreto detectado produce **FAIL**.

### Validaciones opcionales

Solo se ejecutan con `--all-checks` o al nombrarlas en `--checks=`. Si no se piden, aparecen como OMITTED con el texto "no seleccionada".

| Validación | Qué hace | Estados |
|---|---|---|
| `config-status` | `drush config:status --format=json` (con `--uri`). | WARN si la configuración activa difiere del directorio de sincronización; PASS si no hay diferencias. |
| `composer-audit` | `composer audit --format=json --locked` sobre `composer.lock`. | FAIL con avisos de seguridad; WARN con paquetes abandonados; OMITTED si no hay `composer.lock`. |
| `disallowed-modules` | Busca los módulos de `config/disallowed-modules.txt` en `core.extension.yml` (habilitados), en `composer.json` (`drupal/<módulo>`), en las dependencias de `*.info.yml` y en archivos `<módulo>.info.yml` añadidos. | FAIL si aparecen en líneas modificadas por la rama; las apariciones preexistentes se listan aparte. |

## Estados y códigos de salida

| Estado | Significado |
|---|---|
| `PASS` | Aprobado. |
| `WARN` | Advertencia; no bloquea salvo con `--fail-on=warn`. |
| `FAIL` | Error que bloquea. |
| `OMITTED` | Validación omitida: herramienta no instalada, no seleccionada o con error de ejecución (se indica el motivo). |

| Código | Cuándo |
|---|---|
| `0` | Todo aprobado o solo advertencias. |
| `1` | Al menos un FAIL, o advertencias con `--fail-on=warn`. |
| `2` | Error de configuración o ejecución: opción inválida, proyecto sin Git, repositorio sin commits, rama base inexistente o no detectable, reportes no escribibles, o una herramienta **instalada** que falló al ejecutarse (por ejemplo, Drush sin conexión a la base de datos). |

Prioridad: si hay un FAIL, el código es 1 aunque otra herramienta haya fallado, porque el bloqueo ya es seguro. Una herramienta **no instalada** no produce código 2: queda OMITTED y la ejecución continúa.

## Reportes

Cada ejecución escribe:

```
drupal-readiness-check/reports/readiness-<commit>.md
drupal-readiness-check/reports/readiness-<commit>.json
```

`<commit>` son los primeros 12 caracteres del commit HEAD; en modo demo se usa `readiness-demo.*`. Los reportes están ignorados por Git.

Contenido de ambos formatos:

- commit completo del proyecto, rama actual, rama base, su commit y el merge-base;
- alcance, URI de Drush, criterio `--fail-on` y validaciones solicitadas;
- commits de la rama (hash, autor, fecha, asunto);
- archivos considerados, con origen y rangos de líneas modificadas, y número de archivos excluidos;
- para cada validación: estado, resumen, herramientas usadas (y si se omitieron), hallazgos nuevos y errores preexistentes por separado;
- para cada hallazgo: archivo, línea, columna, regla, mensaje, severidad y código involucrado (redactado); en secretos, además, commit, autor y fecha;
- resultado global y código de salida.

Fragmento del JSON:

```json
{
  "mode": "real",
  "project": {
    "commit": "7c72ef104c1f6dcb0084a0881714fe4e0ff47605",
    "branch": "feature/demo",
    "base": "origin/develop",
    "merge_base": "8350a080be037c28cb9be9969f3c3c3f5dda42b4",
    "scope": "changed"
  },
  "files": [
    { "path": "web/modules/custom/x/new.module", "origins": ["committed"], "new_file": true, "changed_lines": "all" }
  ],
  "checks": [
    {
      "id": "code-standards",
      "status": "FAIL",
      "findings": [
        { "file": "web/modules/custom/x/new.module", "line": 3, "column": null,
          "rule": "php-lint.parse-error", "message": "syntax error, unexpected token \";\"",
          "severity": "error", "code": "$c = ;" }
      ],
      "preexisting": [ ]
    }
  ],
  "result": { "status": "FAIL", "exit_code": 1 }
}
```

Para ver el formato completo sin un proyecto real: `ddev readiness-check --demo`.

## Configuración

`config/settings.php`:

| Clave | Por defecto | Uso |
|---|---|---|
| `base_candidates` | `develop, main, master` | Orden de autodetección de la base. |
| `remote` | `origin` | Remoto de las ramas candidatas. |
| `default_checks` | `db-updates, code-standards, secrets-scan` | Validaciones por defecto. |
| `optional_checks` | `config-status, composer-audit, disallowed-modules` | Solo con `--all-checks` o `--checks`. |
| `php_extensions` | `php, module, inc, install, theme` | Archivos tratados como PHP. |
| `yaml_extensions` | `yml, yaml` | Archivos tratados como YAML. |
| `phpcs_default_standard` | `Drupal,DrupalPractice` | Estándar si el proyecto no tiene ruleset. |
| `disallowed_modules_file` | `tool:config/disallowed-modules.txt` | Lista de módulos prohibidos (`tool:` = relativo al validador). |
| `exclude_paths` | `.ddev/commands/web/readiness-check` | Rutas adicionales que no se analizan. |
| `timeouts` | drush 300 s, phpcs 600 s… | Tiempo máximo por herramienta. |

`config/disallowed-modules.txt` admite un nombre de máquina por línea y comentarios con `#`.

## Pruebas automáticas

```bash
bash drupal-readiness-check/tests/scenario-branch.sh
# o dentro del contenedor:
ddev exec bash drupal-readiness-check/tests/scenario-branch.sh
```

Cada escenario crea un repositorio Git temporal con espacios y tildes en la ruta (`mktemp`), con rama `develop`, un remoto `origin` bare y una rama `feature/*`. Copia el validador dentro y lo ejecuta. El proyecto Drupal del usuario no se toca y los temporales se borran al terminar (`KEEP_TMP=1` los conserva).

La batería tiene 65 comprobaciones. Cubre: proyecto sin Git, opciones inválidas, base inexistente, autodetección (remota, local, ninguna), `--base` remoto y merge-base, errores nuevos, errores preexistentes, errores de sintaxis causados por la rama en líneas no modificadas, cambios staged, unstaged y archivos nuevos, archivos con espacios, tildes, `#`, `&`, paréntesis, comillas y barra invertida, `.module`, `.theme` e `.inc`, exclusión de archivos del validador, reportes MD/JSON y su contenido, códigos de salida 0, 1 y 2, `--fail-on=warn`, `--checks`, `--all-checks`, `--scope=all`, `--uri`, `--demo` sin Git en el `PATH`, que el repositorio no se modifique, redacción de secretos, herramientas ausentes (OMITTED) o que fallan, `disallowed-modules`, el instalador (registro del comando, `.git/info/exclude`, idempotencia, rutas con caracteres especiales) y el comando DDEV instalado.

**Tipos de prueba:**
- Sin etiqueta: comportamiento real con Git y `php -l` reales.
- `[doble]`: usan `tests/fakes/` en lugar de Drush, phpcs o Gitleaks. Reproducen el formato de salida documentado de esas herramientas para probar la integración del validador: mapeo de campos, archivo/línea, clasificación y redacción. **No prueban la herramienta real.** Los dobles solo se activan desde las pruebas mediante variables `READINESS_*`.
- `[real]`: necesitan la herramienta real y aparecen como `SKIP` si no está disponible:
  - Gitleaks: en `PATH`, en `bin/gitleaks` o en `READINESS_TEST_GITLEAKS`;
  - phpcs con Drupal Coder: en `PATH` o en `READINESS_TEST_PHPCS`;
  - symfony/yaml: `READINESS_TEST_YAML_AUTOLOAD=/var/www/html/vendor/autoload.php`.

  Dentro de DDEV, con todo instalado:

  ```bash
  ddev exec env READINESS_TEST_PHPCS=/var/www/html/vendor/bin/phpcs \
    READINESS_TEST_YAML_AUTOLOAD=/var/www/html/vendor/autoload.php \
    bash drupal-readiness-check/tests/scenario-branch.sh
  ```

## Decisiones técnicas

Decisiones tomadas donde la especificación no fijaba el comportamiento:

1. **Errores de sintaxis en líneas no modificadas:** se comparan con la versión del merge-base, para no dejar pasar un error causado por la rama que el parser reporta en otra línea. Ver [Errores nuevos y preexistentes](#errores-nuevos-y-preexistentes).
2. **`--scope=all`:** significa "todos los archivos versionados además de los cambiados". Se mantiene la regla de no fallar por errores en líneas no modificadas.
3. **Herramienta instalada que falla:** OMITTED con el motivo y código de salida 2 (si no hay ningún FAIL). Así un fallo de conexión de Drush no se confunde con una aprobación.
4. **Validaciones no seleccionadas:** aparecen como OMITTED en los reportes para que quede claro qué no se ejecutó.
5. **Secretos en cambios sin commit:** como no hay autor ni fecha de commit, se usa el `user.name` local y la fecha de modificación del archivo, indicándolo en el texto.
6. **`config-status` produce WARN, no FAIL:** las diferencias pueden ser legítimas y requieren revisión humana.
7. **Modo demo:** el código de salida es siempre 0 y el reporte avisa de que los datos son ficticios.
8. **Gitleaks se instala dentro del contenedor:** el validador se ejecuta en el contenedor web, así que el binario debe ser de Linux aunque el host sea macOS o Windows.
9. **Versión de Gitleaks:** se fija `8.28.0` por defecto (configurable) y la descarga se verifica por checksum.

### Qué está verificado y qué no

En el entorno donde se construyó la herramienta se verificó:
- la sintaxis de todos los archivos PHP (`php -l`, PHP 8.4 y 8.2) y de los scripts Bash (`bash -n`);
- la batería completa con PHP 8.4 y 8.2: 62 PASS, 0 FAIL y 3 SKIP (los tres `[real]`, por no estar Gitleaks, phpcs/Coder ni symfony/yaml disponibles).

No se verificó en ese entorno, por falta de DDEV, Drush, phpcs, Drupal Coder, Gitleaks, symfony/yaml y acceso a internet:
- la ejecución dentro de un contenedor DDEV real y el `ddev restart` del instalador;
- la descarga de `install-gitleaks.sh`;
- la salida real de Drush, phpcs y Gitleaks (solo el formato reproducido por los dobles);
- `composer audit` con avisos reales.

Ejecute `tests/scenario-branch.sh` dentro de su contenedor DDEV para cubrir las pruebas `[real]`.

## Solución de errores comunes

| Síntoma | Causa y solución |
|---|---|
| `Command "readiness-check" is not defined` / comando desconocido en DDEV | El comando no está registrado. Ejecute `bash drupal-readiness-check/scripts/install.sh` y, si DDEV estaba detenido, `ddev start` (o `ddev restart`). |
| `no se encontró el validador en '…'` | Se movió o renombró el directorio del validador. Vuelva a ejecutar `install.sh`. |
| `El directorio … no pertenece a un repositorio Git` (código 2) | Ejecute el comando dentro de un proyecto con Git. Con DDEV, la raíz del proyecto (`/var/www/html`) debe ser la raíz del repositorio. |
| `Git rechaza el repositorio por propietario distinto (safe.directory)` | Ocurre con algunos montajes de volúmenes. Dentro del contenedor: `ddev exec git config --global --add safe.directory /var/www/html`. Es una decisión del usuario; el validador no cambia la configuración de Git. |
| `No se pudo autodetectar la rama base` (código 2) | No existe `develop`, `main` ni `master` (ni local ni en `origin`). Use `--base=<rama>`. |
| `La rama base 'origin/develop' no existe` | Falta actualizar las ramas remotas: `git fetch origin`. |
| `db-updates` OMITTED con `Error de ejecución: … SQLSTATE … Connection refused` (código 2) | Drush no puede conectar a la base de datos. Compruebe `ddev status` y que el sitio esté instalado. En multisitio, indique `--uri`. |
| `db-updates` WARN "No se encontró su definición" | La función de la actualización no está en un archivo `<módulo>.install` o `<módulo>.post_update.php` dentro del proyecto (por ejemplo, está en `vendor/`). Revísela manualmente. |
| `phpcs: OMITTED — phpcs no está instalado` | `ddev composer require --dev drupal/coder`. |
| `phpcs: OMITTED — El estándar Drupal (Drupal Coder) no está instalado` | phpcs no encuentra el estándar. Con `drupal/coder` y `dealerdirect/phpcodesniffer-composer-installer` se registra solo; si no: `ddev exec vendor/bin/phpcs --config-set installed_paths vendor/drupal/coder/coder_sniffer,vendor/sirbrillig/phpcs-variable-analysis,vendor/slevomat/coding-standard`. |
| `symfony/yaml: OMITTED` | No existe `vendor/symfony/yaml`. Ejecute `ddev composer install`. |
| `secrets-scan` OMITTED "Gitleaks no está instalado" | `bash drupal-readiness-check/scripts/install-gitleaks.sh`. |
| `install-gitleaks.sh`: `El checksum no coincide` | Descarga corrupta o interceptada. Repita la instalación; no use el binario. |
| `install-gitleaks.sh` no descarga (proxy o sin internet) | Descargue manualmente `gitleaks_<versión>_linux_<arq>.tar.gz` de las releases oficiales, verifique el checksum y copie el binario a `drupal-readiness-check/bin/gitleaks`. |
| Gitleaks marca un falso positivo | Añada la huella (`Fingerprint`) a `.gitleaksignore` o una regla `allowlist` en `.gitleaks.toml` en la raíz del proyecto; el validador los usa automáticamente. |
| `composer-audit` OMITTED con error de ejecución | `composer audit` necesita acceso a internet para consultar la base de avisos. |
| El validador aparece en `git status` | Ejecute `install.sh` (añade las rutas a `.git/info/exclude`). Si ya se versionó: `git rm -r --cached drupal-readiness-check .ddev/commands/web/readiness-check`. |
| Muchos errores "preexistentes" | Es lo esperado en código heredado: no bloquean. Para verlos todos en archivos no modificados, use `--scope=all`. |
